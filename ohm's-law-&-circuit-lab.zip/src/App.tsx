import React, { useState } from 'react';
import { LabTab } from './types';
import { AndroidFrame } from './components/AndroidFrame';
import { NavigationHeader } from './components/NavigationHeader';
import { CustomCircuitDesigner } from './components/CustomCircuitDesigner';
import { StepByStepCircuitSolver } from './components/StepByStepCircuitSolver';
import { VIRPMatrixSolver } from './components/VIRPMatrixSolver';
import { OhmsLawCalculator } from './components/OhmsLawCalculator';
import { CircuitTestbench } from './components/CircuitTestbench';
import { VisualPhysicsSimulation } from './components/VisualPhysicsSimulation';
import { ResistorColorCoder } from './components/ResistorColorCoder';
import { CircuitChallenges } from './components/CircuitChallenges';

export default function App() {
  const [activeTab, setActiveTab] = useState<LabTab>('custom_designer');

  const tabTitles: Record<LabTab, string> = {
    custom_designer: 'Custom Circuit Designer & Simulator',
    virp_matrix: 'VIRP Table & Missing Quantity Solver',
    circuit_solver: 'Series, Parallel & Combination Solver',
    ohms_calculator: "Ohm's Law Equation Solver",
    circuit_sandbox: 'Interactive Circuit Testbench',
    physics_visualizer: 'Electron & Fluid Physics Lab',
    resistor_code: 'Resistor Color Band Reader',
    challenges: 'Circuit Challenges & Quizzes',
  };

  return (
    <AndroidFrame activeTabTitle={tabTitles[activeTab]}>
      {/* Tab Navigation */}
      <NavigationHeader activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Tab Content */}
      <div className="flex-1 w-full overflow-y-auto">
        {activeTab === 'custom_designer' && <CustomCircuitDesigner />}
        {activeTab === 'virp_matrix' && <VIRPMatrixSolver />}
        {activeTab === 'circuit_solver' && <StepByStepCircuitSolver />}
        {activeTab === 'ohms_calculator' && <OhmsLawCalculator />}
        {activeTab === 'circuit_sandbox' && <CircuitTestbench />}
        {activeTab === 'physics_visualizer' && <VisualPhysicsSimulation />}
        {activeTab === 'resistor_code' && <ResistorColorCoder />}
        {activeTab === 'challenges' && <CircuitChallenges />}
      </div>
    </AndroidFrame>
  );
}

