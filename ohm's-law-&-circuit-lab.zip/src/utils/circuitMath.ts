import { ResistorBandColor } from '../types';

export const BAND_COLORS: ResistorBandColor[] = [
  { name: 'Black', value: 0, multiplier: 1, colorHex: '#1e293b', textColor: '#ffffff' },
  { name: 'Brown', value: 1, multiplier: 10, tolerance: 1, colorHex: '#854d0e', textColor: '#ffffff' },
  { name: 'Red', value: 2, multiplier: 100, tolerance: 2, colorHex: '#dc2626', textColor: '#ffffff' },
  { name: 'Orange', value: 3, multiplier: 1000, colorHex: '#ea580c', textColor: '#ffffff' },
  { name: 'Yellow', value: 4, multiplier: 10000, colorHex: '#eab308', textColor: '#000000' },
  { name: 'Green', value: 5, multiplier: 100000, tolerance: 0.5, colorHex: '#16a34a', textColor: '#ffffff' },
  { name: 'Blue', value: 6, multiplier: 1000000, tolerance: 0.25, colorHex: '#2563eb', textColor: '#ffffff' },
  { name: 'Violet', value: 7, multiplier: 10000000, tolerance: 0.1, colorHex: '#9333ea', textColor: '#ffffff' },
  { name: 'Gray', value: 8, multiplier: 100000000, tolerance: 0.05, colorHex: '#64748b', textColor: '#ffffff' },
  { name: 'White', value: 9, multiplier: 1000000000, colorHex: '#f8fafc', textColor: '#000000' },
  { name: 'Gold', value: -1, multiplier: 0.1, tolerance: 5, colorHex: '#d97706', textColor: '#ffffff' },
  { name: 'Silver', value: -2, multiplier: 0.01, tolerance: 10, colorHex: '#94a3b8', textColor: '#000000' },
];

export interface LEDSpecs {
  color: string;
  forwardVoltage: number; // Volts
  nominalCurrent: number; // Amps (e.g. 0.02 = 20mA)
  maxCurrent: number;     // Amps (burns out above this)
  hex: string;
}

export const LED_DATA: Record<string, LEDSpecs> = {
  red: { color: 'Red', forwardVoltage: 2.0, nominalCurrent: 0.02, maxCurrent: 0.035, hex: '#ef4444' },
  yellow: { color: 'Yellow', forwardVoltage: 2.1, nominalCurrent: 0.02, maxCurrent: 0.035, hex: '#eab308' },
  green: { color: 'Green', forwardVoltage: 2.2, nominalCurrent: 0.02, maxCurrent: 0.035, hex: '#22c55e' },
  blue: { color: 'Blue', forwardVoltage: 3.2, nominalCurrent: 0.02, maxCurrent: 0.035, hex: '#3b82f6' },
  white: { color: 'White', forwardVoltage: 3.3, nominalCurrent: 0.02, maxCurrent: 0.035, hex: '#f8fafc' },
};

/** Format any electrical value with proper SI prefixes (p, n, µ, m, base, k, M, G) */
export function formatSI(val: number, unit: string, decimals = 2): string {
  if (val === 0 || !Number.isFinite(val)) return `0 ${unit}`;
  const abs = Math.abs(val);
  const sign = val < 0 ? '-' : '';

  if (abs >= 1e9) return `${sign}${(abs / 1e9).toFixed(decimals)} G${unit}`;
  if (abs >= 1e6) return `${sign}${(abs / 1e6).toFixed(decimals)} M${unit}`;
  if (abs >= 1e3) return `${sign}${(abs / 1e3).toFixed(decimals)} k${unit}`;
  if (abs >= 1) return `${sign}${abs.toFixed(decimals)} ${unit}`;
  if (abs >= 1e-3) return `${sign}${(abs * 1e3).toFixed(decimals)} m${unit}`;
  if (abs >= 1e-6) return `${sign}${(abs * 1e6).toFixed(decimals)} µ${unit}`;
  if (abs >= 1e-9) return `${sign}${(abs * 1e9).toFixed(decimals)} n${unit}`;
  return `${sign}${(abs * 1e12).toFixed(decimals)} p${unit}`;
}

export function formatVoltage(v: number): string {
  return formatSI(v, 'V');
}

export function formatCurrent(i: number): string {
  return formatSI(i, 'A');
}

export function formatResistance(r: number): string {
  return formatSI(r, 'Ω');
}

export function formatPower(p: number): string {
  return formatSI(p, 'W');
}

/** Solves Ohm's Law when any 2 of (V, I, R, P) are provided */
export function solveOhmsLaw(params: {
  voltage?: number;
  current?: number;
  resistance?: number;
  power?: number;
}): { voltage: number; current: number; resistance: number; power: number } {
  let { voltage: V, current: I, resistance: R, power: P } = params;

  if (V !== undefined && I !== undefined && V !== null && I !== null) {
    R = I !== 0 ? V / I : Infinity;
    P = V * I;
  } else if (V !== undefined && R !== undefined && V !== null && R !== null) {
    I = R !== 0 ? V / R : Infinity;
    P = R !== 0 ? (V * V) / R : Infinity;
  } else if (I !== undefined && R !== undefined && I !== null && R !== null) {
    V = I * R;
    P = I * I * R;
  } else if (P !== undefined && V !== undefined && P !== null && V !== null) {
    I = V !== 0 ? P / V : 0;
    R = P !== 0 ? (V * V) / P : 0;
  } else if (P !== undefined && I !== undefined && P !== null && I !== null) {
    V = I !== 0 ? P / I : 0;
    R = I !== 0 ? P / (I * I) : 0;
  } else if (P !== undefined && R !== undefined && P !== null && R !== null) {
    V = Math.sqrt(P * R);
    I = R !== 0 ? Math.sqrt(P / R) : 0;
  } else {
    V = V ?? 12;
    R = R ?? 100;
    I = V / R;
    P = (V * V) / R;
  }

  return {
    voltage: Math.max(0, V ?? 0),
    current: Math.max(0, I ?? 0),
    resistance: Math.max(0.001, R ?? 1),
    power: Math.max(0, P ?? 0),
  };
}

/** Calculate 4-band resistor value */
export function decode4Band(b1: number, b2: number, multiplierIdx: number, toleranceIdx: number) {
  const baseVal = b1 * 10 + b2;
  const mult = BAND_COLORS[multiplierIdx].multiplier;
  const resistance = baseVal * mult;
  const tolerance = BAND_COLORS[toleranceIdx]?.tolerance ?? 5;
  return { resistance, tolerance };
}

/** Given a resistance value, find the closest 4-band colors */
export function encode4Band(resistance: number): { b1: number; b2: number; multIdx: number } {
  if (resistance <= 0) return { b1: 1, b2: 0, multIdx: 0 };
  let r = resistance;
  let multIdx = 0;

  // Handle small resistances
  if (r < 10) {
    if (r < 1) {
      // Silver multiplier (0.01)
      const scaled = Math.round(r * 100);
      const b1 = Math.min(9, Math.max(0, Math.floor(scaled / 10)));
      const b2 = Math.min(9, Math.max(0, scaled % 10));
      return { b1, b2, multIdx: 11 }; // Silver
    } else {
      // Gold multiplier (0.1)
      const scaled = Math.round(r * 10);
      const b1 = Math.min(9, Math.max(0, Math.floor(scaled / 10)));
      const b2 = Math.min(9, Math.max(0, scaled % 10));
      return { b1, b2, multIdx: 10 }; // Gold
    }
  }

  let exponent = 0;
  while (r >= 100 && exponent < 9) {
    r /= 10;
    exponent++;
  }
  const intVal = Math.round(r);
  const b1 = Math.min(9, Math.max(1, Math.floor(intVal / 10)));
  const b2 = Math.min(9, Math.max(0, intVal % 10));
  multIdx = Math.min(9, Math.max(0, exponent));

  return { b1, b2, multIdx };
}

// -----------------------------------------------------------------------------
// STEP-BY-STEP SERIES, PARALLEL & COMBINATION CIRCUIT SOLVERS
// -----------------------------------------------------------------------------

import { ResistorLedgerItem, ReductionStep, CustomComponent, CustomWire, SimulationResult } from '../types';

/**
 * Step-by-Step Series Circuit Solver
 */
export function solveSeriesCircuit(
  sourceVoltage: number,
  resistors: { id: string; label: string; value: number }[]
): {
  rTotal: number;
  iTotal: number;
  pTotal: number;
  ledger: ResistorLedgerItem[];
  steps: ReductionStep[];
} {
  const rTotal = resistors.reduce((sum, r) => sum + r.value, 0);
  const iTotal = rTotal > 0 ? sourceVoltage / rTotal : 0;
  const pTotal = sourceVoltage * iTotal;

  const ledger: ResistorLedgerItem[] = resistors.map((r) => {
    const vDrop = iTotal * r.value;
    const p = iTotal * vDrop;
    return {
      id: r.id,
      label: r.label,
      resistance: r.value,
      voltage: vDrop,
      current: iTotal,
      power: p,
      formulaV: `V = I_total × R = ${formatCurrent(iTotal)} × ${formatResistance(r.value)}`,
      formulaI: `I = I_total (Series Rule: Current is identical through every element)`,
    };
  });

  const steps: ReductionStep[] = [
    {
      stepNumber: 1,
      badgeTitle: 'Step 1: Series Resistance Rule',
      heading: 'Sum All Series Resistors to Find Total Equivalent Resistance (R_eq)',
      latexFormula: 'R_{total} = R_1 + R_2 + \\dots + R_n',
      calculation: resistors.map((r) => `${r.label} (${formatResistance(r.value)})`).join(' + ') + ` = ${formatResistance(rTotal)}`,
      resultValue: `R_{total} = ${formatResistance(rTotal)}`,
      rationale: 'In a series circuit, charges have only a single pathway. Therefore, the total opposition to current is the arithmetic sum of individual resistances.',
      highlightedComponents: resistors.map((r) => r.id),
    },
    {
      stepNumber: 2,
      badgeTitle: "Step 2: Apply Ohm's Law for Total Current",
      heading: 'Calculate Loop Current (I_total)',
      latexFormula: 'I_{total} = \\frac{V_{source}}{R_{total}}',
      calculation: `${formatVoltage(sourceVoltage)} / ${formatResistance(rTotal)} = ${formatCurrent(iTotal)}`,
      resultValue: `I_{total} = ${formatCurrent(iTotal)}`,
      rationale: 'Ohm’s Law applies to the entire circuit. The loop current is governed by the total supply voltage divided by equivalent resistance.',
      highlightedComponents: ['source', ...resistors.map((r) => r.id)],
    },
    {
      stepNumber: 3,
      badgeTitle: 'Step 3: Voltage Divider Rule & Individual Drops',
      heading: 'Calculate Voltage Drops across Each Resistor (V_n = I × R_n)',
      latexFormula: 'V_x = V_{source} \\times \\frac{R_x}{R_{total}} = I_{total} \\times R_x',
      calculation: resistors
        .map((r) => `${r.label}: ${formatCurrent(iTotal)} × ${formatResistance(r.value)} = ${formatVoltage(iTotal * r.value)}`)
        .join('  |  '),
      resultValue: `KVL Check: ∑ V_n = ${formatVoltage(resistors.reduce((acc, r) => acc + iTotal * r.value, 0))} = V_{source}`,
      rationale: "Kirchhoff's Voltage Law (KVL) confirms that the sum of all individual series voltage drops equals the applied source voltage.",
      highlightedComponents: resistors.map((r) => r.id),
    },
    {
      stepNumber: 4,
      badgeTitle: 'Step 4: Power Dissipation & Joule Heating',
      heading: 'Calculate Individual & Total Power (P = I² × R)',
      latexFormula: 'P = I^2 \\times R = V \\times I',
      calculation: resistors
        .map((r) => `${r.label}: (${formatCurrent(iTotal)})² × ${formatResistance(r.value)} = ${formatPower(iTotal * iTotal * r.value)}`)
        .join('  |  '),
      resultValue: `P_{total} = ${formatPower(pTotal)}`,
      rationale: 'Conservation of energy dictates that total electrical power supplied by the source matches the thermal energy dissipated across all resistors.',
      highlightedComponents: resistors.map((r) => r.id),
    },
  ];

  return { rTotal, iTotal, pTotal, ledger, steps };
}

/**
 * Step-by-Step Parallel Circuit Solver
 */
export function solveParallelCircuit(
  sourceVoltage: number,
  resistors: { id: string; label: string; value: number }[]
): {
  rTotal: number;
  iTotal: number;
  pTotal: number;
  ledger: ResistorLedgerItem[];
  steps: ReductionStep[];
} {
  const reciprocalSum = resistors.reduce((sum, r) => sum + (r.value > 0 ? 1 / r.value : 0), 0);
  const rTotal = reciprocalSum > 0 ? 1 / reciprocalSum : 0;
  const iTotal = rTotal > 0 ? sourceVoltage / rTotal : 0;
  const pTotal = sourceVoltage * iTotal;

  const ledger: ResistorLedgerItem[] = resistors.map((r) => {
    const branchCurrent = r.value > 0 ? sourceVoltage / r.value : 0;
    const branchPower = sourceVoltage * branchCurrent;
    return {
      id: r.id,
      label: r.label,
      resistance: r.value,
      voltage: sourceVoltage,
      current: branchCurrent,
      power: branchPower,
      formulaV: `V = V_source = ${formatVoltage(sourceVoltage)} (Parallel Rule: Constant Voltage across nodes)`,
      formulaI: `I = V / R = ${formatVoltage(sourceVoltage)} / ${formatResistance(r.value)} = ${formatCurrent(branchCurrent)}`,
    };
  });

  const steps: ReductionStep[] = [
    {
      stepNumber: 1,
      badgeTitle: 'Step 1: Parallel Voltage Rule',
      heading: 'Recognize Identical Voltage across All Parallel Branches',
      latexFormula: 'V_{source} = V_1 = V_2 = \\dots = V_n',
      calculation: `Every branch connects directly across the two main common rails: V = ${formatVoltage(sourceVoltage)}`,
      resultValue: `Branch Voltage = ${formatVoltage(sourceVoltage)}`,
      rationale: 'In parallel connections, all components share the exact same two electrical nodes, hence the potential difference across every branch is identical.',
      highlightedComponents: resistors.map((r) => r.id),
    },
    {
      stepNumber: 2,
      badgeTitle: 'Step 2: Reciprocal Resistance Formula',
      heading: 'Calculate Total Equivalent Resistance (R_eq)',
      latexFormula: '\\frac{1}{R_{total}} = \\frac{1}{R_1} + \\frac{1}{R_2} + \\dots + \\frac{1}{R_n}',
      calculation: `1/R_total = ` + resistors.map((r) => `1/${formatResistance(r.value)}`).join(' + ') + ` = ${reciprocalSum.toFixed(5)} S  →  R_total = ${formatResistance(rTotal)}`,
      resultValue: `R_{total} = ${formatResistance(rTotal)} (Always smaller than smallest branch!)`,
      rationale: 'Adding parallel paths provides more channels for charge flow, effectively decreasing the overall equivalent resistance.',
      highlightedComponents: resistors.map((r) => r.id),
    },
    {
      stepNumber: 3,
      badgeTitle: 'Step 3: Branch Currents & Current Divider',
      heading: 'Calculate Individual Branch Currents (I_n = V / R_n)',
      latexFormula: 'I_x = \\frac{V_{source}}{R_x}',
      calculation: resistors
        .map((r) => `${r.label}: ${formatVoltage(sourceVoltage)} / ${formatResistance(r.value)} = ${formatCurrent(sourceVoltage / r.value)}`)
        .join('  |  '),
      resultValue: `KCL Check: ∑ I_{branches} = ${formatCurrent(resistors.reduce((acc, r) => acc + sourceVoltage / r.value, 0))} = I_{total}`,
      rationale: "Kirchhoff's Current Law (KCL) confirms that total current entering the junction equals the sum of currents leaving through all branches.",
      highlightedComponents: resistors.map((r) => r.id),
    },
    {
      stepNumber: 4,
      badgeTitle: 'Step 4: Branch & Total Power',
      heading: 'Calculate Branch Power (P = V² / R)',
      latexFormula: 'P_x = \\frac{V^2}{R_x} = V \\times I_x',
      calculation: resistors
        .map((r) => `${r.label}: (${formatVoltage(sourceVoltage)})² / ${formatResistance(r.value)} = ${formatPower((sourceVoltage * sourceVoltage) / r.value)}`)
        .join('  |  '),
      resultValue: `P_{total} = ${formatPower(pTotal)}`,
      rationale: 'Branches with lower resistance draw higher current and therefore dissipate proportionally greater power.',
      highlightedComponents: resistors.map((r) => r.id),
    },
  ];

  return { rTotal, iTotal, pTotal, ledger, steps };
}

/**
 * Step-by-Step Series-Parallel Combination Solver: R1 in series with (R2 || R3)
 */
export function solveSeriesParallelCombo(
  voltage: number,
  r1: number,
  r2: number,
  r3: number
): {
  rTotal: number;
  iTotal: number;
  pTotal: number;
  rParallel23: number;
  v1: number;
  vParallel: number;
  i1: number;
  i2: number;
  i3: number;
  ledger: ResistorLedgerItem[];
  steps: ReductionStep[];
} {
  // Step 1: Simplify parallel block (R2 || R3)
  const rParallel23 = (r2 * r3) / Math.max(0.001, r2 + r3);
  // Step 2: Add series resistor R1
  const rTotal = r1 + rParallel23;
  // Step 3: Total current
  const iTotal = rTotal > 0 ? voltage / rTotal : 0;
  const pTotal = voltage * iTotal;

  // Step 4: Work backwards for branch values
  const i1 = iTotal;
  const v1 = i1 * r1;
  const vParallel = voltage - v1; // Or iTotal * rParallel23
  const i2 = r2 > 0 ? vParallel / r2 : 0;
  const i3 = r3 > 0 ? vParallel / r3 : 0;

  const p1 = v1 * i1;
  const p2 = vParallel * i2;
  const p3 = vParallel * i3;

  const ledger: ResistorLedgerItem[] = [
    {
      id: 'r1',
      label: 'R1 (Series Trunk)',
      resistance: r1,
      voltage: v1,
      current: i1,
      power: p1,
      formulaV: `V1 = I_total × R1 = ${formatCurrent(i1)} × ${formatResistance(r1)} = ${formatVoltage(v1)}`,
      formulaI: `I1 = I_total = ${formatCurrent(i1)} (Carries full loop current)`,
    },
    {
      id: 'r2',
      label: 'R2 (Parallel Branch A)',
      resistance: r2,
      voltage: vParallel,
      current: i2,
      power: p2,
      formulaV: `V2 = V_parallel = V_source - V1 = ${formatVoltage(voltage)} - ${formatVoltage(v1)} = ${formatVoltage(vParallel)}`,
      formulaI: `I2 = V_parallel / R2 = ${formatVoltage(vParallel)} / ${formatResistance(r2)} = ${formatCurrent(i2)}`,
    },
    {
      id: 'r3',
      label: 'R3 (Parallel Branch B)',
      resistance: r3,
      voltage: vParallel,
      current: i3,
      power: p3,
      formulaV: `V3 = V_parallel = ${formatVoltage(vParallel)} (Shares same node with R2)`,
      formulaI: `I3 = V_parallel / R3 = ${formatVoltage(vParallel)} / ${formatResistance(r3)} = ${formatCurrent(i3)}`,
    },
  ];

  const steps: ReductionStep[] = [
    {
      stepNumber: 1,
      badgeTitle: 'Stage 1: Reduce Innermost Parallel Group',
      heading: 'Combine R2 and R3 into Equivalent Parallel Resistor (R_p)',
      latexFormula: 'R_{23} = \\frac{R_2 \\times R_3}{R_2 + R_3}',
      calculation: `(${formatResistance(r2)} × ${formatResistance(r3)}) / (${formatResistance(r2)} + ${formatResistance(r3)}) = ${formatResistance(rParallel23)}`,
      resultValue: `R_{23} = ${formatResistance(rParallel23)}`,
      rationale: 'Always start with the innermost sub-circuits. Here, R2 and R3 are connected in pure parallel across the same two junctions.',
      highlightedComponents: ['r2', 'r3'],
    },
    {
      stepNumber: 2,
      badgeTitle: 'Stage 2: Reduce Remaining Series Chain',
      heading: 'Sum R1 with the Equivalent R23 for Total Circuit Resistance',
      latexFormula: 'R_{total} = R_1 + R_{23}',
      calculation: `${formatResistance(r1)} + ${formatResistance(rParallel23)} = ${formatResistance(rTotal)}`,
      resultValue: `R_{total} = ${formatResistance(rTotal)}`,
      rationale: 'After replacing (R2 || R3) with R23, the entire circuit collapses into a simple single-loop series circuit of R1 + R23.',
      highlightedComponents: ['r1', 'r2', 'r3'],
    },
    {
      stepNumber: 3,
      badgeTitle: 'Stage 3: Calculate Total Source Current',
      heading: 'Apply Ohm’s Law across the Collapsed Circuit',
      latexFormula: 'I_{total} = \\frac{V_{source}}{R_{total}}',
      calculation: `${formatVoltage(voltage)} / ${formatResistance(rTotal)} = ${formatCurrent(iTotal)}`,
      resultValue: `I_{total} = ${formatCurrent(iTotal)} (Flows through R1)`,
      rationale: 'Total current leaving the battery enters R1 in its entirety before splitting at the parallel junction.',
      highlightedComponents: ['source', 'r1'],
    },
    {
      stepNumber: 4,
      badgeTitle: 'Stage 4: Expand Outward (KVL Node Voltages)',
      heading: 'Find Voltage Drop on R1 and Remaining Junction Voltage for R2 & R3',
      latexFormula: 'V_1 = I_{total} \\times R_1, \\quad V_{p} = V_{source} - V_1',
      calculation: `V1 = ${formatCurrent(iTotal)} × ${formatResistance(r1)} = ${formatVoltage(v1)}  →  V_parallel = ${formatVoltage(voltage)} - ${formatVoltage(v1)} = ${formatVoltage(vParallel)}`,
      resultValue: `V_{R1} = ${formatVoltage(v1)}, \\quad V_{R2} = V_{R3} = ${formatVoltage(vParallel)}`,
      rationale: 'KVL mandates that the source voltage is partitioned between R1 and the parallel block: V_source = V1 + V_parallel.',
      highlightedComponents: ['r1', 'r2', 'r3'],
    },
    {
      stepNumber: 5,
      badgeTitle: 'Stage 5: Branch Current Division (KCL)',
      heading: 'Calculate Individual Currents in Parallel Branches R2 and R3',
      latexFormula: 'I_2 = \\frac{V_{p}}{R_2}, \\quad I_3 = \\frac{V_{p}}{R_3}',
      calculation: `I2 = ${formatVoltage(vParallel)} / ${formatResistance(r2)} = ${formatCurrent(i2)}  |  I3 = ${formatVoltage(vParallel)} / ${formatResistance(r3)} = ${formatCurrent(i3)}`,
      resultValue: `KCL Verification: I2 (${formatCurrent(i2)}) + I3 (${formatCurrent(i3)}) = ${formatCurrent(i2 + i3)} = I_{total}`,
      rationale: 'At the junction, total current I_total splits inversely proportional to branch resistance, precisely obeying KCL.',
      highlightedComponents: ['r2', 'r3'],
    },
  ];

  return {
    rTotal,
    iTotal,
    pTotal,
    rParallel23,
    v1,
    vParallel,
    i1,
    i2,
    i3,
    ledger,
    steps,
  };
}

/**
 * Step-by-Step Parallel-Series Combo Solver: (R1 + R2) in parallel with (R3 + R4)
 */
export function solveParallelSeriesCombo(
  voltage: number,
  r1: number,
  r2: number,
  r3: number,
  r4: number
): {
  rTotal: number;
  iTotal: number;
  pTotal: number;
  rBranchA: number;
  rBranchB: number;
  iA: number;
  iB: number;
  ledger: ResistorLedgerItem[];
  steps: ReductionStep[];
} {
  const rBranchA = r1 + r2;
  const rBranchB = r3 + r4;
  const rTotal = (rBranchA * rBranchB) / Math.max(0.001, rBranchA + rBranchB);
  const iTotal = rTotal > 0 ? voltage / rTotal : 0;
  const pTotal = voltage * iTotal;

  const iA = rBranchA > 0 ? voltage / rBranchA : 0;
  const iB = rBranchB > 0 ? voltage / rBranchB : 0;

  const v1 = iA * r1;
  const v2 = iA * r2;
  const v3 = iB * r3;
  const v4 = iB * r4;

  const ledger: ResistorLedgerItem[] = [
    {
      id: 'r1',
      label: 'R1 (Branch A Top)',
      resistance: r1,
      voltage: v1,
      current: iA,
      power: v1 * iA,
      formulaV: `V1 = IA × R1 = ${formatCurrent(iA)} × ${formatResistance(r1)} = ${formatVoltage(v1)}`,
      formulaI: `I1 = IA = ${formatCurrent(iA)}`,
    },
    {
      id: 'r2',
      label: 'R2 (Branch A Bottom)',
      resistance: r2,
      voltage: v2,
      current: iA,
      power: v2 * iA,
      formulaV: `V2 = IA × R2 = ${formatCurrent(iA)} × ${formatResistance(r2)} = ${formatVoltage(v2)}`,
      formulaI: `I2 = IA = ${formatCurrent(iA)}`,
    },
    {
      id: 'r3',
      label: 'R3 (Branch B Top)',
      resistance: r3,
      voltage: v3,
      current: iB,
      power: v3 * iB,
      formulaV: `V3 = IB × R3 = ${formatCurrent(iB)} × ${formatResistance(r3)} = ${formatVoltage(v3)}`,
      formulaI: `I3 = IB = ${formatCurrent(iB)}`,
    },
    {
      id: 'r4',
      label: 'R4 (Branch B Bottom)',
      resistance: r4,
      voltage: v4,
      current: iB,
      power: v4 * iB,
      formulaV: `V4 = IB × R4 = ${formatCurrent(iB)} × ${formatResistance(r4)} = ${formatVoltage(v4)}`,
      formulaI: `I4 = IB = ${formatCurrent(iB)}`,
    },
  ];

  const steps: ReductionStep[] = [
    {
      stepNumber: 1,
      badgeTitle: 'Stage 1: Simplify Series Chains in Each Branch',
      heading: 'Sum Series Resistors in Branch A (R1+R2) and Branch B (R3+R4)',
      latexFormula: 'R_A = R_1 + R_2, \\quad R_B = R_3 + R_4',
      calculation: `Branch A: ${formatResistance(r1)} + ${formatResistance(r2)} = ${formatResistance(rBranchA)}  |  Branch B: ${formatResistance(r3)} + ${formatResistance(r4)} = ${formatResistance(rBranchB)}`,
      resultValue: `R_A = ${formatResistance(rBranchA)}, \\quad R_B = ${formatResistance(rBranchB)}`,
      rationale: 'Each branch is an independent series circuit connected in parallel across the main supply rails.',
      highlightedComponents: ['r1', 'r2', 'r3', 'r4'],
    },
    {
      stepNumber: 2,
      badgeTitle: 'Stage 2: Combine Parallel Branches',
      heading: 'Calculate Equivalent Total Resistance (R_eq = R_A || R_B)',
      latexFormula: 'R_{total} = \\frac{R_A \\times R_B}{R_A + R_B}',
      calculation: `(${formatResistance(rBranchA)} × ${formatResistance(rBranchB)}) / (${formatResistance(rBranchA)} + ${formatResistance(rBranchB)}) = ${formatResistance(rTotal)}`,
      resultValue: `R_{total} = ${formatResistance(rTotal)}`,
      rationale: 'Both series branches are wired in parallel across the power supply.',
      highlightedComponents: ['r1', 'r2', 'r3', 'r4'],
    },
    {
      stepNumber: 3,
      badgeTitle: 'Stage 3: Calculate Branch Currents',
      heading: 'Branch Currents from Full Supply Voltage',
      latexFormula: 'I_A = \\frac{V}{R_A}, \\quad I_B = \\frac{V}{R_B}, \\quad I_{total} = I_A + I_B',
      calculation: `IA = ${formatVoltage(voltage)} / ${formatResistance(rBranchA)} = ${formatCurrent(iA)}  |  IB = ${formatVoltage(voltage)} / ${formatResistance(rBranchB)} = ${formatCurrent(iB)}`,
      resultValue: `I_{total} = ${formatCurrent(iTotal)}`,
      rationale: 'Because both branches receive the full supply voltage, their currents are independently determined.',
      highlightedComponents: ['r1', 'r2', 'r3', 'r4'],
    },
    {
      stepNumber: 4,
      badgeTitle: 'Stage 4: Series Voltage Drops within Branches',
      heading: 'Calculate Individual Voltages (V = I × R)',
      latexFormula: 'V_1 = I_A R_1, \\, V_2 = I_A R_2, \\, V_3 = I_B R_3, \\, V_4 = I_B R_4',
      calculation: `V1 = ${formatVoltage(v1)}, V2 = ${formatVoltage(v2)} (Sum = ${formatVoltage(v1 + v2)}) | V3 = ${formatVoltage(v3)}, V4 = ${formatVoltage(v4)} (Sum = ${formatVoltage(v3 + v4)})`,
      resultValue: 'Verified: Both branches satisfy KVL and KCL',
      rationale: 'The voltage drops across R1 and R2 add up to V_source, and R3 and R4 also sum to V_source.',
      highlightedComponents: ['r1', 'r2', 'r3', 'r4'],
    },
  ];

  return { rTotal, iTotal, pTotal, rBranchA, rBranchB, iA, iB, ledger, steps };
}

/**
 * Step-by-Step 5-Resistor Ladder Network Solver: R1 + [R2 || (R3 + [R4 || R5])]
 */
export function solveLadderCombo(
  voltage: number,
  r1: number,
  r2: number,
  r3: number,
  r4: number,
  r5: number
): {
  rTotal: number;
  iTotal: number;
  pTotal: number;
  ledger: ResistorLedgerItem[];
  steps: ReductionStep[];
} {
  // Stage 1: R4 || R5
  const r45 = (r4 * r5) / Math.max(0.001, r4 + r5);
  // Stage 2: R3 + R45
  const r345 = r3 + r45;
  // Stage 3: R2 || R345
  const r2345 = (r2 * r345) / Math.max(0.001, r2 + r345);
  // Stage 4: R1 + R2345
  const rTotal = r1 + r2345;

  const iTotal = rTotal > 0 ? voltage / rTotal : 0;
  const pTotal = voltage * iTotal;

  // Expanding voltages & currents:
  const i1 = iTotal;
  const v1 = i1 * r1;
  const vNodeA = voltage - v1; // voltage across R2 and R345 branch

  const i2 = r2 > 0 ? vNodeA / r2 : 0;
  const i345 = r345 > 0 ? vNodeA / r345 : 0;

  const i3 = i345;
  const v3 = i3 * r3;
  const vNodeB = vNodeA - v3; // voltage across R4 and R5

  const i4 = r4 > 0 ? vNodeB / r4 : 0;
  const i5 = r5 > 0 ? vNodeB / r5 : 0;

  const ledger: ResistorLedgerItem[] = [
    {
      id: 'r1',
      label: 'R1 (Input Series Trunk)',
      resistance: r1,
      voltage: v1,
      current: i1,
      power: v1 * i1,
      formulaV: `V1 = I_total × R1 = ${formatCurrent(i1)} × ${formatResistance(r1)} = ${formatVoltage(v1)}`,
      formulaI: `I1 = I_total = ${formatCurrent(i1)}`,
    },
    {
      id: 'r2',
      label: 'R2 (First Shunt Resistor)',
      resistance: r2,
      voltage: vNodeA,
      current: i2,
      power: vNodeA * i2,
      formulaV: `V2 = V_nodeA = ${formatVoltage(vNodeA)}`,
      formulaI: `I2 = V_nodeA / R2 = ${formatCurrent(i2)}`,
    },
    {
      id: 'r3',
      label: 'R3 (Second Series Arm)',
      resistance: r3,
      voltage: v3,
      current: i3,
      power: v3 * i3,
      formulaV: `V3 = I3 × R3 = ${formatVoltage(v3)}`,
      formulaI: `I3 = V_nodeA / R345 = ${formatCurrent(i3)}`,
    },
    {
      id: 'r4',
      label: 'R4 (Termination Shunt A)',
      resistance: r4,
      voltage: vNodeB,
      current: i4,
      power: vNodeB * i4,
      formulaV: `V4 = V_nodeB = ${formatVoltage(vNodeB)}`,
      formulaI: `I4 = V_nodeB / R4 = ${formatCurrent(i4)}`,
    },
    {
      id: 'r5',
      label: 'R5 (Termination Shunt B)',
      resistance: r5,
      voltage: vNodeB,
      current: i5,
      power: vNodeB * i5,
      formulaV: `V5 = V_nodeB = ${formatVoltage(vNodeB)}`,
      formulaI: `I5 = V_nodeB / R5 = ${formatCurrent(i5)}`,
    },
  ];

  const steps: ReductionStep[] = [
    {
      stepNumber: 1,
      badgeTitle: 'Stage 1: Furthest Parallel Branch (Rightmost)',
      heading: 'Combine R4 and R5 in Parallel',
      latexFormula: 'R_{45} = \\frac{R_4 \\times R_5}{R_4 + R_5}',
      calculation: `(${formatResistance(r4)} × ${formatResistance(r5)}) / (${formatResistance(r4)} + ${formatResistance(r5)}) = ${formatResistance(r45)}`,
      resultValue: `R_{45} = ${formatResistance(r45)}`,
      rationale: 'In ladder networks, always reduce from the furthest point opposite the source back toward the source.',
      highlightedComponents: ['r4', 'r5'],
    },
    {
      stepNumber: 2,
      badgeTitle: 'Stage 2: Series Addition with R3',
      heading: 'Add R3 in Series with R45',
      latexFormula: 'R_{345} = R_3 + R_{45}',
      calculation: `${formatResistance(r3)} + ${formatResistance(r45)} = ${formatResistance(r345)}`,
      resultValue: `R_{345} = ${formatResistance(r345)}`,
      rationale: 'The combined R45 block sits directly in series with R3.',
      highlightedComponents: ['r3', 'r4', 'r5'],
    },
    {
      stepNumber: 3,
      badgeTitle: 'Stage 3: Shunt Parallel with R2',
      heading: 'Combine R2 in Parallel with R345',
      latexFormula: 'R_{2345} = \\frac{R_2 \\times R_{345}}{R_2 + R_{345}}',
      calculation: `(${formatResistance(r2)} × ${formatResistance(r345)}) / (${formatResistance(r2)} + ${formatResistance(r345)}) = ${formatResistance(r2345)}`,
      resultValue: `R_{2345} = ${formatResistance(r2345)}`,
      rationale: 'The entire right block is in parallel across shunt resistor R2.',
      highlightedComponents: ['r2', 'r3', 'r4', 'r5'],
    },
    {
      stepNumber: 4,
      badgeTitle: 'Stage 4: Input Series Sum with R1',
      heading: 'Add Series Input Resistor R1 for Total Circuit Resistance',
      latexFormula: 'R_{total} = R_1 + R_{2345}',
      calculation: `${formatResistance(r1)} + ${formatResistance(r2345)} = ${formatResistance(rTotal)}`,
      resultValue: `R_{total} = ${formatResistance(rTotal)}  |  I_{total} = ${formatCurrent(iTotal)}`,
      rationale: 'The entire ladder simplifies to a single equivalent resistance R_total.',
      highlightedComponents: ['r1', 'r2', 'r3', 'r4', 'r5'],
    },
    {
      stepNumber: 5,
      badgeTitle: 'Stage 5: Back-Propagation of Node Voltages & Currents',
      heading: 'Calculate Voltages at Node A and Node B',
      latexFormula: 'V_A = V_{source} - I_{total} R_1, \\quad V_B = V_A - I_3 R_3',
      calculation: `Node A = ${formatVoltage(vNodeA)}  →  Node B = ${formatVoltage(vNodeB)}`,
      resultValue: `Branch Currents: I1=${formatCurrent(i1)}, I2=${formatCurrent(i2)}, I3=${formatCurrent(i3)}, I4=${formatCurrent(i4)}, I5=${formatCurrent(i5)}`,
      rationale: 'Each stage attenuates voltage down the ladder line, forming a multi-stage voltage divider.',
      highlightedComponents: ['r1', 'r2', 'r3', 'r4', 'r5'],
    },
  ];

  return { rTotal, iTotal, pTotal, ledger, steps };
}

/**
 * Step-by-Step Wheatstone Bridge Network Solver
 */
export function solveWheatstoneBridge(
  voltage: number,
  r1: number,
  r2: number,
  r3: number,
  r4: number
): {
  vA: number;
  vB: number;
  vBridge: number;
  isBalanced: boolean;
  rTotal: number;
  iTotal: number;
  pTotal: number;
  ledger: ResistorLedgerItem[];
  steps: ReductionStep[];
} {
  // Left divider node A: across R2 (where R1 is top, R2 is bottom)
  const vA = voltage * (r2 / Math.max(0.001, r1 + r2));
  // Right divider node B: across R4 (where R3 is top, R4 is bottom)
  const vB = voltage * (r4 / Math.max(0.001, r3 + r4));
  const vBridge = vA - vB; // Detector voltage

  const ratioLeft = r1 / Math.max(0.001, r2);
  const ratioRight = r3 / Math.max(0.001, r4);
  const isBalanced = Math.abs(ratioLeft - ratioRight) < 0.001;

  // Unloaded bridge total equivalent resistance
  const rLeft = r1 + r2;
  const rRight = r3 + r4;
  const rTotal = (rLeft * rRight) / Math.max(0.001, rLeft + rRight);
  const iTotal = rTotal > 0 ? voltage / rTotal : 0;
  const pTotal = voltage * iTotal;

  const iLeft = voltage / rLeft;
  const iRight = voltage / rRight;

  const v1 = iLeft * r1;
  const v2 = iLeft * r2;
  const v3 = iRight * r3;
  const v4 = iRight * r4;

  const ledger: ResistorLedgerItem[] = [
    {
      id: 'r1',
      label: 'R1 (Left Upper Arm)',
      resistance: r1,
      voltage: v1,
      current: iLeft,
      power: v1 * iLeft,
      formulaV: `V1 = Vin × (R1 / (R1+R2)) = ${formatVoltage(v1)}`,
      formulaI: `I1 = Vin / (R1+R2) = ${formatCurrent(iLeft)}`,
    },
    {
      id: 'r2',
      label: 'R2 (Left Lower Arm / Node A)',
      resistance: r2,
      voltage: v2,
      current: iLeft,
      power: v2 * iLeft,
      formulaV: `V2 = Node A = Vin × (R2 / (R1+R2)) = ${formatVoltage(vA)}`,
      formulaI: `I2 = I_left = ${formatCurrent(iLeft)}`,
    },
    {
      id: 'r3',
      label: 'R3 (Right Upper Arm)',
      resistance: r3,
      voltage: v3,
      current: iRight,
      power: v3 * iRight,
      formulaV: `V3 = Vin × (R3 / (R3+R4)) = ${formatVoltage(v3)}`,
      formulaI: `I3 = Vin / (R3+R4) = ${formatCurrent(iRight)}`,
    },
    {
      id: 'r4',
      label: 'R4 (Right Lower Arm / Node B)',
      resistance: r4,
      voltage: v4,
      current: iRight,
      power: v4 * iRight,
      formulaV: `V4 = Node B = Vin × (R4 / (R3+R4)) = ${formatVoltage(vB)}`,
      formulaI: `I4 = I_right = ${formatCurrent(iRight)}`,
    },
  ];

  const steps: ReductionStep[] = [
    {
      stepNumber: 1,
      badgeTitle: 'Stage 1: Left Leg Voltage Divider (Node A)',
      heading: 'Calculate Potential at Midpoint Node A',
      latexFormula: 'V_A = V_{in} \\times \\left( \\frac{R_2}{R_1 + R_2} \\right)',
      calculation: `${formatVoltage(voltage)} × (${formatResistance(r2)} / (${formatResistance(r1)} + ${formatResistance(r2)})) = ${formatVoltage(vA)}`,
      resultValue: `V_A = ${formatVoltage(vA)}`,
      rationale: 'The left leg is an independent voltage divider formed by series resistors R1 and R2 across Vin.',
      highlightedComponents: ['r1', 'r2'],
    },
    {
      stepNumber: 2,
      badgeTitle: 'Stage 2: Right Leg Voltage Divider (Node B)',
      heading: 'Calculate Potential at Midpoint Node B',
      latexFormula: 'V_B = V_{in} \\times \\left( \\frac{R_4}{R_3 + R_4} \\right)',
      calculation: `${formatVoltage(voltage)} × (${formatResistance(r4)} / (${formatResistance(r3)} + ${formatResistance(r4)})) = ${formatVoltage(vB)}`,
      resultValue: `V_B = ${formatVoltage(vB)}`,
      rationale: 'The right leg is an identical voltage divider formed by series resistors R3 and R4 across Vin.',
      highlightedComponents: ['r3', 'r4'],
    },
    {
      stepNumber: 3,
      badgeTitle: 'Stage 3: Bridge Differential Voltage (V_AB)',
      heading: 'Calculate Potential Difference across the Detector Terminals',
      latexFormula: 'V_{bridge} = V_A - V_B = V_{in} \\left( \\frac{R_2}{R_1 + R_2} - \\frac{R_4}{R_3 + R_4} \\right)',
      calculation: `${formatVoltage(vA)} - ${formatVoltage(vB)} = ${formatVoltage(vBridge)}`,
      resultValue: `V_{bridge} = ${formatVoltage(vBridge)}  (${isBalanced ? 'BALANCED 0V' : 'UNBALANCED'})`,
      rationale: 'When R1/R2 = R3/R4, V_A equals V_B, and zero current flows between nodes A and B.',
      highlightedComponents: ['r1', 'r2', 'r3', 'r4'],
    },
    {
      stepNumber: 4,
      badgeTitle: 'Stage 4: Bridge Balance Condition Check',
      heading: 'Ratio Equation: R1 / R2 == R3 / R4',
      latexFormula: '\\frac{R_1}{R_2} = \\frac{R_3}{R_4} \\implies R_1 R_4 = R_2 R_3',
      calculation: `(${formatResistance(r1)} / ${formatResistance(r2)} = ${ratioLeft.toFixed(3)}) vs (${formatResistance(r3)} / ${formatResistance(r4)} = ${ratioRight.toFixed(3)})`,
      resultValue: isBalanced ? 'Bridge is Perfectly Balanced (Null Detector = 0.000V)' : 'Bridge is Unbalanced (Current flows across bridge)',
      rationale: 'The Wheatstone bridge principle enables ultra-precise unknown resistance and sensor measurements by tuning until V_bridge = 0.',
      highlightedComponents: ['r1', 'r2', 'r3', 'r4'],
    },
  ];

  return { vA, vB, vBridge, isBalanced, rTotal, iTotal, pTotal, ledger, steps };
}

// -----------------------------------------------------------------------------
// GENERALIZED NODAL CIRCUIT SIMULATION ENGINE FOR CUSTOM DESIGNER
// -----------------------------------------------------------------------------

/**
 * Solves arbitrary custom circuit graph with Modified Nodal Analysis (MNA)
 */
export function simulateCustomCircuit(
  components: CustomComponent[],
  wires: CustomWire[]
): SimulationResult {
  const result: SimulationResult = {
    nodeVoltages: {},
    componentCurrents: {},
    componentVoltages: {},
    componentPowers: {},
    wireCurrents: {},
    totalSourcePower: 0,
    totalEquivalentResistance: 0,
    isShortCircuit: false,
    blownFuses: [],
  };

  if (components.length === 0) return result;

  // 1. Build Pin connectivity graph using Union-Find to group pins into electrical nodes
  const parent: Record<string, string> = {};
  const find = (i: string): string => {
    if (!parent[i]) parent[i] = i;
    if (parent[i] === i) return i;
    parent[i] = find(parent[i]);
    return parent[i];
  };
  const union = (i: string, j: string) => {
    const rootI = find(i);
    const rootJ = find(j);
    if (rootI !== rootJ) parent[rootI] = rootJ;
  };

  // Register all component pins
  components.forEach((c) => {
    const pins = getComponentPinList(c.type);
    pins.forEach((p) => {
      const pinKey = `${c.id}:${p.id}`;
      parent[pinKey] = pinKey;
    });
  });

  // Connect pins through wires
  wires.forEach((w) => {
    const pin1 = `${w.fromCompId}:${w.fromPinId}`;
    const pin2 = `${w.toCompId}:${w.toPinId}`;
    union(pin1, pin2);
  });

  // Map each pin to its root node ID
  const pinNodeMap: Record<string, string> = {};
  const uniqueNodes = new Set<string>();

  Object.keys(parent).forEach((pinKey) => {
    const rootNode = find(pinKey);
    pinNodeMap[pinKey] = rootNode;
    uniqueNodes.add(rootNode);
  });

  const nodeList = Array.from(uniqueNodes);
  if (nodeList.length === 0) return result;

  // Designate ground node: Check if Ground component is placed, or use neg pin of first DC source
  let groundNode = nodeList[0];
  const gndComp = components.find((c) => c.type === 'ground');
  if (gndComp) {
    groundNode = pinNodeMap[`${gndComp.id}:gnd`] || groundNode;
  } else {
    const firstSource = components.find((c) => c.type === 'dc_source');
    if (firstSource) {
      groundNode = pinNodeMap[`${firstSource.id}:neg`] || groundNode;
    }
  }

  // Assign index 0..N-1 to non-ground nodes
  const nonGndNodes = nodeList.filter((n) => n !== groundNode);
  const nodeIdxMap: Record<string, number> = {};
  nonGndNodes.forEach((n, idx) => {
    nodeIdxMap[n] = idx;
  });

  const n = nonGndNodes.length;
  // Count independent voltage sources
  const voltageSources = components.filter((c) => c.type === 'dc_source');
  const m = voltageSources.length;

  if (m === 0) {
    // No active voltage source in circuit
    nodeList.forEach((n) => {
      result.nodeVoltages[n] = 0;
    });
    return result;
  }

  const matrixSize = n + m;
  const A: number[][] = Array.from({ length: matrixSize }, () => Array(matrixSize).fill(0));
  const z: number[] = Array(matrixSize).fill(0);

  // Helper to add conductance between two nodes
  const addConductance = (nodeA: string, nodeB: string, g: number) => {
    if (nodeA === nodeB || g === 0) return;
    const idxA = nodeIdxMap[nodeA];
    const idxB = nodeIdxMap[nodeB];

    if (idxA !== undefined) A[idxA][idxA] += g;
    if (idxB !== undefined) A[idxB][idxB] += g;
    if (idxA !== undefined && idxB !== undefined) {
      A[idxA][idxB] -= g;
      A[idxB][idxA] -= g;
    }
  };

  // Populate passive components (Resistors, Bulbs, LEDs, Switches, Fuses, Meters)
  components.forEach((c) => {
    if (c.type === 'dc_source' || c.type === 'ground') return;

    let r = 100;
    if (c.type === 'resistor') {
      r = Math.max(0.01, c.value);
    } else if (c.type === 'bulb') {
      r = Math.max(1, c.value || 24);
    } else if (c.type === 'led') {
      r = Math.max(10, (c.extra?.forwardVoltage || 2.0) / 0.02);
    } else if (c.type === 'switch') {
      const isClosed = c.extra?.switchClosed ?? true;
      r = isClosed ? 0.001 : 1e9; // 1 mΩ or 1 GΩ
    } else if (c.type === 'fuse') {
      const isBlown = c.extra?.fuseBlown ?? false;
      r = isBlown ? 1e9 : 0.005; // 5 mΩ
    } else if (c.type === 'voltmeter') {
      r = 1e7; // 10 MΩ input impedance
    } else if (c.type === 'ammeter') {
      r = 0.001; // 1 mΩ shunt
    }

    const g = 1 / r;
    const pin1 = pinNodeMap[`${c.id}:p1`] || pinNodeMap[`${c.id}:anode`] || pinNodeMap[`${c.id}:pos`] || pinNodeMap[`${c.id}:in`];
    const pin2 = pinNodeMap[`${c.id}:p2`] || pinNodeMap[`${c.id}:cathode`] || pinNodeMap[`${c.id}:neg`] || pinNodeMap[`${c.id}:out`];

    if (pin1 && pin2) {
      addConductance(pin1, pin2, g);
    }
  });

  // Populate independent voltage sources (B and C submatrices)
  voltageSources.forEach((vs, k) => {
    const vVal = vs.value;
    const pinPos = pinNodeMap[`${vs.id}:pos`];
    const pinNeg = pinNodeMap[`${vs.id}:neg`];

    const idxPos = nodeIdxMap[pinPos];
    const idxNeg = nodeIdxMap[pinNeg];
    const row = n + k;

    if (idxPos !== undefined) {
      A[idxPos][row] += 1;
      A[row][idxPos] += 1;
    }
    if (idxNeg !== undefined) {
      A[idxNeg][row] -= 1;
      A[row][idxNeg] -= 1;
    }

    z[row] = vVal;
  });

  // Solve system A * x = z using Gaussian elimination
  const solution = solveLinearSystem(A, z);

  // Map solution to node voltages
  result.nodeVoltages[groundNode] = 0;
  nonGndNodes.forEach((nodeId, idx) => {
    result.nodeVoltages[nodeId] = solution[idx] ?? 0;
  });

  // Extract source currents and calculate component drops
  voltageSources.forEach((vs, k) => {
    const srcCurrent = Math.abs(solution[n + k] ?? 0);
    result.componentCurrents[vs.id] = srcCurrent;
    result.componentVoltages[vs.id] = vs.value;
    result.componentPowers[vs.id] = vs.value * srcCurrent;
    result.totalSourcePower += vs.value * srcCurrent;

    if (srcCurrent > 0.0001) {
      result.totalEquivalentResistance = vs.value / srcCurrent;
    }
  });

  // Calculate passive component values
  components.forEach((c) => {
    if (c.type === 'dc_source' || c.type === 'ground') return;

    const pin1 = pinNodeMap[`${c.id}:p1`] || pinNodeMap[`${c.id}:anode`] || pinNodeMap[`${c.id}:pos`] || pinNodeMap[`${c.id}:in`];
    const pin2 = pinNodeMap[`${c.id}:p2`] || pinNodeMap[`${c.id}:cathode`] || pinNodeMap[`${c.id}:neg`] || pinNodeMap[`${c.id}:out`];

    const v1 = result.nodeVoltages[pin1] || 0;
    const v2 = result.nodeVoltages[pin2] || 0;
    const vDrop = Math.abs(v1 - v2);

    let r = c.value || 100;
    if (c.type === 'bulb') r = c.value || 24;
    if (c.type === 'led') r = 100;
    if (c.type === 'switch') r = (c.extra?.switchClosed ?? true) ? 0.001 : 1e9;
    if (c.type === 'fuse') r = (c.extra?.fuseBlown ?? false) ? 1e9 : 0.005;
    if (c.type === 'ammeter') r = 0.001;
    if (c.type === 'voltmeter') r = 1e7;

    const current = r > 0 ? vDrop / r : 0;
    const power = vDrop * current;

    result.componentVoltages[c.id] = vDrop;
    result.componentCurrents[c.id] = current;
    result.componentPowers[c.id] = power;

    // Check if fuse blows
    if (c.type === 'fuse' && current > (c.value || 1.0)) {
      result.blownFuses.push(c.id);
    }
  });

  // Wire currents
  wires.forEach((w) => {
    const compA = components.find((c) => c.id === w.fromCompId);
    if (compA) {
      result.wireCurrents[w.id] = result.componentCurrents[compA.id] || 0;
    }
  });

  return result;
}

/**
 * Return pin configurations for component types
 */
export function getComponentPinList(type: string): { id: string; label: string; relX: number; relY: number }[] {
  switch (type) {
    case 'dc_source':
      return [
        { id: 'pos', label: '+', relX: 0, relY: -1 },
        { id: 'neg', label: '-', relX: 0, relY: 1 },
      ];
    case 'ground':
      return [{ id: 'gnd', label: '⏚', relX: 0, relY: -0.8 }];
    case 'led':
      return [
        { id: 'anode', label: '+', relX: -1.2, relY: 0 },
        { id: 'cathode', label: '-', relX: 1.2, relY: 0 },
      ];
    case 'voltmeter':
      return [
        { id: 'pos', label: 'V+', relX: -1.2, relY: 0 },
        { id: 'neg', label: 'COM', relX: 1.2, relY: 0 },
      ];
    case 'ammeter':
      return [
        { id: 'in', label: 'A+', relX: -1.2, relY: 0 },
        { id: 'out', label: 'A-', relX: 1.2, relY: 0 },
      ];
    default:
      // Resistor, bulb, switch, fuse
      return [
        { id: 'p1', label: '1', relX: -1.2, relY: 0 },
        { id: 'p2', label: '2', relX: 1.2, relY: 0 },
      ];
  }
}

/**
 * Solves A * x = b with partial pivoting Gaussian elimination
 */
function solveLinearSystem(A: number[][], b: number[]): number[] {
  const n = b.length;
  const M: number[][] = A.map((row, i) => [...row, b[i]]);

  for (let i = 0; i < n; i++) {
    // Find pivot
    let maxRow = i;
    for (let k = i + 1; k < n; k++) {
      if (Math.abs(M[k][i]) > Math.abs(M[maxRow][i])) {
        maxRow = k;
      }
    }
    // Swap rows
    const temp = M[i];
    M[i] = M[maxRow];
    M[maxRow] = temp;

    if (Math.abs(M[i][i]) < 1e-12) continue; // Singular / near zero

    // Eliminate below
    for (let k = i + 1; k < n; k++) {
      const factor = M[k][i] / M[i][i];
      for (let j = i; j <= n; j++) {
        M[k][j] -= factor * M[i][j];
      }
    }
  }

  // Back substitution
  const x = Array(n).fill(0);
  for (let i = n - 1; i >= 0; i--) {
    if (Math.abs(M[i][i]) < 1e-12) {
      x[i] = 0;
      continue;
    }
    let sum = M[i][n];
    for (let j = i + 1; j < n; j++) {
      sum -= M[i][j] * x[j];
    }
    x[i] = sum / M[i][i];
  }

  return x;
}

