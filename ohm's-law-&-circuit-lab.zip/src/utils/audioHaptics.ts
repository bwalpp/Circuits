// Web Audio API and Android Haptic Feedback Synthesizer

class SoundEngine {
  private ctx: AudioContext | null = null;
  private motorOsc: OscillatorNode | null = null;
  private motorGain: GainNode | null = null;
  private continuityOsc: OscillatorNode | null = null;
  private continuityGain: GainNode | null = null;
  private isMuted: boolean = false;

  private initCtx() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (muted) {
      this.stopMotor();
      this.stopContinuity();
    }
  }

  public getIsMuted(): boolean {
    return this.isMuted;
  }

  public vibrate(pattern: number | number[] = 30) {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(pattern);
      } catch {
        // Safe fallback
      }
    }
  }

  /** Click sound for tactile switch toggles */
  public playSwitchClick(state: boolean) {
    this.vibrate(20);
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(state ? 800 : 400, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(100, this.ctx.currentTime + 0.05);

    gain.gain.setValueAtTime(0.3, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.05);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.06);
  }

  /** Slider tick feedback */
  public playTick() {
    this.vibrate(10);
  }

  /** Multimeter continuity test beep */
  public setContinuityBeep(active: boolean) {
    if (this.isMuted) {
      this.stopContinuity();
      return;
    }
    if (active) {
      this.initCtx();
      if (!this.ctx) return;
      if (!this.continuityOsc) {
        this.continuityOsc = this.ctx.createOscillator();
        this.continuityGain = this.ctx.createGain();
        this.continuityOsc.type = 'sine';
        this.continuityOsc.frequency.setValueAtTime(2400, this.ctx.currentTime); // standard 2.4kHz multimeter beep
        this.continuityGain.gain.setValueAtTime(0.2, this.ctx.currentTime);
        this.continuityOsc.connect(this.continuityGain);
        this.continuityGain.connect(this.ctx.destination);
        this.continuityOsc.start();
      }
    } else {
      this.stopContinuity();
    }
  }

  private stopContinuity() {
    if (this.continuityOsc) {
      try {
        this.continuityOsc.stop();
        this.continuityOsc.disconnect();
      } catch {
        // Ignored
      }
      this.continuityOsc = null;
      this.continuityGain = null;
    }
  }

  /** Fuse blow / burn out pop */
  public playFuseBlow() {
    this.vibrate([80, 50, 120]);
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(180, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(30, this.ctx.currentTime + 0.2);

    gain.gain.setValueAtTime(0.6, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.25);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.26);
  }

  /** Success chime for challenges */
  public playSuccessChime() {
    this.vibrate([40, 60, 80]);
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
    notes.forEach((freq, idx) => {
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const startTime = this.ctx.currentTime + idx * 0.08;

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, startTime);

      gain.gain.setValueAtTime(0.2, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.3);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(startTime);
      osc.stop(startTime + 0.35);
    });
  }

  public playSuccess() {
    this.playSuccessChime();
  }

  /** Motor hum with dynamic RPM frequency */
  public setMotorHum(active: boolean, rpmNormalized = 0.5) {
    this.updateMotorSound(active, rpmNormalized);
  }

  public updateMotorSound(active: boolean, rpmNormalized: number) {
    if (this.isMuted || !active || rpmNormalized <= 0.01) {
      this.stopMotor();
      return;
    }

    this.initCtx();
    if (!this.ctx) return;

    const targetFreq = 40 + rpmNormalized * 300; // 40Hz to 340Hz
    const targetVol = Math.min(0.25, 0.05 + rpmNormalized * 0.2);

    if (!this.motorOsc) {
      this.motorOsc = this.ctx.createOscillator();
      this.motorGain = this.ctx.createGain();
      this.motorOsc.type = 'sawtooth';
      this.motorOsc.frequency.setValueAtTime(targetFreq, this.ctx.currentTime);
      this.motorGain.gain.setValueAtTime(targetVol, this.ctx.currentTime);

      this.motorOsc.connect(this.motorGain);
      this.motorGain.connect(this.ctx.destination);
      this.motorOsc.start();
    } else if (this.motorGain && this.motorOsc) {
      this.motorOsc.frequency.setTargetAtTime(targetFreq, this.ctx.currentTime, 0.05);
      this.motorGain.gain.setTargetAtTime(targetVol, this.ctx.currentTime, 0.05);
    }
  }

  public stopMotor() {
    if (this.motorOsc) {
      try {
        this.motorOsc.stop();
        this.motorOsc.disconnect();
      } catch {
        // Ignored
      }
      this.motorOsc = null;
      this.motorGain = null;
    }
  }
}

export const sounds = new SoundEngine();
