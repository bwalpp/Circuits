export type VIRPTopology =
  | 'series_2'
  | 'series_3'
  | 'series_4'
  | 'parallel_2'
  | 'parallel_3'
  | 'parallel_4'
  | 'combo_series_parallel' // R1 + (R2 || R3)
  | 'combo_parallel_series'; // (R1 + R2) || (R3 + R4)

export interface VIRPEntry {
  id: string;
  label: string;
  v?: number | null;
  i?: number | null;
  r?: number | null;
  p?: number | null;
}

export interface SolvedCell {
  value: number;
  isGiven: boolean;
  formula?: string;
  stepDescription?: string;
}

export interface SolvedVIRPRow {
  id: string;
  label: string;
  v: SolvedCell | null;
  i: SolvedCell | null;
  r: SolvedCell | null;
  p: SolvedCell | null;
}

export interface VIRPSolutionStep {
  stepNumber: number;
  variableName: string;
  targetId: string;
  parameter: 'V' | 'I' | 'R' | 'P';
  formula: string;
  substitution: string;
  resultString: string;
  rationale: string;
}

export interface VIRPSolverResult {
  isFullySolved: boolean;
  solvedRows: SolvedVIRPRow[];
  totalRow: SolvedVIRPRow;
  steps: VIRPSolutionStep[];
  statusMessage: string;
  error?: string;
  componentCount: number;
}

/** Formats values nicely for mathematical display */
function fmtNum(val: number, decimals = 3): string {
  if (Math.abs(val) >= 10000 || (Math.abs(val) < 0.001 && val !== 0)) {
    return val.toExponential(decimals);
  }
  const str = val.toFixed(decimals);
  return parseFloat(str).toString(); // trim trailing zeros
}

export function solveVIRPMatrix(
  topology: VIRPTopology,
  inputs: Record<string, { v?: string; i?: string; r?: string; p?: string }>
): VIRPSolverResult {
  let compCount = 2;
  if (topology === 'series_2' || topology === 'parallel_2') compCount = 2;
  else if (topology === 'series_3' || topology === 'parallel_3' || topology === 'combo_series_parallel') compCount = 3;
  else if (topology === 'series_4' || topology === 'parallel_4' || topology === 'combo_parallel_series') compCount = 4;

  const rowIds: string[] = [];
  for (let k = 1; k <= compCount; k++) {
    rowIds.push(`r${k}`);
  }

  // Internal state tracking:
  // state[rowId][param] = { val: number, isGiven: boolean, formula: string, explanation: string }
  type VarInfo = { val: number; isGiven: boolean; formula: string; explanation: string };
  const matrix: Record<string, Record<'V' | 'I' | 'R' | 'P', VarInfo | null>> = {};

  const allKeys = [...rowIds, 'total'];
  allKeys.forEach((key) => {
    matrix[key] = { V: null, I: null, R: null, P: null };
  });

  const steps: VIRPSolutionStep[] = [];
  let stepCounter = 1;

  // Parse given user inputs
  allKeys.forEach((key) => {
    const raw = inputs[key];
    if (!raw) return;

    if (raw.v !== undefined && raw.v !== '' && !isNaN(parseFloat(raw.v)) && parseFloat(raw.v) >= 0) {
      const val = parseFloat(raw.v);
      matrix[key].V = { val, isGiven: true, formula: 'Given', explanation: `Given input value for ${key === 'total' ? 'Total Voltage V_total' : `V_${key}`}` };
    }
    if (raw.i !== undefined && raw.i !== '' && !isNaN(parseFloat(raw.i)) && parseFloat(raw.i) >= 0) {
      const val = parseFloat(raw.i);
      matrix[key].I = { val, isGiven: true, formula: 'Given', explanation: `Given input value for ${key === 'total' ? 'Total Current I_total' : `I_${key}`}` };
    }
    if (raw.r !== undefined && raw.r !== '' && !isNaN(parseFloat(raw.r)) && parseFloat(raw.r) > 0) {
      const val = parseFloat(raw.r);
      matrix[key].R = { val, isGiven: true, formula: 'Given', explanation: `Given input value for ${key === 'total' ? 'Total Resistance R_total' : `R_${key}`}` };
    }
    if (raw.p !== undefined && raw.p !== '' && !isNaN(parseFloat(raw.p)) && parseFloat(raw.p) >= 0) {
      const val = parseFloat(raw.p);
      matrix[key].P = { val, isGiven: true, formula: 'Given', explanation: `Given input value for ${key === 'total' ? 'Total Power P_total' : `P_${key}`}` };
    }
  });

  const setVar = (
    key: string,
    param: 'V' | 'I' | 'R' | 'P',
    val: number,
    formula: string,
    substitution: string,
    rationale: string,
    unit: string
  ) => {
    if (val < 0 || !Number.isFinite(val)) return false;
    if (matrix[key][param] !== null) return false;

    matrix[key][param] = {
      val,
      isGiven: false,
      formula,
      explanation: rationale,
    };

    const varName = key === 'total' ? `${param}_total` : `${param}_${key.replace('r', '')}`;
    steps.push({
      stepNumber: stepCounter++,
      variableName: varName,
      targetId: key,
      parameter: param,
      formula,
      substitution,
      resultString: `${varName} = ${fmtNum(val)} ${unit}`,
      rationale,
    });
    return true;
  };

  // Iterative constraint propagation loop
  let changed = true;
  let iterations = 0;
  const MAX_ITERATIONS = 30;

  while (changed && iterations < MAX_ITERATIONS) {
    changed = false;
    iterations++;

    // -------------------------------------------------------------------------
    // RULE 1: Individual Row Ohm's Law and Joule's Law for all elements & Total
    // -------------------------------------------------------------------------
    allKeys.forEach((key) => {
      const v = matrix[key].V?.val;
      const i = matrix[key].I?.val;
      const r = matrix[key].R?.val;
      const p = matrix[key].P?.val;
      const label = key === 'total' ? 'Total' : key.toUpperCase();

      // V & R known -> find I & P
      if (v !== undefined && r !== undefined && r > 0) {
        if (i === undefined) {
          const calcI = v / r;
          if (setVar(key, 'I', calcI, 'I = V / R', `${fmtNum(v)} V / ${fmtNum(r)} Ω`, `By Ohm's Law on ${label}`, 'A')) changed = true;
        }
        if (p === undefined) {
          const calcP = (v * v) / r;
          if (setVar(key, 'P', calcP, 'P = V² / R', `(${fmtNum(v)} V)² / ${fmtNum(r)} Ω`, `By Joule's Power Law on ${label}`, 'W')) changed = true;
        }
      }

      // I & R known -> find V & P
      if (i !== undefined && r !== undefined) {
        if (v === undefined) {
          const calcV = i * r;
          if (setVar(key, 'V', calcV, 'V = I × R', `${fmtNum(i)} A × ${fmtNum(r)} Ω`, `By Ohm's Law on ${label}`, 'V')) changed = true;
        }
        if (p === undefined) {
          const calcP = i * i * r;
          if (setVar(key, 'P', calcP, 'P = I² × R', `(${fmtNum(i)} A)² × ${fmtNum(r)} Ω`, `By Joule's Power Law on ${label}`, 'W')) changed = true;
        }
      }

      // V & I known -> find R & P
      if (v !== undefined && i !== undefined) {
        if (r === undefined && i > 0) {
          const calcR = v / i;
          if (setVar(key, 'R', calcR, 'R = V / I', `${fmtNum(v)} V / ${fmtNum(i)} A`, `By Ohm's Law on ${label}`, 'Ω')) changed = true;
        }
        if (p === undefined) {
          const calcP = v * i;
          if (setVar(key, 'P', calcP, 'P = V × I', `${fmtNum(v)} V × ${fmtNum(i)} A`, `By Joule's Power Law on ${label}`, 'W')) changed = true;
        }
      }

      // P & V known -> find I & R
      if (p !== undefined && v !== undefined && v > 0) {
        if (i === undefined) {
          const calcI = p / v;
          if (setVar(key, 'I', calcI, 'I = P / V', `${fmtNum(p)} W / ${fmtNum(v)} V`, `By Power relationship on ${label}`, 'A')) changed = true;
        }
        if (r === undefined && p > 0) {
          const calcR = (v * v) / p;
          if (setVar(key, 'R', calcR, 'R = V² / P', `(${fmtNum(v)} V)² / ${fmtNum(p)} W`, `By Power-Resistance relationship on ${label}`, 'Ω')) changed = true;
        }
      }

      // P & I known -> find V & R
      if (p !== undefined && i !== undefined && i > 0) {
        if (v === undefined) {
          const calcV = p / i;
          if (setVar(key, 'V', calcV, 'V = P / I', `${fmtNum(p)} W / ${fmtNum(i)} A`, `By Power relationship on ${label}`, 'V')) changed = true;
        }
        if (r === undefined) {
          const calcR = p / (i * i);
          if (setVar(key, 'R', calcR, 'R = P / I²', `${fmtNum(p)} W / (${fmtNum(i)} A)²`, `By Power relationship on ${label}`, 'Ω')) changed = true;
        }
      }

      // P & R known -> find V & I
      if (p !== undefined && r !== undefined && r > 0) {
        if (v === undefined) {
          const calcV = Math.sqrt(p * r);
          if (setVar(key, 'V', calcV, 'V = √(P × R)', `√(${fmtNum(p)} W × ${fmtNum(r)} Ω)`, `By Power relationship on ${label}`, 'V')) changed = true;
        }
        if (i === undefined) {
          const calcI = Math.sqrt(p / r);
          if (setVar(key, 'I', calcI, 'I = √(P / R)', `√(${fmtNum(p)} W / ${fmtNum(r)} Ω)`, `By Power relationship on ${label}`, 'A')) changed = true;
        }
      }
    });

    // -------------------------------------------------------------------------
    // RULE 2: Power Summation (Conservation of Energy: P_total = sum(P_i))
    // -------------------------------------------------------------------------
    const knownPList = rowIds.map((k) => matrix[k].P?.val);
    const missingPIdx = knownPList.findIndex((val) => val === undefined);
    const countMissingP = knownPList.filter((val) => val === undefined).length;
    const totalP = matrix['total'].P?.val;

    if (countMissingP === 0) {
      // All individual P known -> deduce P_total
      const sumP = knownPList.reduce((acc, v) => (acc ?? 0) + (v ?? 0), 0) ?? 0;
      if (matrix['total'].P === null) {
        const subStr = knownPList.map((v) => `${fmtNum(v!)} W`).join(' + ');
        if (setVar('total', 'P', sumP, 'P_total = P1 + P2 + ...', subStr, 'Conservation of Energy: Total power equals the sum of branch dissipations', 'W')) changed = true;
      }
    } else if (countMissingP === 1 && totalP !== undefined) {
      // P_total known and all except one P_i known
      const missingKey = rowIds[missingPIdx];
      const sumOtherP = knownPList.reduce((acc, v, idx) => (idx !== missingPIdx ? (acc ?? 0) + (v ?? 0) : acc), 0) ?? 0;
      const deducedP = totalP - sumOtherP;
      if (deducedP >= 0) {
        if (setVar(missingKey, 'P', deducedP, `P_${missingKey.replace('r','')} = P_total - ∑(Other P)`, `${fmtNum(totalP)} W - ${fmtNum(sumOtherP)} W`, 'Conservation of Energy', 'W')) changed = true;
      }
    }

    // -------------------------------------------------------------------------
    // RULE 3: PURE SERIES TOPOLOGY (series_2, series_3, series_4)
    // -------------------------------------------------------------------------
    if (topology.startsWith('series_')) {
      // A) Current is uniform: I_1 = I_2 = ... = I_n = I_total
      let knownCurrentVal: number | undefined;
      let knownSourceLabel = '';
      allKeys.forEach((k) => {
        if (matrix[k].I !== null && knownCurrentVal === undefined) {
          knownCurrentVal = matrix[k].I!.val;
          knownSourceLabel = k === 'total' ? 'I_total' : `I_${k.replace('r', '')}`;
        }
      });

      if (knownCurrentVal !== undefined) {
        allKeys.forEach((k) => {
          if (matrix[k].I === null) {
            const label = k === 'total' ? 'I_total' : `I_${k.replace('r', '')}`;
            if (setVar(k, 'I', knownCurrentVal!, `${label} = ${knownSourceLabel}`, `${fmtNum(knownCurrentVal!)} A`, 'In a pure series circuit, current is identical everywhere throughout the loop', 'A')) {
              changed = true;
            }
          }
        });
      }

      // B) Resistance sum: R_total = R1 + R2 + ... + Rn
      const knownRList = rowIds.map((k) => matrix[k].R?.val);
      const countMissingR = knownRList.filter((v) => v === undefined).length;
      const totalR = matrix['total'].R?.val;

      if (countMissingR === 0 && matrix['total'].R === null) {
        const sumR = knownRList.reduce((acc, v) => (acc ?? 0) + (v ?? 0), 0) ?? 0;
        const subStr = knownRList.map((v) => `${fmtNum(v!)} Ω`).join(' + ');
        if (setVar('total', 'R', sumR, 'R_total = R1 + R2 + ... + Rn', subStr, 'Series equivalent resistance is the direct linear sum of all individual resistors', 'Ω')) {
          changed = true;
        }
      } else if (countMissingR === 1 && totalR !== undefined) {
        const missingIdx = knownRList.findIndex((v) => v === undefined);
        const missingKey = rowIds[missingIdx];
        const sumOthers = knownRList.reduce((acc, v, idx) => (idx !== missingIdx ? (acc ?? 0) + (v ?? 0) : acc), 0) ?? 0;
        const deducedR = totalR - sumOthers;
        if (deducedR > 0) {
          if (setVar(missingKey, 'R', deducedR, `R_${missingKey.replace('r','')} = R_total - ∑(Other R)`, `${fmtNum(totalR)} Ω - ${fmtNum(sumOthers)} Ω`, 'Series total resistance subtraction', 'Ω')) {
            changed = true;
          }
        }
      }

      // C) Voltage sum (Kirchhoff's Voltage Law): V_total = V1 + V2 + ... + Vn
      const knownVList = rowIds.map((k) => matrix[k].V?.val);
      const countMissingV = knownVList.filter((v) => v === undefined).length;
      const totalV = matrix['total'].V?.val;

      if (countMissingV === 0 && matrix['total'].V === null) {
        const sumV = knownVList.reduce((acc, v) => (acc ?? 0) + (v ?? 0), 0) ?? 0;
        const subStr = knownVList.map((v) => `${fmtNum(v!)} V`).join(' + ');
        if (setVar('total', 'V', sumV, 'V_total = V1 + V2 + ... + Vn', subStr, "Kirchhoff's Voltage Law (KVL): Sum of series voltage drops equals total source voltage", 'V')) {
          changed = true;
        }
      } else if (countMissingV === 1 && totalV !== undefined) {
        const missingIdx = knownVList.findIndex((v) => v === undefined);
        const missingKey = rowIds[missingIdx];
        const sumOthers = knownVList.reduce((acc, v, idx) => (idx !== missingIdx ? (acc ?? 0) + (v ?? 0) : acc), 0) ?? 0;
        const deducedV = totalV - sumOthers;
        if (deducedV >= 0) {
          if (setVar(missingKey, 'V', deducedV, `V_${missingKey.replace('r','')} = V_total - ∑(Other V)`, `${fmtNum(totalV)} V - ${fmtNum(sumOthers)} V`, "Kirchhoff's Voltage Law (KVL)", 'V')) {
            changed = true;
          }
        }
      }
    }

    // -------------------------------------------------------------------------
    // RULE 4: PURE PARALLEL TOPOLOGY (parallel_2, parallel_3, parallel_4)
    // -------------------------------------------------------------------------
    if (topology.startsWith('parallel_')) {
      // A) Voltage is uniform across all branches: V_1 = V_2 = ... = V_n = V_total
      let knownVoltageVal: number | undefined;
      let knownVoltageSource = '';
      allKeys.forEach((k) => {
        if (matrix[k].V !== null && knownVoltageVal === undefined) {
          knownVoltageVal = matrix[k].V!.val;
          knownVoltageSource = k === 'total' ? 'V_total' : `V_${k.replace('r', '')}`;
        }
      });

      if (knownVoltageVal !== undefined) {
        allKeys.forEach((k) => {
          if (matrix[k].V === null) {
            const label = k === 'total' ? 'V_total' : `V_${k.replace('r', '')}`;
            if (setVar(k, 'V', knownVoltageVal!, `${label} = ${knownVoltageSource}`, `${fmtNum(knownVoltageVal!)} V`, 'In a pure parallel circuit, every branch connects across the identical voltage rails', 'V')) {
              changed = true;
            }
          }
        });
      }

      // B) Current sum (Kirchhoff's Current Law): I_total = I1 + I2 + ... + In
      const knownIList = rowIds.map((k) => matrix[k].I?.val);
      const countMissingI = knownIList.filter((v) => v === undefined).length;
      const totalI = matrix['total'].I?.val;

      if (countMissingI === 0 && matrix['total'].I === null) {
        const sumI = knownIList.reduce((acc, v) => (acc ?? 0) + (v ?? 0), 0) ?? 0;
        const subStr = knownIList.map((v) => `${fmtNum(v!)} A`).join(' + ');
        if (setVar('total', 'I', sumI, 'I_total = I1 + I2 + ... + In', subStr, "Kirchhoff's Current Law (KCL): Total current equals the sum of parallel branch currents", 'A')) {
          changed = true;
        }
      } else if (countMissingI === 1 && totalI !== undefined) {
        const missingIdx = knownIList.findIndex((v) => v === undefined);
        const missingKey = rowIds[missingIdx];
        const sumOthers = knownIList.reduce((acc, v, idx) => (idx !== missingIdx ? (acc ?? 0) + (v ?? 0) : acc), 0) ?? 0;
        const deducedI = totalI - sumOthers;
        if (deducedI >= 0) {
          if (setVar(missingKey, 'I', deducedI, `I_${missingKey.replace('r','')} = I_total - ∑(Other I)`, `${fmtNum(totalI)} A - ${fmtNum(sumOthers)} A`, "Kirchhoff's Current Law (KCL)", 'A')) {
            changed = true;
          }
        }
      }

      // C) Parallel Equivalent Resistance: 1/R_total = 1/R1 + 1/R2 + ... + 1/Rn
      const knownRList = rowIds.map((k) => matrix[k].R?.val);
      const countMissingR = knownRList.filter((v) => v === undefined).length;
      const totalR = matrix['total'].R?.val;

      if (countMissingR === 0 && matrix['total'].R === null) {
        const sumReciprocal = knownRList.reduce((acc, v) => (acc ?? 0) + 1 / (v ?? 1), 0) ?? 0;
        if (sumReciprocal > 0) {
          const req = 1 / sumReciprocal;
          const subStr = `1 / (${knownRList.map((v) => `1/${fmtNum(v!)}`).join(' + ')})`;
          if (setVar('total', 'R', req, '1/R_total = 1/R1 + 1/R2 + ...', subStr, 'Parallel equivalent resistance formula', 'Ω')) {
            changed = true;
          }
        }
      } else if (countMissingR === 1 && totalR !== undefined) {
        const missingIdx = knownRList.findIndex((v) => v === undefined);
        const missingKey = rowIds[missingIdx];
        const sumOtherReciprocals = knownRList.reduce((acc, v, idx) => (idx !== missingIdx ? (acc ?? 0) + 1 / (v ?? 1) : acc), 0) ?? 0;
        const missingReciprocal = 1 / totalR - sumOtherReciprocals;
        if (missingReciprocal > 0) {
          const deducedR = 1 / missingReciprocal;
          if (setVar(missingKey, 'R', deducedR, `1/R_${missingKey.replace('r','')} = 1/R_total - ∑(1/Other R)`, `1/(${fmtNum(totalR)}) - ${fmtNum(sumOtherReciprocals)}`, 'Parallel resistance reduction', 'Ω')) {
            changed = true;
          }
        }
      }
    }

    // -------------------------------------------------------------------------
    // RULE 5: SERIES-PARALLEL COMBINATION: R1 + (R2 || R3)
    // -------------------------------------------------------------------------
    if (topology === 'combo_series_parallel') {
      const v1 = matrix['r1'].V?.val;
      const i1 = matrix['r1'].I?.val;
      const r1 = matrix['r1'].R?.val;

      const v2 = matrix['r2'].V?.val;
      const i2 = matrix['r2'].I?.val;
      const r2 = matrix['r2'].R?.val;

      const v3 = matrix['r3'].V?.val;
      const i3 = matrix['r3'].I?.val;
      const r3 = matrix['r3'].R?.val;

      const vTot = matrix['total'].V?.val;
      const iTot = matrix['total'].I?.val;
      const rTot = matrix['total'].R?.val;

      // 1. I1 is the trunk current -> equals I_total
      if (i1 !== undefined && iTot === undefined) {
        if (setVar('total', 'I', i1, 'I_total = I1', `${fmtNum(i1)} A`, 'Trunk resistor R1 carries full circuit current', 'A')) changed = true;
      }
      if (iTot !== undefined && i1 === undefined) {
        if (setVar('r1', 'I', iTot, 'I1 = I_total', `${fmtNum(iTot)} A`, 'Trunk resistor R1 carries full circuit current', 'A')) changed = true;
      }

      // 2. Parallel pair R2 and R3 share voltage: V2 = V3
      if (v2 !== undefined && v3 === undefined) {
        if (setVar('r3', 'V', v2, 'V3 = V2', `${fmtNum(v2)} V`, 'R2 and R3 are connected in parallel across the same nodes', 'V')) changed = true;
      }
      if (v3 !== undefined && v2 === undefined) {
        if (setVar('r2', 'V', v3, 'V2 = V3', `${fmtNum(v3)} V`, 'R2 and R3 are connected in parallel across the same nodes', 'V')) changed = true;
      }

      // 3. KCL on parallel junction: I_trunk = I2 + I3
      const currentTrunk = iTot ?? i1;
      if (currentTrunk !== undefined) {
        if (i2 !== undefined && i3 === undefined) {
          const calcI3 = currentTrunk - i2;
          if (calcI3 >= 0) {
            if (setVar('r3', 'I', calcI3, 'I3 = I_total - I2', `${fmtNum(currentTrunk)} A - ${fmtNum(i2)} A`, 'KCL at parallel junction', 'A')) changed = true;
          }
        }
        if (i3 !== undefined && i2 === undefined) {
          const calcI2 = currentTrunk - i3;
          if (calcI2 >= 0) {
            if (setVar('r2', 'I', calcI2, 'I2 = I_total - I3', `${fmtNum(currentTrunk)} A - ${fmtNum(i3)} A`, 'KCL at parallel junction', 'A')) changed = true;
          }
        }
      } else if (i2 !== undefined && i3 !== undefined) {
        const calcITrunk = i2 + i3;
        if (setVar('r1', 'I', calcITrunk, 'I1 = I2 + I3', `${fmtNum(i2)} A + ${fmtNum(i3)} A`, 'KCL sum from parallel branches', 'A')) changed = true;
        if (setVar('total', 'I', calcITrunk, 'I_total = I2 + I3', `${fmtNum(i2)} A + ${fmtNum(i3)} A`, 'Total circuit current equals sum of branch currents', 'A')) changed = true;
      }

      // 4. KVL: V_total = V1 + V_parallel (where V_parallel = V2 = V3)
      const vPar = v2 ?? v3;
      if (v1 !== undefined && vPar !== undefined && vTot === undefined) {
        const calcVTot = v1 + vPar;
        if (setVar('total', 'V', calcVTot, 'V_total = V1 + V_parallel', `${fmtNum(v1)} V + ${fmtNum(vPar)} V`, 'KVL loop across trunk and parallel block', 'V')) changed = true;
      }
      if (vTot !== undefined && v1 !== undefined && vPar === undefined) {
        const calcVPar = vTot - v1;
        if (calcVPar >= 0) {
          if (setVar('r2', 'V', calcVPar, 'V2 = V_total - V1', `${fmtNum(vTot)} V - ${fmtNum(v1)} V`, 'KVL voltage drop across parallel block', 'V')) changed = true;
          if (setVar('r3', 'V', calcVPar, 'V3 = V_total - V1', `${fmtNum(vTot)} V - ${fmtNum(v1)} V`, 'KVL voltage drop across parallel block', 'V')) changed = true;
        }
      }
      if (vTot !== undefined && vPar !== undefined && v1 === undefined) {
        const calcV1 = vTot - vPar;
        if (calcV1 >= 0) {
          if (setVar('r1', 'V', calcV1, 'V1 = V_total - V_parallel', `${fmtNum(vTot)} V - ${fmtNum(vPar)} V`, 'KVL trunk voltage drop', 'V')) changed = true;
        }
      }

      // 5. Total Resistance: R_total = R1 + (R2 || R3) = R1 + (R2*R3)/(R2+R3)
      if (r1 !== undefined && r2 !== undefined && r3 !== undefined && rTot === undefined) {
        const rPar = (r2 * r3) / (r2 + r3);
        const calcRTot = r1 + rPar;
        if (setVar('total', 'R', calcRTot, 'R_total = R1 + (R2 || R3)', `${fmtNum(r1)} Ω + (${fmtNum(r2)} × ${fmtNum(r3)})/(${fmtNum(r2)}+${fmtNum(r3)}) Ω`, 'Series-parallel reduction formula', 'Ω')) {
          changed = true;
        }
      }
    }

    // -------------------------------------------------------------------------
    // RULE 6: PARALLEL-SERIES COMBINATION: (R1 + R2) || (R3 + R4)
    // -------------------------------------------------------------------------
    if (topology === 'combo_parallel_series') {
      const vTot = matrix['total'].V?.val;
      const iTot = matrix['total'].I?.val;

      // Branch A (R1+R2) and Branch B (R3+R4) share V_total:
      // V_A = V1 + V2 = V_total
      // V_B = V3 + V4 = V_total
      // I1 = I2 = I_A
      // I3 = I4 = I_B
      // I_total = I_A + I_B

      // I1 = I2
      if (matrix['r1'].I?.val !== undefined && matrix['r2'].I === null) {
        const val = matrix['r1'].I!.val;
        if (setVar('r2', 'I', val, 'I2 = I1', `${fmtNum(val)} A`, 'R1 and R2 are in series in Branch A', 'A')) changed = true;
      }
      if (matrix['r2'].I?.val !== undefined && matrix['r1'].I === null) {
        const val = matrix['r2'].I!.val;
        if (setVar('r1', 'I', val, 'I1 = I2', `${fmtNum(val)} A`, 'R1 and R2 are in series in Branch A', 'A')) changed = true;
      }

      // I3 = I4
      if (matrix['r3'].I?.val !== undefined && matrix['r4'].I === null) {
        const val = matrix['r3'].I!.val;
        if (setVar('r4', 'I', val, 'I4 = I3', `${fmtNum(val)} A`, 'R3 and R4 are in series in Branch B', 'A')) changed = true;
      }
      if (matrix['r4'].I?.val !== undefined && matrix['r3'].I === null) {
        const val = matrix['r4'].I!.val;
        if (setVar('r3', 'I', val, 'I3 = I4', `${fmtNum(val)} A`, 'R3 and R4 are in series in Branch B', 'A')) changed = true;
      }

      // Branch A KVL: V_total = V1 + V2
      const v1 = matrix['r1'].V?.val;
      const v2 = matrix['r2'].V?.val;
      if (v1 !== undefined && v2 !== undefined && vTot === undefined) {
        const sum = v1 + v2;
        if (setVar('total', 'V', sum, 'V_total = V1 + V2', `${fmtNum(v1)} V + ${fmtNum(v2)} V`, 'KVL across Branch A', 'V')) changed = true;
      }
      if (vTot !== undefined && v1 !== undefined && v2 === undefined) {
        const calc = vTot - v1;
        if (calc >= 0) if (setVar('r2', 'V', calc, 'V2 = V_total - V1', `${fmtNum(vTot)} V - ${fmtNum(v1)} V`, 'KVL on Branch A', 'V')) changed = true;
      }
      if (vTot !== undefined && v2 !== undefined && v1 === undefined) {
        const calc = vTot - v2;
        if (calc >= 0) if (setVar('r1', 'V', calc, 'V1 = V_total - V2', `${fmtNum(vTot)} V - ${fmtNum(v2)} V`, 'KVL on Branch A', 'V')) changed = true;
      }

      // Branch B KVL: V_total = V3 + V4
      const v3 = matrix['r3'].V?.val;
      const v4 = matrix['r4'].V?.val;
      if (v3 !== undefined && v4 !== undefined && vTot === undefined) {
        const sum = v3 + v4;
        if (setVar('total', 'V', sum, 'V_total = V3 + V4', `${fmtNum(v3)} V + ${fmtNum(v4)} V`, 'KVL across Branch B', 'V')) changed = true;
      }
      if (vTot !== undefined && v3 !== undefined && v4 === undefined) {
        const calc = vTot - v3;
        if (calc >= 0) if (setVar('r4', 'V', calc, 'V4 = V_total - V3', `${fmtNum(vTot)} V - ${fmtNum(v3)} V`, 'KVL on Branch B', 'V')) changed = true;
      }
      if (vTot !== undefined && v4 !== undefined && v3 === undefined) {
        const calc = vTot - v4;
        if (calc >= 0) if (setVar('r3', 'V', calc, 'V3 = V_total - V4', `${fmtNum(vTot)} V - ${fmtNum(v4)} V`, 'KVL on Branch B', 'V')) changed = true;
      }

      // KCL: I_total = I_A + I_B (where I_A = I1 = I2, I_B = I3 = I4)
      const iA = matrix['r1'].I?.val ?? matrix['r2'].I?.val;
      const iB = matrix['r3'].I?.val ?? matrix['r4'].I?.val;
      if (iA !== undefined && iB !== undefined && iTot === undefined) {
        const sumI = iA + iB;
        if (setVar('total', 'I', sumI, 'I_total = I_A + I_B', `${fmtNum(iA)} A + ${fmtNum(iB)} A`, 'KCL sum of Branch A and Branch B currents', 'A')) changed = true;
      }
      if (iTot !== undefined && iA !== undefined && iB === undefined) {
        const calcIB = iTot - iA;
        if (calcIB >= 0) {
          if (setVar('r3', 'I', calcIB, 'I3 = I_total - I_A', `${fmtNum(iTot)} A - ${fmtNum(iA)} A`, 'KCL at source junction', 'A')) changed = true;
          if (setVar('r4', 'I', calcIB, 'I4 = I_total - I_A', `${fmtNum(iTot)} A - ${fmtNum(iA)} A`, 'KCL at source junction', 'A')) changed = true;
        }
      }
      if (iTot !== undefined && iB !== undefined && iA === undefined) {
        const calcIA = iTot - iB;
        if (calcIA >= 0) {
          if (setVar('r1', 'I', calcIA, 'I1 = I_total - I_B', `${fmtNum(iTot)} A - ${fmtNum(iB)} A`, 'KCL at source junction', 'A')) changed = true;
          if (setVar('r2', 'I', calcIA, 'I2 = I_total - I_B', `${fmtNum(iTot)} A - ${fmtNum(iB)} A`, 'KCL at source junction', 'A')) changed = true;
        }
      }

      // Total R: (R1+R2) || (R3+R4)
      const r1 = matrix['r1'].R?.val;
      const r2 = matrix['r2'].R?.val;
      const r3 = matrix['r3'].R?.val;
      const r4 = matrix['r4'].R?.val;
      if (r1 !== undefined && r2 !== undefined && r3 !== undefined && r4 !== undefined && matrix['total'].R === null) {
        const rA = r1 + r2;
        const rB = r3 + r4;
        const req = (rA * rB) / (rA + rB);
        if (setVar('total', 'R', req, 'R_total = (R1+R2) || (R3+R4)', `(${fmtNum(rA)} × ${fmtNum(rB)}) / (${fmtNum(rA)} + ${fmtNum(rB)}) Ω`, 'Parallel-series equivalent resistance', 'Ω')) {
          changed = true;
        }
      }
    }
  }

  // Build solved rows output
  const solvedRows: SolvedVIRPRow[] = rowIds.map((key) => {
    const row = matrix[key];
    return {
      id: key,
      label: key.toUpperCase(),
      v: row.V ? { value: row.V.val, isGiven: row.V.isGiven, formula: row.V.formula, stepDescription: row.V.explanation } : null,
      i: row.I ? { value: row.I.val, isGiven: row.I.isGiven, formula: row.I.formula, stepDescription: row.I.explanation } : null,
      r: row.R ? { value: row.R.val, isGiven: row.R.isGiven, formula: row.R.formula, stepDescription: row.R.explanation } : null,
      p: row.P ? { value: row.P.val, isGiven: row.P.isGiven, formula: row.P.formula, stepDescription: row.P.explanation } : null,
    };
  });

  const totalRaw = matrix['total'];
  const totalRow: SolvedVIRPRow = {
    id: 'total',
    label: 'TOTAL CIRCUIT',
    v: totalRaw.V ? { value: totalRaw.V.val, isGiven: totalRaw.V.isGiven, formula: totalRaw.V.formula, stepDescription: totalRaw.V.explanation } : null,
    i: totalRaw.I ? { value: totalRaw.I.val, isGiven: totalRaw.I.isGiven, formula: totalRaw.I.formula, stepDescription: totalRaw.I.explanation } : null,
    r: totalRaw.R ? { value: totalRaw.R.val, isGiven: totalRaw.R.isGiven, formula: totalRaw.R.formula, stepDescription: totalRaw.R.explanation } : null,
    p: totalRaw.P ? { value: totalRaw.P.val, isGiven: totalRaw.P.isGiven, formula: totalRaw.P.formula, stepDescription: totalRaw.P.explanation } : null,
  };

  // Check if everything is solved
  let isFullySolved = true;
  allKeys.forEach((key) => {
    if (!matrix[key].V || !matrix[key].I || !matrix[key].R || !matrix[key].P) {
      isFullySolved = false;
    }
  });

  let statusMessage = 'Provide any known values to automatically solve all missing circuit parameters.';
  if (isFullySolved) {
    statusMessage = 'Complete Circuit Solved! All voltages, currents, resistances, and power dissipations have been calculated.';
  } else if (steps.length > 0) {
    statusMessage = `Partially Solved (${steps.length} parameters derived). Enter additional knowns to solve the remaining unknowns.`;
  }

  return {
    isFullySolved,
    solvedRows,
    totalRow,
    steps,
    statusMessage,
    componentCount: compCount,
  };
}
