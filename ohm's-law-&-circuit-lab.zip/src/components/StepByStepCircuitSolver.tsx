import React, { useState } from 'react';
import {
  Layers,
  GitMerge,
  GitPullRequest,
  Workflow,
  Sparkles,
  Zap,
  Sliders,
  CheckCircle2,
  Table,
  BookOpen,
  ArrowRight,
  ShieldAlert,
  HelpCircle,
  Activity,
  Flame,
} from 'lucide-react';
import {
  SolverTopology,
  ResistorLedgerItem,
  ReductionStep,
} from '../types';
import {
  solveSeriesCircuit,
  solveParallelCircuit,
  solveSeriesParallelCombo,
  solveParallelSeriesCombo,
  solveLadderCombo,
  solveWheatstoneBridge,
  formatVoltage,
  formatCurrent,
  formatResistance,
  formatPower,
} from '../utils/circuitMath';
import { VIRPMatrixSolver } from './VIRPMatrixSolver';
import { sounds } from '../utils/audioHaptics';

export const StepByStepCircuitSolver: React.FC = () => {
  const [solverMode, setSolverMode] = useState<'reduction' | 'virp_matrix'>('virp_matrix');
  const [topology, setTopology] = useState<SolverTopology>('combo_series_parallel');
  const [voltage, setVoltage] = useState<number>(12); // Volts

  // Resistor values state
  const [r1, setR1] = useState<number>(100);
  const [r2, setR2] = useState<number>(200);
  const [r3, setR3] = useState<number>(300);
  const [r4, setR4] = useState<number>(150);
  const [r5, setR5] = useState<number>(100);

  // For dynamic Series/Parallel list
  const [seriesResistors, setSeriesResistors] = useState<number[]>([100, 220, 470]);
  const [parallelResistors, setParallelResistors] = useState<number[]>([100, 200, 300]);

  // Solver execution based on active topology
  let rTotal = 0;
  let iTotal = 0;
  let pTotal = 0;
  let ledger: ResistorLedgerItem[] = [];
  let steps: ReductionStep[] = [];
  let bridgeData: { vA: number; vB: number; vBridge: number; isBalanced: boolean } | null = null;

  if (topology === 'series') {
    const resList = seriesResistors.map((val, idx) => ({
      id: `r${idx + 1}`,
      label: `R${idx + 1}`,
      value: val,
    }));
    const res = solveSeriesCircuit(voltage, resList);
    rTotal = res.rTotal;
    iTotal = res.iTotal;
    pTotal = res.pTotal;
    ledger = res.ledger;
    steps = res.steps;
  } else if (topology === 'parallel') {
    const resList = parallelResistors.map((val, idx) => ({
      id: `r${idx + 1}`,
      label: `R${idx + 1}`,
      value: val,
    }));
    const res = solveParallelCircuit(voltage, resList);
    rTotal = res.rTotal;
    iTotal = res.iTotal;
    pTotal = res.pTotal;
    ledger = res.ledger;
    steps = res.steps;
  } else if (topology === 'combo_series_parallel') {
    const res = solveSeriesParallelCombo(voltage, r1, r2, r3);
    rTotal = res.rTotal;
    iTotal = res.iTotal;
    pTotal = res.pTotal;
    ledger = res.ledger;
    steps = res.steps;
  } else if (topology === 'combo_parallel_series') {
    const res = solveParallelSeriesCombo(voltage, r1, r2, r3, r4);
    rTotal = res.rTotal;
    iTotal = res.iTotal;
    pTotal = res.pTotal;
    ledger = res.ledger;
    steps = res.steps;
  } else if (topology === 'combo_ladder') {
    const res = solveLadderCombo(voltage, r1, r2, r3, r4, r5);
    rTotal = res.rTotal;
    iTotal = res.iTotal;
    pTotal = res.pTotal;
    ledger = res.ledger;
    steps = res.steps;
  } else if (topology === 'bridge_wheatstone') {
    const res = solveWheatstoneBridge(voltage, r1, r2, r3, r4);
    rTotal = res.rTotal;
    iTotal = res.iTotal;
    pTotal = res.pTotal;
    ledger = res.ledger;
    steps = res.steps;
    bridgeData = {
      vA: res.vA,
      vB: res.vB,
      vBridge: res.vBridge,
      isBalanced: res.isBalanced,
    };
  }

  // Topologies list
  const topologies: { id: SolverTopology; label: string; icon: React.ReactNode; desc: string }[] = [
    {
      id: 'series',
      label: 'Series Circuit',
      icon: <Layers className="w-4 h-4" />,
      desc: 'Single continuous current loop: R_total = R1 + R2 + ...',
    },
    {
      id: 'parallel',
      label: 'Parallel Circuit',
      icon: <GitMerge className="w-4 h-4" />,
      desc: 'Shared constant voltage across branches: 1/R_total = 1/R1 + ...',
    },
    {
      id: 'combo_series_parallel',
      label: 'Series-Parallel Combo',
      icon: <Workflow className="w-4 h-4" />,
      desc: 'Trunk resistor R1 in series with parallel pair (R2 || R3)',
    },
    {
      id: 'combo_parallel_series',
      label: 'Parallel-Series Combo',
      icon: <GitPullRequest className="w-4 h-4" />,
      desc: 'Two series branches in parallel: (R1+R2) || (R3+R4)',
    },
    {
      id: 'combo_ladder',
      label: '5-Resistor Ladder',
      icon: <Activity className="w-4 h-4" />,
      desc: 'Multi-stage ladder attenuation: R1 + [R2 || (R3 + [R4 || R5])]',
    },
    {
      id: 'bridge_wheatstone',
      label: 'Wheatstone Bridge',
      icon: <Sparkles className="w-4 h-4" />,
      desc: 'Bridge differential voltage V_AB with null detector balance',
    },
  ];

  return (
    <div className="space-y-4">
      {/* Top Mode Segmented Control */}
      <div className="bg-slate-900/60 p-1.5 rounded-2xl border border-slate-800 flex items-center gap-1.5 max-w-xl mx-auto shadow-sm">
        <button
          onClick={() => {
            setSolverMode('virp_matrix');
            sounds.playSwitchClick(true);
          }}
          className={`flex-1 py-2 px-3 rounded-xl font-mono text-xs font-bold transition-all flex items-center justify-center gap-2 ${
            solverMode === 'virp_matrix'
              ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <Table className="w-3.5 h-3.5" />
          <span>VIRP Matrix & Given/Missing Solver</span>
        </button>
        <button
          onClick={() => {
            setSolverMode('reduction');
            sounds.playSwitchClick(true);
          }}
          className={`flex-1 py-2 px-3 rounded-xl font-mono text-xs font-bold transition-all flex items-center justify-center gap-2 ${
            solverMode === 'reduction'
              ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <Workflow className="w-3.5 h-3.5" />
          <span>Step-by-Step Circuit Reduction</span>
        </button>
      </div>

      {solverMode === 'virp_matrix' ? (
        <VIRPMatrixSolver />
      ) : (
        <>
          {/* Header Bento Banner */}
          <div className="bg-slate-900/50 p-4 sm:p-5 rounded-3xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm">
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                <span className="p-1.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  <Workflow className="w-4 h-4" />
                </span>
                How to Solve Series, Parallel & Combination Circuits
              </h2>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                Step-by-step algebraic circuit reduction, nodal voltage division, and complete parameter ledgers.
              </p>
            </div>

            {/* Global Summary Stats Bento Pill */}
            <div className="flex items-center gap-3 bg-slate-950 p-2 sm:px-4 sm:py-2.5 rounded-2xl border border-slate-800 self-start md:self-auto shadow-inner">
              <div className="text-left border-r border-slate-800 pr-3 font-mono">
                <span className="text-[10px] text-slate-500 block uppercase font-bold">Total R_eq</span>
                <span className="text-xs sm:text-sm font-bold text-emerald-400">{formatResistance(rTotal)}</span>
              </div>
              <div className="text-left border-r border-slate-800 pr-3 font-mono">
                <span className="text-[10px] text-slate-500 block uppercase font-bold">Total Current (I_s)</span>
                <span className="text-xs sm:text-sm font-bold text-cyan-400">{formatCurrent(iTotal)}</span>
              </div>
              <div className="text-left font-mono">
                <span className="text-[10px] text-slate-500 block uppercase font-bold">Total Power</span>
                <span className="text-xs sm:text-sm font-bold text-amber-400">{formatPower(pTotal)}</span>
              </div>
            </div>
          </div>

      {/* Topology Selector Buttons */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
        {topologies.map((t) => {
          const isActive = topology === t.id;
          return (
            <button
              key={t.id}
              onClick={() => {
                setTopology(t.id);
                sounds.playSwitchClick(true);
              }}
              className={`p-3 rounded-2xl border text-left transition-all flex flex-col justify-between ${
                isActive
                  ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-md shadow-emerald-500/20 font-bold'
                  : 'bg-slate-900/50 border-slate-800 text-slate-300 hover:bg-slate-800/80 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-1.5 text-xs">
                {t.icon}
                <span className="truncate">{t.label}</span>
              </div>
              <span className={`text-[10px] line-clamp-2 mt-1 leading-tight font-mono ${isActive ? 'text-slate-900' : 'text-slate-500'}`}>
                {t.desc}
              </span>
            </button>
          );
        })}
      </div>

      {/* Main Analysis Bento Layout: 12-Column Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Interactive Schematic & Parameter Controls (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Visual Schematic Diagram Card */}
          <div className="bg-slate-900/50 p-5 rounded-3xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                Active Schematic Diagram
              </span>
              <span className="px-2 py-0.5 rounded-lg text-[10px] font-mono font-bold bg-slate-950 text-emerald-400 border border-slate-800">
                {formatVoltage(voltage)} DC Supply
              </span>
            </div>

            {/* SVG Schematic Canvas */}
            <div className="w-full bg-slate-950 rounded-2xl border border-slate-800/90 p-4 flex items-center justify-center relative select-none min-h-[220px]">
              {topology === 'series' && (
                <svg viewBox="0 0 400 180" className="w-full max-w-sm drop-shadow-md">
                  {/* DC Source */}
                  <line x1="50" y1="50" x2="50" y2="130" stroke="#0ea5e9" strokeWidth="2" />
                  <line x1="30" y1="80" x2="70" y2="80" stroke="#f59e0b" strokeWidth="3" />
                  <line x1="40" y1="100" x2="60" y2="100" stroke="#64748b" strokeWidth="3" />
                  <text x="20" y="75" fill="#f59e0b" fontSize="11" fontWeight="bold" fontFamily="monospace">+</text>
                  <text x="22" y="110" fill="#94a3b8" fontSize="11" fontWeight="bold" fontFamily="monospace">-</text>
                  <text x="15" y="145" fill="#38bdf8" fontSize="10" fontFamily="monospace">{formatVoltage(voltage)}</text>

                  {/* Wire loop */}
                  <path d="M 50 50 L 120 50" fill="none" stroke="#38bdf8" strokeWidth="2" />
                  <path d="M 50 130 L 350 130 L 350 50" fill="none" stroke="#38bdf8" strokeWidth="2" />

                  {/* Resistors */}
                  {seriesResistors.map((val, idx) => {
                    const x = 120 + idx * 75;
                    return (
                      <g key={idx}>
                        <line x1={x - 20} y1="50" x2={x - 10} y2="50" stroke="#38bdf8" strokeWidth="2" />
                        <rect x={x - 10} y="40" width="38" height="20" rx="4" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                        <text x={x + 9} y="54" fill="#34d399" fontSize="9" fontWeight="bold" fontFamily="monospace" textAnchor="middle">
                          R{idx + 1}
                        </text>
                        <text x={x + 9} y="74" fill="#94a3b8" fontSize="8" fontFamily="monospace" textAnchor="middle">
                          {formatResistance(val)}
                        </text>
                        <line x1={x + 28} y1="50" x2={x + 55} y2="50" stroke="#38bdf8" strokeWidth="2" />
                      </g>
                    );
                  })}
                  {/* Current Arrow */}
                  <path d="M 200 130 L 190 126 L 190 134 Z" fill="#38bdf8" />
                  <text x="200" y="148" fill="#38bdf8" fontSize="9" fontFamily="monospace" textAnchor="middle">
                    I_loop = {formatCurrent(iTotal)}
                  </text>
                </svg>
              )}

              {topology === 'parallel' && (
                <svg viewBox="0 0 400 180" className="w-full max-w-sm drop-shadow-md">
                  {/* Source */}
                  <line x1="60" y1="40" x2="60" y2="140" stroke="#0ea5e9" strokeWidth="2" />
                  <line x1="40" y1="80" x2="80" y2="80" stroke="#f59e0b" strokeWidth="3" />
                  <line x1="50" y1="100" x2="70" y2="100" stroke="#64748b" strokeWidth="3" />
                  <text x="25" y="75" fill="#f59e0b" fontSize="11" fontWeight="bold" fontFamily="monospace">+</text>
                  <text x="28" y="110" fill="#94a3b8" fontSize="11" fontWeight="bold" fontFamily="monospace">-</text>

                  {/* Top & Bottom Common Rails */}
                  <line x1="60" y1="40" x2="340" y2="40" stroke="#38bdf8" strokeWidth="2.5" />
                  <line x1="60" y1="140" x2="340" y2="140" stroke="#38bdf8" strokeWidth="2.5" />

                  {/* Parallel Branches */}
                  {parallelResistors.map((val, idx) => {
                    const x = 140 + idx * 85;
                    const iBranch = val > 0 ? voltage / val : 0;
                    return (
                      <g key={idx}>
                        <circle cx={x} cy="40" r="3" fill="#38bdf8" />
                        <circle cx={x} cy="140" r="3" fill="#38bdf8" />
                        <line x1={x} y1="40" x2={x} y2="70" stroke="#38bdf8" strokeWidth="2" />
                        <rect x={x - 12} y="70" width="24" height="40" rx="4" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                        <text x={x} y="94" fill="#34d399" fontSize="9" fontWeight="bold" fontFamily="monospace" textAnchor="middle">
                          R{idx + 1}
                        </text>
                        <line x1={x} y1="110" x2={x} y2="140" stroke="#38bdf8" strokeWidth="2" />
                        <text x={x + 20} y="85" fill="#94a3b8" fontSize="8" fontFamily="monospace">
                          {formatResistance(val)}
                        </text>
                        <text x={x + 20} y="100" fill="#38bdf8" fontSize="8" fontFamily="monospace">
                          {formatCurrent(iBranch)}
                        </text>
                      </g>
                    );
                  })}
                </svg>
              )}

              {topology === 'combo_series_parallel' && (
                <svg viewBox="0 0 400 180" className="w-full max-w-sm drop-shadow-md">
                  {/* Source */}
                  <line x1="40" y1="40" x2="40" y2="140" stroke="#0ea5e9" strokeWidth="2" />
                  <line x1="25" y1="80" x2="55" y2="80" stroke="#f59e0b" strokeWidth="3" />
                  <line x1="30" y1="100" x2="50" y2="100" stroke="#64748b" strokeWidth="3" />
                  <text x="12" y="75" fill="#f59e0b" fontSize="11" fontWeight="bold" fontFamily="monospace">+</text>
                  <text x="15" y="110" fill="#94a3b8" fontSize="11" fontWeight="bold" fontFamily="monospace">-</text>

                  {/* Wire to R1 */}
                  <line x1="40" y1="40" x2="100" y2="40" stroke="#38bdf8" strokeWidth="2" />
                  {/* R1 Series */}
                  <rect x="100" y="30" width="45" height="20" rx="4" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                  <text x="122" y="44" fill="#34d399" fontSize="9" fontWeight="bold" fontFamily="monospace" textAnchor="middle">
                    R1
                  </text>
                  <line x1="145" y1="40" x2="190" y2="40" stroke="#38bdf8" strokeWidth="2" />

                  {/* Junction Split Node */}
                  <circle cx="190" cy="40" r="3.5" fill="#f59e0b" />
                  <line x1="190" y1="20" x2="190" y2="60" stroke="#38bdf8" strokeWidth="2" />
                  <line x1="190" y1="20" x2="230" y2="20" stroke="#38bdf8" strokeWidth="2" />
                  <line x1="190" y1="60" x2="230" y2="60" stroke="#38bdf8" strokeWidth="2" />

                  {/* R2 & R3 Parallel */}
                  <rect x="230" y="10" width="45" height="20" rx="4" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                  <text x="252" y="24" fill="#34d399" fontSize="9" fontWeight="bold" fontFamily="monospace" textAnchor="middle">
                    R2
                  </text>
                  <rect x="230" y="50" width="45" height="20" rx="4" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                  <text x="252" y="64" fill="#34d399" fontSize="9" fontWeight="bold" fontFamily="monospace" textAnchor="middle">
                    R3
                  </text>

                  {/* Reconnect Node */}
                  <line x1="275" y1="20" x2="315" y2="20" stroke="#38bdf8" strokeWidth="2" />
                  <line x1="275" y1="60" x2="315" y2="60" stroke="#38bdf8" strokeWidth="2" />
                  <line x1="315" y1="20" x2="315" y2="60" stroke="#38bdf8" strokeWidth="2" />
                  <circle cx="315" cy="40" r="3.5" fill="#f59e0b" />

                  {/* Return Path */}
                  <path d="M 315 40 L 360 40 L 360 140 L 40 140" fill="none" stroke="#38bdf8" strokeWidth="2" />
                </svg>
              )}

              {topology === 'combo_parallel_series' && (
                <svg viewBox="0 0 400 180" className="w-full max-w-sm drop-shadow-md">
                  {/* Source */}
                  <line x1="40" y1="30" x2="40" y2="150" stroke="#0ea5e9" strokeWidth="2" />
                  <line x1="25" y1="80" x2="55" y2="80" stroke="#f59e0b" strokeWidth="3" />
                  <line x1="30" y1="100" x2="50" y2="100" stroke="#64748b" strokeWidth="3" />

                  {/* Rails */}
                  <line x1="40" y1="30" x2="360" y2="30" stroke="#38bdf8" strokeWidth="2" />
                  <line x1="40" y1="150" x2="360" y2="150" stroke="#38bdf8" strokeWidth="2" />

                  {/* Branch A: R1 + R2 */}
                  <circle cx="140" cy="30" r="3" fill="#38bdf8" />
                  <circle cx="140" cy="150" r="3" fill="#38bdf8" />
                  <line x1="140" y1="30" x2="140" y2="50" stroke="#38bdf8" strokeWidth="2" />
                  <rect x="128" y="50" width="24" height="28" rx="3" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                  <text x="140" y="68" fill="#34d399" fontSize="8" fontWeight="bold" fontFamily="monospace" textAnchor="middle">R1</text>
                  <line x1="140" y1="78" x2="140" y2="100" stroke="#38bdf8" strokeWidth="2" />
                  <rect x="128" y="100" width="24" height="28" rx="3" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                  <text x="140" y="118" fill="#34d399" fontSize="8" fontWeight="bold" fontFamily="monospace" textAnchor="middle">R2</text>
                  <line x1="140" y1="128" x2="140" y2="150" stroke="#38bdf8" strokeWidth="2" />

                  {/* Branch B: R3 + R4 */}
                  <circle cx="260" cy="30" r="3" fill="#38bdf8" />
                  <circle cx="260" cy="150" r="3" fill="#38bdf8" />
                  <line x1="260" y1="30" x2="260" y2="50" stroke="#38bdf8" strokeWidth="2" />
                  <rect x="248" y="50" width="24" height="28" rx="3" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                  <text x="260" y="68" fill="#34d399" fontSize="8" fontWeight="bold" fontFamily="monospace" textAnchor="middle">R3</text>
                  <line x1="260" y1="78" x2="260" y2="100" stroke="#38bdf8" strokeWidth="2" />
                  <rect x="248" y="100" width="24" height="28" rx="3" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                  <text x="260" y="118" fill="#34d399" fontSize="8" fontWeight="bold" fontFamily="monospace" textAnchor="middle">R4</text>
                  <line x1="260" y1="128" x2="260" y2="150" stroke="#38bdf8" strokeWidth="2" />
                </svg>
              )}

              {topology === 'combo_ladder' && (
                <svg viewBox="0 0 400 180" className="w-full max-w-sm drop-shadow-md">
                  {/* Ladder SVG */}
                  <line x1="30" y1="40" x2="30" y2="140" stroke="#0ea5e9" strokeWidth="2" />
                  <line x1="18" y1="80" x2="42" y2="80" stroke="#f59e0b" strokeWidth="3" />
                  <line x1="22" y1="100" x2="38" y2="100" stroke="#64748b" strokeWidth="3" />

                  {/* R1 Top Series */}
                  <line x1="30" y1="40" x2="70" y2="40" stroke="#38bdf8" strokeWidth="2" />
                  <rect x="70" y="32" width="30" height="16" rx="3" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                  <text x="85" y="44" fill="#34d399" fontSize="8" fontWeight="bold" fontFamily="monospace" textAnchor="middle">R1</text>
                  <line x1="100" y1="40" x2="150" y2="40" stroke="#38bdf8" strokeWidth="2" />

                  {/* Shunt R2 */}
                  <circle cx="150" cy="40" r="3" fill="#f59e0b" />
                  <line x1="150" y1="40" x2="150" y2="65" stroke="#38bdf8" strokeWidth="2" />
                  <rect x="142" y="65" width="16" height="30" rx="3" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                  <text x="150" y="83" fill="#34d399" fontSize="8" fontWeight="bold" fontFamily="monospace" textAnchor="middle">R2</text>
                  <line x1="150" y1="95" x2="150" y2="140" stroke="#38bdf8" strokeWidth="2" />

                  {/* Arm R3 */}
                  <line x1="150" y1="40" x2="210" y2="40" stroke="#38bdf8" strokeWidth="2" />
                  <rect x="210" y="32" width="30" height="16" rx="3" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                  <text x="225" y="44" fill="#34d399" fontSize="8" fontWeight="bold" fontFamily="monospace" textAnchor="middle">R3</text>
                  <line x1="240" y1="40" x2="290" y2="40" stroke="#38bdf8" strokeWidth="2" />

                  {/* Parallel End: R4 and R5 */}
                  <circle cx="290" cy="40" r="3" fill="#f59e0b" />
                  <line x1="290" y1="40" x2="290" y2="65" stroke="#38bdf8" strokeWidth="2" />
                  <rect x="282" y="65" width="16" height="30" rx="3" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                  <text x="290" y="83" fill="#34d399" fontSize="8" fontWeight="bold" fontFamily="monospace" textAnchor="middle">R4</text>
                  <line x1="290" y1="95" x2="290" y2="140" stroke="#38bdf8" strokeWidth="2" />

                  <line x1="290" y1="40" x2="350" y2="40" stroke="#38bdf8" strokeWidth="2" />
                  <line x1="350" y1="40" x2="350" y2="65" stroke="#38bdf8" strokeWidth="2" />
                  <rect x="342" y="65" width="16" height="30" rx="3" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                  <text x="350" y="83" fill="#34d399" fontSize="8" fontWeight="bold" fontFamily="monospace" textAnchor="middle">R5</text>
                  <line x1="350" y1="95" x2="350" y2="140" stroke="#38bdf8" strokeWidth="2" />

                  {/* Bottom Common Rail */}
                  <line x1="30" y1="140" x2="350" y2="140" stroke="#38bdf8" strokeWidth="2" />
                </svg>
              )}

              {topology === 'bridge_wheatstone' && (
                <svg viewBox="0 0 400 180" className="w-full max-w-sm drop-shadow-md">
                  {/* Source */}
                  <line x1="40" y1="20" x2="40" y2="160" stroke="#0ea5e9" strokeWidth="2" />
                  <line x1="25" y1="80" x2="55" y2="80" stroke="#f59e0b" strokeWidth="3" />
                  <line x1="30" y1="100" x2="50" y2="100" stroke="#64748b" strokeWidth="3" />

                  {/* Diamond Bridge */}
                  {/* Top vertex */}
                  <line x1="40" y1="20" x2="200" y2="20" stroke="#38bdf8" strokeWidth="2" />
                  <circle cx="200" cy="20" r="3.5" fill="#f59e0b" />

                  {/* R1 Top Left */}
                  <line x1="200" y1="20" x2="120" y2="90" stroke="#38bdf8" strokeWidth="2" />
                  <rect x="135" y="42" width="28" height="18" rx="3" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                  <text x="149" y="55" fill="#34d399" fontSize="8" fontWeight="bold" fontFamily="monospace" textAnchor="middle">R1</text>

                  {/* R3 Top Right */}
                  <line x1="200" y1="20" x2="280" y2="90" stroke="#38bdf8" strokeWidth="2" />
                  <rect x="235" y="42" width="28" height="18" rx="3" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                  <text x="249" y="55" fill="#34d399" fontSize="8" fontWeight="bold" fontFamily="monospace" textAnchor="middle">R3</text>

                  {/* Midpoint Node A & B */}
                  <circle cx="120" cy="90" r="4" fill="#38bdf8" />
                  <text x="95" y="93" fill="#38bdf8" fontSize="9" fontWeight="bold" fontFamily="monospace">Node A</text>

                  <circle cx="280" cy="90" r="4" fill="#38bdf8" />
                  <text x="290" y="93" fill="#38bdf8" fontSize="9" fontWeight="bold" fontFamily="monospace">Node B</text>

                  {/* Bridge Detector Line */}
                  <line x1="120" y1="90" x2="280" y2="90" stroke="#a855f7" strokeWidth="2" strokeDasharray="4 3" />
                  <circle cx="200" cy="90" r="14" fill="#0f172a" stroke="#a855f7" strokeWidth="1.5" />
                  <text x="200" y="93" fill="#c084fc" fontSize="8" fontWeight="bold" fontFamily="monospace" textAnchor="middle">V_AB</text>

                  {/* R2 Bottom Left */}
                  <line x1="120" y1="90" x2="200" y2="160" stroke="#38bdf8" strokeWidth="2" />
                  <rect x="135" y="118" width="28" height="18" rx="3" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                  <text x="149" y="131" fill="#34d399" fontSize="8" fontWeight="bold" fontFamily="monospace" textAnchor="middle">R2</text>

                  {/* R4 Bottom Right */}
                  <line x1="280" y1="90" x2="200" y2="160" stroke="#38bdf8" strokeWidth="2" />
                  <rect x="235" y="118" width="28" height="18" rx="3" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                  <text x="249" y="131" fill="#34d399" fontSize="8" fontWeight="bold" fontFamily="monospace" textAnchor="middle">R4</text>

                  {/* Bottom vertex */}
                  <circle cx="200" cy="160" r="3.5" fill="#f59e0b" />
                  <line x1="200" y1="160" x2="40" y2="160" stroke="#38bdf8" strokeWidth="2" />
                </svg>
              )}
            </div>
          </div>

          {/* Circuit Parameter Controls Bento Card */}
          <div className="bg-slate-900/50 p-5 rounded-3xl border border-slate-800 space-y-4">
            <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
              <Sliders className="w-3.5 h-3.5 text-emerald-400" />
              Adjust Voltage & Resistor Parameters
            </h3>

            {/* Voltage Slider & Typed Input */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-xs font-mono">
                <span className="text-amber-400 font-bold">Supply Voltage (V_source):</span>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min="0.1"
                    max="1000"
                    step="any"
                    value={voltage}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value) || 0;
                      setVoltage(val);
                    }}
                    className="w-16 bg-slate-950 text-white font-bold text-xs px-2 py-0.5 rounded-lg border border-slate-800 text-right focus:border-amber-500 focus:outline-none"
                  />
                  <span className="text-slate-400 font-bold">V</span>
                </div>
              </div>
              <input
                type="range"
                min="1"
                max="48"
                step="1"
                value={voltage}
                onChange={(e) => {
                  setVoltage(parseFloat(e.target.value));
                  sounds.playTick();
                }}
                className="w-full accent-amber-500"
              />
            </div>

            {/* Individual Resistor Inputs based on Topology */}
            {topology === 'series' && (
              <div className="space-y-3 pt-2 border-t border-slate-800">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-slate-400 font-semibold">Series Resistors:</span>
                  <div className="flex gap-1.5">
                    <button
                      onClick={() => {
                        if (seriesResistors.length < 5) {
                          setSeriesResistors([...seriesResistors, 100]);
                          sounds.playSwitchClick(true);
                        }
                      }}
                      className="px-2 py-0.5 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-mono font-bold"
                    >
                      + Add Resistor
                    </button>
                    {seriesResistors.length > 2 && (
                      <button
                        onClick={() => {
                          setSeriesResistors(seriesResistors.slice(0, -1));
                          sounds.playSwitchClick(false);
                        }}
                        className="px-2 py-0.5 rounded-lg bg-rose-500/20 text-rose-400 border border-rose-500/30 text-[10px] font-mono font-bold"
                      >
                        - Remove
                      </button>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  {seriesResistors.map((val, idx) => (
                    <div key={idx} className="bg-slate-950 p-2.5 rounded-2xl border border-slate-800 space-y-1.5">
                      <div className="flex justify-between items-center text-[11px] font-mono">
                        <span className="text-emerald-400 font-bold">R{idx + 1}:</span>
                        <div className="flex items-center gap-1">
                          <input
                            type="number"
                            min="0.1"
                            max="100000"
                            step="any"
                            value={val}
                            onChange={(e) => {
                              const updated = [...seriesResistors];
                              updated[idx] = parseFloat(e.target.value) || 0;
                              setSeriesResistors(updated);
                            }}
                            className="w-16 bg-slate-900 border border-slate-800 text-white font-bold text-[11px] px-1.5 py-0.5 rounded text-right focus:border-emerald-500 focus:outline-none"
                          />
                          <span className="text-slate-400">Ω</span>
                        </div>
                      </div>
                      <input
                        type="range"
                        min="10"
                        max="1000"
                        step="10"
                        value={val}
                        onChange={(e) => {
                          const updated = [...seriesResistors];
                          updated[idx] = parseFloat(e.target.value);
                          setSeriesResistors(updated);
                          sounds.playTick();
                        }}
                        className="w-full accent-emerald-500"
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {topology === 'parallel' && (
              <div className="space-y-3 pt-2 border-t border-slate-800">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-slate-400 font-semibold">Parallel Branches:</span>
                  <div className="flex gap-1.5">
                    <button
                      onClick={() => {
                        if (parallelResistors.length < 5) {
                          setParallelResistors([...parallelResistors, 100]);
                          sounds.playSwitchClick(true);
                        }
                      }}
                      className="px-2 py-0.5 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-mono font-bold"
                    >
                      + Add Branch
                    </button>
                    {parallelResistors.length > 2 && (
                      <button
                        onClick={() => {
                          setParallelResistors(parallelResistors.slice(0, -1));
                          sounds.playSwitchClick(false);
                        }}
                        className="px-2 py-0.5 rounded-lg bg-rose-500/20 text-rose-400 border border-rose-500/30 text-[10px] font-mono font-bold"
                      >
                        - Remove
                      </button>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  {parallelResistors.map((val, idx) => (
                    <div key={idx} className="bg-slate-950 p-2.5 rounded-2xl border border-slate-800 space-y-1.5">
                      <div className="flex justify-between items-center text-[11px] font-mono">
                        <span className="text-emerald-400 font-bold">R{idx + 1}:</span>
                        <div className="flex items-center gap-1">
                          <input
                            type="number"
                            min="0.1"
                            max="100000"
                            step="any"
                            value={val}
                            onChange={(e) => {
                              const updated = [...parallelResistors];
                              updated[idx] = parseFloat(e.target.value) || 0;
                              setParallelResistors(updated);
                            }}
                            className="w-16 bg-slate-900 border border-slate-800 text-white font-bold text-[11px] px-1.5 py-0.5 rounded text-right focus:border-emerald-500 focus:outline-none"
                          />
                          <span className="text-slate-400">Ω</span>
                        </div>
                      </div>
                      <input
                        type="range"
                        min="10"
                        max="1000"
                        step="10"
                        value={val}
                        onChange={(e) => {
                          const updated = [...parallelResistors];
                          updated[idx] = parseFloat(e.target.value);
                          setParallelResistors(updated);
                          sounds.playTick();
                        }}
                        className="w-full accent-emerald-500"
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {topology !== 'series' && topology !== 'parallel' && (
              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800">
                <div className="bg-slate-950 p-2.5 rounded-2xl border border-slate-800 space-y-1.5">
                  <div className="flex justify-between items-center text-[11px] font-mono">
                    <span className="text-emerald-400 font-bold">R1:</span>
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        min="0.1"
                        max="100000"
                        step="any"
                        value={r1}
                        onChange={(e) => setR1(parseFloat(e.target.value) || 0)}
                        className="w-16 bg-slate-900 border border-slate-800 text-white font-bold text-[11px] px-1.5 py-0.5 rounded text-right focus:border-emerald-500 focus:outline-none"
                      />
                      <span className="text-slate-400">Ω</span>
                    </div>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="1000"
                    step="10"
                    value={r1}
                    onChange={(e) => {
                      setR1(parseFloat(e.target.value));
                      sounds.playTick();
                    }}
                    className="w-full accent-emerald-500"
                  />
                </div>

                <div className="bg-slate-950 p-2.5 rounded-2xl border border-slate-800 space-y-1.5">
                  <div className="flex justify-between items-center text-[11px] font-mono">
                    <span className="text-emerald-400 font-bold">R2:</span>
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        min="0.1"
                        max="100000"
                        step="any"
                        value={r2}
                        onChange={(e) => setR2(parseFloat(e.target.value) || 0)}
                        className="w-16 bg-slate-900 border border-slate-800 text-white font-bold text-[11px] px-1.5 py-0.5 rounded text-right focus:border-emerald-500 focus:outline-none"
                      />
                      <span className="text-slate-400">Ω</span>
                    </div>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="1000"
                    step="10"
                    value={r2}
                    onChange={(e) => {
                      setR2(parseFloat(e.target.value));
                      sounds.playTick();
                    }}
                    className="w-full accent-emerald-500"
                  />
                </div>

                <div className="bg-slate-950 p-2.5 rounded-2xl border border-slate-800 space-y-1.5">
                  <div className="flex justify-between items-center text-[11px] font-mono">
                    <span className="text-emerald-400 font-bold">R3:</span>
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        min="0.1"
                        max="100000"
                        step="any"
                        value={r3}
                        onChange={(e) => setR3(parseFloat(e.target.value) || 0)}
                        className="w-16 bg-slate-900 border border-slate-800 text-white font-bold text-[11px] px-1.5 py-0.5 rounded text-right focus:border-emerald-500 focus:outline-none"
                      />
                      <span className="text-slate-400">Ω</span>
                    </div>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="1000"
                    step="10"
                    value={r3}
                    onChange={(e) => {
                      setR3(parseFloat(e.target.value));
                      sounds.playTick();
                    }}
                    className="w-full accent-emerald-500"
                  />
                </div>

                {(topology === 'combo_parallel_series' || topology === 'combo_ladder' || topology === 'bridge_wheatstone') && (
                  <div className="bg-slate-950 p-2.5 rounded-2xl border border-slate-800 space-y-1.5">
                    <div className="flex justify-between items-center text-[11px] font-mono">
                      <span className="text-emerald-400 font-bold">R4:</span>
                      <div className="flex items-center gap-1">
                        <input
                          type="number"
                          min="0.1"
                          max="100000"
                          step="any"
                          value={r4}
                          onChange={(e) => setR4(parseFloat(e.target.value) || 0)}
                          className="w-16 bg-slate-900 border border-slate-800 text-white font-bold text-[11px] px-1.5 py-0.5 rounded text-right focus:border-emerald-500 focus:outline-none"
                        />
                        <span className="text-slate-400">Ω</span>
                      </div>
                    </div>
                    <input
                      type="range"
                      min="10"
                      max="1000"
                      step="10"
                      value={r4}
                      onChange={(e) => {
                        setR4(parseFloat(e.target.value));
                        sounds.playTick();
                      }}
                      className="w-full accent-emerald-500"
                    />
                  </div>
                )}

                {topology === 'combo_ladder' && (
                  <div className="col-span-2 bg-slate-950 p-2.5 rounded-2xl border border-slate-800 space-y-1.5">
                    <div className="flex justify-between items-center text-[11px] font-mono">
                      <span className="text-emerald-400 font-bold">R5:</span>
                      <div className="flex items-center gap-1">
                        <input
                          type="number"
                          min="0.1"
                          max="100000"
                          step="any"
                          value={r5}
                          onChange={(e) => setR5(parseFloat(e.target.value) || 0)}
                          className="w-16 bg-slate-900 border border-slate-800 text-white font-bold text-[11px] px-1.5 py-0.5 rounded text-right focus:border-emerald-500 focus:outline-none"
                        />
                        <span className="text-slate-400">Ω</span>
                      </div>
                    </div>
                    <input
                      type="range"
                      min="10"
                      max="1000"
                      step="10"
                      value={r5}
                      onChange={(e) => {
                        setR5(parseFloat(e.target.value));
                        sounds.playTick();
                      }}
                      className="w-full accent-emerald-500"
                    />
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Step-by-Step Mathematical Reduction Breakdown & Ledger (7 Cols) */}
        <div className="lg:col-span-7 space-y-4">
          {/* Step-by-Step Stages Container */}
          <div className="bg-slate-900/50 p-5 rounded-3xl border border-slate-800 space-y-4 shadow-sm">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2 font-mono">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                Step-by-Step Reduction Workflow
              </h3>
              <span className="text-[11px] font-mono text-slate-400">
                {steps.length} Analytical Stages
              </span>
            </div>

            {/* Stages Stack */}
            <div className="space-y-3">
              {steps.map((step) => (
                <div
                  key={step.stepNumber}
                  className="bg-slate-950 p-4 rounded-2xl border border-slate-800/80 space-y-2 relative overflow-hidden"
                >
                  <div className="flex items-center justify-between">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      {step.badgeTitle}
                    </span>
                    <span className="text-[10px] font-mono text-slate-500">
                      Phase {step.stepNumber} of {steps.length}
                    </span>
                  </div>

                  <h4 className="text-xs sm:text-sm font-bold text-white">
                    {step.heading}
                  </h4>

                  {/* Formula and Numerical Substitution */}
                  <div className="bg-slate-900/90 p-3 rounded-xl border border-slate-800 font-mono text-xs space-y-1.5">
                    <div className="text-emerald-400 font-bold flex items-center gap-2">
                      <span className="text-slate-500 uppercase text-[9px]">Formula:</span>
                      <span>{step.latexFormula}</span>
                    </div>
                    <div className="text-slate-200">
                      <span className="text-slate-500 uppercase text-[9px]">Substitution: </span>
                      <span>{step.calculation}</span>
                    </div>
                    <div className="text-cyan-300 font-bold border-t border-slate-800/60 pt-1 mt-1">
                      ➔ {step.resultValue}
                    </div>
                  </div>

                  <p className="text-xs text-slate-400 leading-relaxed font-mono">
                    <strong className="text-slate-300">Physics Rationale:</strong> {step.rationale}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Complete Resistor Parameter Ledger Table */}
          <div className="bg-slate-900/50 p-5 rounded-3xl border border-slate-800 space-y-3 shadow-sm">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <Table className="w-3.5 h-3.5 text-emerald-400" />
                Individual Component Ledger
              </h3>
              <span className="text-[10px] font-mono text-slate-400">
                Ohm's Law & Power Breakdown
              </span>
            </div>

            <div className="overflow-x-auto no-scrollbar">
              <table className="w-full text-left text-xs font-mono border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 text-[10px] uppercase">
                    <th className="py-2 px-3">Resistor</th>
                    <th className="py-2 px-3">Resistance</th>
                    <th className="py-2 px-3 text-amber-400">Voltage (V)</th>
                    <th className="py-2 px-3 text-cyan-400">Current (I)</th>
                    <th className="py-2 px-3 text-emerald-400">Power (P)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {ledger.map((item) => (
                    <tr key={item.id} className="hover:bg-slate-800/30 transition-colors">
                      <td className="py-2.5 px-3 font-bold text-white">{item.label}</td>
                      <td className="py-2.5 px-3 text-slate-300">{formatResistance(item.resistance)}</td>
                      <td className="py-2.5 px-3 font-bold text-amber-400">{formatVoltage(item.voltage)}</td>
                      <td className="py-2.5 px-3 font-bold text-cyan-400">{formatCurrent(item.current)}</td>
                      <td className="py-2.5 px-3 font-bold text-emerald-400">{formatPower(item.power)}</td>
                    </tr>
                  ))}
                  <tr className="bg-slate-950 font-bold border-t-2 border-emerald-500/40">
                    <td className="py-2.5 px-3 text-emerald-400">TOTAL CIRCUIT</td>
                    <td className="py-2.5 px-3 text-emerald-400">{formatResistance(rTotal)}</td>
                    <td className="py-2.5 px-3 text-amber-400">{formatVoltage(voltage)}</td>
                    <td className="py-2.5 px-3 text-cyan-400">{formatCurrent(iTotal)}</td>
                    <td className="py-2.5 px-3 text-emerald-400">{formatPower(pTotal)}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Circuit Solver Golden Rules & Pedagogy Card */}
      <div className="bg-slate-900/50 p-5 sm:p-6 rounded-3xl border border-slate-800 space-y-4 shadow-sm">
        <h3 className="text-sm font-bold text-white flex items-center gap-2 font-mono">
          <BookOpen className="w-4 h-4 text-emerald-400" />
          The 5-Step Master Strategy for Solving Any Complex Circuit
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs font-mono">
          <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 space-y-1.5">
            <span className="text-emerald-400 font-bold block text-[11px]">
              1. Identify Pure Connections
            </span>
            <p className="text-slate-400 leading-relaxed">
              Find resistors that share <strong>only one node</strong> with no branches between them (Pure Series) or share <strong>both identical nodes</strong> (Pure Parallel).
            </p>
          </div>

          <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 space-y-1.5">
            <span className="text-cyan-400 font-bold block text-[11px]">
              2. Collapse from Furthest End
            </span>
            <p className="text-slate-400 leading-relaxed">
              Simplify the innermost or rightmost clusters first into equivalent resistors [Rp = (R1 × R2) / (R1 + R2)], working systematically backward toward the voltage source until only Req remains.
            </p>
          </div>

          <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 space-y-1.5">
            <span className="text-amber-400 font-bold block text-[11px]">
              3. Expand Backwards for Drops
            </span>
            <p className="text-slate-400 leading-relaxed">
              Calculate total current [I_total = Vs / Req], then unpack each stage applying <strong>KVL</strong> (V = I × R) and <strong>KCL</strong> (I = V / R) to find every local parameter.
            </p>
          </div>
        </div>
      </div>
    </>
  )}
</div>
);
};
