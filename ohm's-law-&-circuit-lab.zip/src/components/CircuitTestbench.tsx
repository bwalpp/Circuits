import React, { useState, useEffect } from 'react';
import {
  Power,
  RotateCw,
  Zap,
  Gauge,
  Flame,
  AlertTriangle,
  Lightbulb,
  Radio,
  Sliders,
  CheckCircle2,
  Sparkles,
  Volume2
} from 'lucide-react';
import { CircuitTopology, LoadType } from '../types';
import {
  formatVoltage,
  formatCurrent,
  formatResistance,
  formatPower,
  LED_DATA,
  LEDSpecs,
} from '../utils/circuitMath';
import { sounds } from '../utils/audioHaptics';

type NodePoint = 'BAT_POS' | 'SW_OUT' | 'MID_NODE' | 'LOAD_POS' | 'GND';

export const CircuitTestbench: React.FC = () => {
  // Circuit Parameters
  const [topology, setTopology] = useState<CircuitTopology>('series');
  const [sourceV, setSourceV] = useState<number>(12); // 12V
  const [switchClosed, setSwitchClosed] = useState<boolean>(true);
  const [r1, setR1] = useState<number>(100); // 100 Ohms
  const [r2, setR2] = useState<number>(220); // 220 Ohms
  const [potPos, setPotPos] = useState<number>(0.5); // 50%
  const [loadType, setLoadType] = useState<LoadType>('bulb');
  const [ledColor, setLedColor] = useState<string>('red');
  const [fuseRating, setFuseRating] = useState<number>(1.0); // 1 Amp
  const [fuseBlown, setFuseBlown] = useState<boolean>(false);

  // Multimeter probes
  const [dmmMode, setDmmMode] = useState<'voltage' | 'current' | 'resistance' | 'continuity'>('voltage');
  const [probeRed, setProbeRed] = useState<NodePoint>('SW_OUT');
  const [probeBlack, setProbeBlack] = useState<NodePoint>('GND');

  // Animation frame ref for motor
  const [motorAngle, setMotorAngle] = useState(0);

  // Calculate Circuit Physics
  const ledSpec: LEDSpecs = LED_DATA[ledColor] || LED_DATA.red;

  let totalR = 0;
  let loadVDrop = 0;
  let r1VDrop = 0;
  let r2VDrop = 0;
  let loopCurrent = 0;
  let isLoadBurned = false;
  let midNodeV = 0;

  // Compute effective load resistance
  let loadBaseR = 50;
  if (loadType === 'bulb') loadBaseR = 40;
  else if (loadType === 'motor') loadBaseR = 25;
  else if (loadType === 'heating_element') loadBaseR = 15;
  else if (loadType === 'resistor_only') loadBaseR = 0;

  if (switchClosed && !fuseBlown) {
    if (topology === 'single') {
      totalR = r1 + loadBaseR;
      loopCurrent = sourceV / Math.max(0.1, totalR);
      r1VDrop = loopCurrent * r1;
      loadVDrop = loopCurrent * loadBaseR;
      midNodeV = sourceV - r1VDrop;
    } else if (topology === 'series') {
      totalR = r1 + r2 + loadBaseR;
      loopCurrent = sourceV / Math.max(0.1, totalR);
      r1VDrop = loopCurrent * r1;
      r2VDrop = loopCurrent * r2;
      midNodeV = sourceV - r1VDrop;
      loadVDrop = loopCurrent * loadBaseR;
    } else if (topology === 'parallel') {
      const branch1R = r1;
      const branch2R = r2 + loadBaseR;
      const req = (branch1R * branch2R) / Math.max(0.1, branch1R + branch2R);
      totalR = req;
      loopCurrent = sourceV / Math.max(0.1, req);
      const iBranch2 = sourceV / Math.max(0.1, branch2R);
      loadVDrop = iBranch2 * loadBaseR;
      r1VDrop = sourceV;
      r2VDrop = iBranch2 * r2;
      midNodeV = sourceV;
    } else if (topology === 'potentiometer') {
      const topR = Math.max(1, 500 * (1 - potPos));
      const botR = Math.max(1, 500 * potPos);
      totalR = topR + botR;
      loopCurrent = sourceV / totalR;
      midNodeV = sourceV * (botR / totalR);
      loadVDrop = midNodeV;
    } else if (topology === 'led_circuit') {
      if (sourceV > ledSpec.forwardVoltage) {
        const vDiff = sourceV - ledSpec.forwardVoltage;
        loopCurrent = vDiff / Math.max(1, r1);
        r1VDrop = loopCurrent * r1;
        loadVDrop = ledSpec.forwardVoltage;
        if (loopCurrent > ledSpec.maxCurrent) {
          isLoadBurned = true;
        }
      } else {
        loopCurrent = 0;
        r1VDrop = 0;
        loadVDrop = sourceV;
      }
    } else if (topology === 'fuse_circuit') {
      totalR = r1 + loadBaseR;
      loopCurrent = sourceV / Math.max(0.1, totalR);
      if (loopCurrent > fuseRating) {
        // Blow fuse
        setFuseBlown(true);
        sounds.playFuseBlow();
      }
    }
  }

  // Handle Motor Rotation & Sound Loop
  useEffect(() => {
    let animId: number;
    if (switchClosed && !fuseBlown && loadType === 'motor' && loopCurrent > 0.05) {
      const speed = loopCurrent * 20;
      sounds.setMotorHum(true, Math.min(1.5, loopCurrent * 2));
      const step = () => {
        setMotorAngle((prev) => (prev + speed) % 360);
        animId = requestAnimationFrame(step);
      };
      animId = requestAnimationFrame(step);
    } else {
      sounds.setMotorHum(false);
    }
    return () => {
      cancelAnimationFrame(animId);
      sounds.setMotorHum(false);
    };
  }, [switchClosed, fuseBlown, loadType, loopCurrent]);

  // Multimeter reading evaluation
  let dmmReadingText = '0.00 V';
  let dmmIsContinuityBeeping = false;

  const getNodePotential = (node: NodePoint): number => {
    if (!switchClosed || fuseBlown) return 0;
    switch (node) {
      case 'BAT_POS':
        return sourceV;
      case 'SW_OUT':
        return sourceV;
      case 'MID_NODE':
        return midNodeV;
      case 'LOAD_POS':
        return loadVDrop;
      case 'GND':
      default:
        return 0;
    }
  };

  if (dmmMode === 'voltage') {
    const vRed = getNodePotential(probeRed);
    const vBlack = getNodePotential(probeBlack);
    const vDiff = vRed - vBlack;
    dmmReadingText = formatVoltage(vDiff);
  } else if (dmmMode === 'current') {
    const isSeriesInLoop =
      (probeRed === 'BAT_POS' && probeBlack === 'SW_OUT') ||
      (probeRed === 'SW_OUT' && probeBlack === 'BAT_POS');
    if (isSeriesInLoop) {
      dmmReadingText = formatCurrent(loopCurrent);
    } else {
      dmmReadingText = '0.00 mA (Open Probe)';
    }
  } else if (dmmMode === 'resistance') {
    if (!switchClosed) {
      if (
        (probeRed === 'SW_OUT' && probeBlack === 'MID_NODE') ||
        (probeRed === 'MID_NODE' && probeBlack === 'SW_OUT')
      ) {
        dmmReadingText = formatResistance(r1);
      } else if (
        (probeRed === 'MID_NODE' && probeBlack === 'GND') ||
        (probeRed === 'GND' && probeBlack === 'MID_NODE')
      ) {
        dmmReadingText = formatResistance(r2);
      } else if (
        (probeRed === 'SW_OUT' && probeBlack === 'GND') ||
        (probeRed === 'GND' && probeBlack === 'SW_OUT')
      ) {
        dmmReadingText = formatResistance(r1 + r2);
      } else {
        dmmReadingText = 'O.L (Open)';
      }
    } else {
      dmmReadingText = 'ERR (Live Circuit)';
    }
  } else if (dmmMode === 'continuity') {
    const isDirect =
      probeRed === probeBlack ||
      (probeRed === 'BAT_POS' && probeBlack === 'SW_OUT' && switchClosed) ||
      (probeRed === 'SW_OUT' && probeBlack === 'BAT_POS' && switchClosed);
    if (isDirect) {
      dmmReadingText = '0.1 Ω (SHORT)';
      dmmIsContinuityBeeping = true;
    } else {
      dmmReadingText = 'O.L (OPEN)';
    }
  }

  // Handle continuity sound
  useEffect(() => {
    sounds.setContinuityBeep(dmmIsContinuityBeeping);
    return () => sounds.setContinuityBeep(false);
  }, [dmmIsContinuityBeeping]);

  const toggleSwitch = () => {
    const next = !switchClosed;
    setSwitchClosed(next);
    sounds.playSwitchClick(next);
  };

  const resetFuse = () => {
    setFuseBlown(false);
    sounds.playSwitchClick(true);
  };

  const connectProbe = (probe: 'red' | 'black', node: NodePoint) => {
    sounds.vibrate(15);
    if (probe === 'red') setProbeRed(node);
    else setProbeBlack(node);
  };

  const isPointConnected = (node: NodePoint) => {
    return {
      isRed: probeRed === node,
      isBlack: probeBlack === node,
    };
  };

  return (
    <div className="space-y-4">
      {/* Top Bento Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-slate-900/50 p-4 rounded-3xl border border-slate-800">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <Zap className="w-4 h-4" />
            </span>
            Interactive Circuit Sandbox & Testbench
          </h2>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Test voltage dividers, parallel loops, LEDs, and measure with live multimeter leads.
          </p>
        </div>

        {/* Experiment Presets Buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
          <span className="text-[11px] font-mono text-slate-400">Topology:</span>
          {(
            [
              { id: 'single', label: 'Single R' },
              { id: 'series', label: 'Series Divider' },
              { id: 'parallel', label: 'Parallel' },
              { id: 'potentiometer', label: 'Potentiometer' },
              { id: 'led_circuit', label: 'LED Driver' },
              { id: 'fuse_circuit', label: 'Fuse Overload' },
            ] as { id: CircuitTopology; label: string }[]
          ).map((t) => (
            <button
              key={t.id}
              onClick={() => {
                setTopology(t.id);
                sounds.playSwitchClick(true);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold whitespace-nowrap transition-all ${
                topology === t.id
                  ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                  : 'bg-slate-950 border border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Interactive Circuit Schematic Board */}
      <div className="bg-slate-900/50 rounded-3xl border border-slate-800 p-5 sm:p-6 relative overflow-hidden shadow-sm">
        {/* Top Circuit Toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800 relative z-10">
          <div className="flex items-center gap-2">
            {/* SPST Master Switch Toggle */}
            <button
              onClick={toggleSwitch}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-mono font-bold flex items-center gap-2 transition-all ${
                switchClosed
                  ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/30'
                  : 'bg-rose-950/60 border border-rose-500/50 text-rose-300'
              }`}
            >
              <Power className="w-3.5 h-3.5" />
              <span>{switchClosed ? 'SWITCH: CLOSED (ON)' : 'SWITCH: OPEN (OFF)'}</span>
            </button>

            {/* Fuse status indicator */}
            {topology === 'fuse_circuit' && (
              <div className="flex items-center gap-2">
                {fuseBlown ? (
                  <button
                    onClick={resetFuse}
                    className="px-2.5 py-1 rounded-xl bg-rose-500/20 border border-rose-500 text-rose-300 text-xs font-mono font-bold flex items-center gap-1.5"
                  >
                    <AlertTriangle className="w-3.5 h-3.5" /> Replace Fuse
                  </button>
                ) : (
                  <span className="px-2.5 py-1 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono">
                    Fuse: OK ({fuseRating}A)
                  </span>
                )}
              </div>
            )}
          </div>

          {/* Quick Metrics */}
          <div className="flex items-center gap-2 sm:gap-3 text-xs font-mono">
            <div className="bg-slate-950 px-2.5 py-1 rounded-xl border border-slate-800 text-slate-300">
              Loop I: <span className="text-emerald-400 font-bold">{formatCurrent(loopCurrent)}</span>
            </div>
            <div className="bg-slate-950 px-2.5 py-1 rounded-xl border border-slate-800 text-slate-300">
              Req: <span className="text-amber-400 font-bold">{formatResistance(totalR)}</span>
            </div>
          </div>
        </div>

        {/* Vector SVG Breadboard Simulation Schematic */}
        <div className="w-full min-h-[280px] sm:min-h-[320px] my-3 flex items-center justify-center relative bg-slate-950/60 rounded-2xl border border-slate-800/80 p-2 overflow-x-auto">
          <svg viewBox="0 0 760 300" className="w-full max-w-3xl min-w-[600px] select-none">
            {/* Grid Dots */}
            <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
              <circle cx="2" cy="2" r="1" fill="#334155" />
            </pattern>
            <rect width="760" height="300" fill="url(#grid)" opacity="0.3" />

            {/* Main Circuit Wires */}
            <path
              d="M 100 150 L 100 60 L 220 60"
              stroke="#64748b"
              strokeWidth="4"
              strokeLinecap="round"
              fill="none"
            />
            {/* Switch gap */}
            <line x1="220" y1="60" x2="250" y2="60" stroke="#64748b" strokeWidth="2" />
            <line
              x1="220"
              y1="60"
              x2="250"
              y2={switchClosed ? 60 : 35}
              stroke={switchClosed ? '#10b981' : '#ef4444'}
              strokeWidth="4"
              strokeLinecap="round"
            />
            <path
              d="M 250 60 L 320 60"
              stroke="#64748b"
              strokeWidth="4"
              strokeLinecap="round"
              fill="none"
            />

            {/* R1 Resistor location */}
            <path
              d="M 400 60 L 520 60"
              stroke="#64748b"
              strokeWidth="4"
              strokeLinecap="round"
              fill="none"
            />

            {/* Right return path */}
            <path
              d="M 650 60 L 680 60 L 680 240 L 100 240 L 100 190"
              stroke="#64748b"
              strokeWidth="4"
              strokeLinecap="round"
              fill="none"
            />

            {/* Battery Symbol */}
            <g transform="translate(100, 170)">
              <line x1="-20" y1="-10" x2="20" y2="-10" stroke="#10b981" strokeWidth="4" />
              <line x1="-10" y1="10" x2="10" y2="10" stroke="#ef4444" strokeWidth="4" />
              <text x="-30" y="-8" fill="#10b981" fontSize="12" fontWeight="bold" textAnchor="end" fontFamily="monospace">
                +{sourceV}V
              </text>
              <text x="-30" y="14" fill="#64748b" fontSize="12" fontWeight="bold" textAnchor="end" fontFamily="monospace">
                GND
              </text>
            </g>

            {/* R1 Resistor Symbol */}
            <g transform="translate(360, 60)">
              <rect x="-35" y="-12" width="70" height="24" rx="4" fill="#1e293b" stroke="#10b981" strokeWidth="2" />
              <text x="0" y="4" fill="#10b981" fontSize="11" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                R1: {formatResistance(r1)}
              </text>
            </g>

            {/* R2 Resistor Symbol (if series) */}
            {topology === 'series' && (
              <g transform="translate(580, 60)">
                <rect x="-35" y="-12" width="70" height="24" rx="4" fill="#1e293b" stroke="#14b8a6" strokeWidth="2" />
                <text x="0" y="4" fill="#14b8a6" fontSize="11" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                  R2: {formatResistance(r2)}
                </text>
              </g>
            )}

            {/* Load Component at Right Branch */}
            <g transform="translate(680, 150)">
              {loadType === 'bulb' && (
                <g>
                  <circle
                    cx="0"
                    cy="0"
                    r="24"
                    fill={switchClosed && !fuseBlown && loopCurrent > 0.05 ? 'rgba(245, 158, 11, 0.4)' : '#1e293b'}
                    stroke="#f59e0b"
                    strokeWidth="2.5"
                  />
                  <path d="M-10 10 L0 -8 L10 10" stroke="#fbbf24" strokeWidth="2" fill="none" />
                  <text x="-35" y="0" fill="#f59e0b" fontSize="11" fontWeight="bold" textAnchor="end" fontFamily="monospace">
                    Bulb ({formatVoltage(loadVDrop)})
                  </text>
                </g>
              )}

              {loadType === 'led' && (
                <g>
                  <circle
                    cx="0"
                    cy="0"
                    r="22"
                    fill={switchClosed && !fuseBlown && loopCurrent > 0.005 ? `${ledSpec.hex}66` : '#1e293b'}
                    stroke={ledSpec.hex}
                    strokeWidth="2.5"
                  />
                  <text x="-35" y="0" fill={ledSpec.hex} fontSize="11" fontWeight="bold" textAnchor="end" fontFamily="monospace">
                    {ledSpec.color} LED ({formatVoltage(loadVDrop)})
                  </text>
                </g>
              )}

              {loadType === 'motor' && (
                <g>
                  <circle cx="0" cy="0" r="24" fill="#0f172a" stroke="#10b981" strokeWidth="2.5" />
                  <text x="0" y="2" fill="#10b981" fontSize="14" fontWeight="bold" textAnchor="middle" dominantBaseline="middle" fontFamily="monospace">
                    M
                  </text>
                  <g transform={`rotate(${motorAngle})`}>
                    <line x1="-16" y1="0" x2="16" y2="0" stroke="#34d399" strokeWidth="3" />
                    <line x1="0" y1="-16" x2="0" y2="16" stroke="#34d399" strokeWidth="3" />
                  </g>
                  <text x="-35" y="0" fill="#10b981" fontSize="11" fontWeight="bold" textAnchor="end" fontFamily="monospace">
                    Motor ({(loopCurrent * 2500).toFixed(0)} RPM)
                  </text>
                </g>
              )}

              {loadType === 'heating_element' && (
                <g>
                  <rect x="-18" y="-24" width="36" height="48" rx="6" fill={switchClosed && !fuseBlown && loopCurrent > 0.1 ? 'rgba(239, 68, 68, 0.4)' : '#1e293b'} stroke="#ef4444" strokeWidth="2.5" />
                  <path d="M-8 -15 Q0 -8 -8 0 Q0 8 -8 15" stroke="#fca5a5" strokeWidth="2.5" fill="none" />
                  <text x="-35" y="0" fill="#ef4444" fontSize="11" fontWeight="bold" textAnchor="end" fontFamily="monospace">
                    Heater ({formatPower(loadVDrop * loopCurrent)})
                  </text>
                </g>
              )}
            </g>

            {/* Test Points / Probe Hookup Nodes */}
            {[
              { id: 'BAT_POS', label: 'TP1 (+V)', x: 100, y: 60 },
              { id: 'SW_OUT', label: 'TP2 (Sw Out)', x: 260, y: 60 },
              { id: 'MID_NODE', label: 'TP3 (Mid Node)', x: 460, y: 60 },
              { id: 'LOAD_POS', label: 'TP4 (Load +)', x: 650, y: 60 },
              { id: 'GND', label: 'TP5 (GND)', x: 380, y: 240 },
            ].map((node) => {
              const { isRed, isBlack } = isPointConnected(node.id as NodePoint);
              return (
                <g key={node.id} transform={`translate(${node.x}, ${node.y})`}>
                  <circle
                    cx="0"
                    cy="0"
                    r="14"
                    fill={isRed ? '#ef4444' : isBlack ? '#0284c7' : '#1e293b'}
                    stroke={isRed ? '#ffffff' : isBlack ? '#38bdf8' : '#475569'}
                    strokeWidth="2"
                    className="cursor-pointer transition-transform hover:scale-125"
                    onClick={() => connectProbe(probeRed === node.id ? 'black' : 'red', node.id as NodePoint)}
                  />
                  <text x="0" y="-18" fill="#e2e8f0" fontSize="10" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                    {node.label}
                  </text>
                  {isRed && (
                    <text x="0" y="3" fill="#ffffff" fontSize="10" fontWeight="bold" textAnchor="middle" dominantBaseline="middle">
                      +R
                    </text>
                  )}
                  {isBlack && (
                    <text x="0" y="3" fill="#ffffff" fontSize="10" fontWeight="bold" textAnchor="middle" dominantBaseline="middle">
                      -B
                    </text>
                  )}
                </g>
              );
            })}
          </svg>
        </div>

        {/* Bento Row: Multimeter Station + Parameter Tuner */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 mt-4">
          {/* Multimeter Box (6 Cols) */}
          <div className="lg:col-span-6 bg-slate-950 p-5 rounded-3xl border border-slate-800 flex flex-col justify-between shadow-sm">
            <div>
              <div className="flex items-center justify-between border-b border-slate-800 pb-2.5 mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-xs font-bold text-emerald-400 tracking-wider uppercase font-mono">
                    Digital Multimeter (DMM)
                  </span>
                </div>
                <span className="text-[10px] font-mono bg-emerald-500/10 text-emerald-300 px-2 py-0.5 rounded-md border border-emerald-500/30">
                  TRUE RMS
                </span>
              </div>

              {/* LCD Display */}
              <div className="w-full bg-[#11241f] rounded-2xl border-2 border-[#1e4239] p-3 text-emerald-300 font-mono shadow-inner mb-3">
                <div className="flex justify-between text-[10px] text-emerald-500/80 mb-0.5">
                  <span>HOLD | AUTO</span>
                  <span>{dmmMode.toUpperCase()} MODE</span>
                </div>
                <div className="text-3xl font-black tracking-widest text-emerald-400 text-center font-mono py-1">
                  {dmmReadingText}
                </div>
                <div className="flex justify-between text-[10px] text-emerald-500/70 border-t border-[#1e4239] pt-1">
                  <span>Red: {probeRed}</span>
                  <span>Black: {probeBlack}</span>
                </div>
              </div>

              {/* Rotary Mode Buttons */}
              <div className="grid grid-cols-4 gap-1.5 mb-2">
                {[
                  { id: 'voltage', label: 'V DC' },
                  { id: 'current', label: 'I (mA/A)' },
                  { id: 'resistance', label: 'Ω (Ohms)' },
                  { id: 'continuity', label: '🔊 Beep' },
                ].map((mode) => (
                  <button
                    key={mode.id}
                    onClick={() => {
                      setDmmMode(mode.id as any);
                      sounds.playSwitchClick(true);
                    }}
                    className={`py-2 px-1 rounded-xl text-xs font-mono font-bold transition-all ${
                      dmmMode === mode.id
                        ? 'bg-emerald-500 text-slate-950 shadow-sm'
                        : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                    }`}
                  >
                    {mode.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Test Leads Selectors */}
            <div className="bg-slate-900/60 p-3 rounded-2xl border border-slate-800 space-y-2 text-xs">
              <div className="text-[11px] font-semibold text-slate-300 flex justify-between font-mono">
                <span>Attach Test Leads:</span>
                <span className="text-slate-500">Touch nodes or select:</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-[10px] text-rose-400 font-mono block mb-1">
                    Red Probe (+):
                  </span>
                  <select
                    value={probeRed}
                    onChange={(e) => connectProbe('red', e.target.value as NodePoint)}
                    className="w-full bg-slate-950 text-rose-300 font-mono text-xs p-1.5 rounded-lg border border-rose-500/40 focus:outline-none"
                  >
                    <option value="BAT_POS">TP1: Battery (+)</option>
                    <option value="SW_OUT">TP2: Switch Out</option>
                    <option value="MID_NODE">TP3: Mid Node</option>
                    <option value="LOAD_POS">TP4: Load (+)</option>
                    <option value="GND">TP5: Ground (-)</option>
                  </select>
                </div>

                <div>
                  <span className="text-[10px] text-cyan-400 font-mono block mb-1">
                    Black Probe (-):
                  </span>
                  <select
                    value={probeBlack}
                    onChange={(e) => connectProbe('black', e.target.value as NodePoint)}
                    className="w-full bg-slate-950 text-cyan-300 font-mono text-xs p-1.5 rounded-lg border border-cyan-500/40 focus:outline-none"
                  >
                    <option value="GND">TP5: Ground (-)</option>
                    <option value="LOAD_POS">TP4: Load (+)</option>
                    <option value="MID_NODE">TP3: Mid Node</option>
                    <option value="SW_OUT">TP2: Switch Out</option>
                    <option value="BAT_POS">TP1: Battery (+)</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          {/* Parameter Tuner Box (6 Cols) */}
          <div className="lg:col-span-6 bg-slate-950 p-5 rounded-3xl border border-slate-800 space-y-3.5">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-emerald-400" />
              Live Component Parameter Controls
            </h3>

            {/* Source Voltage Slider */}
            <div>
              <div className="flex justify-between text-xs font-mono text-emerald-400 mb-1">
                <span>Power Source (Vs):</span>
                <strong>{sourceV.toFixed(1)} V</strong>
              </div>
              <input
                type="range"
                min="1"
                max="36"
                step="0.5"
                value={sourceV}
                onChange={(e) => {
                  setSourceV(parseFloat(e.target.value));
                  sounds.playTick();
                }}
                className="w-full accent-emerald-500"
              />
            </div>

            {/* R1 Resistor Slider */}
            <div>
              <div className="flex justify-between text-xs font-mono text-amber-400 mb-1">
                <span>Resistor R1:</span>
                <strong>{formatResistance(r1)}</strong>
              </div>
              <input
                type="range"
                min="10"
                max="1000"
                step="10"
                value={r1}
                onChange={(e) => {
                  setR1(parseFloat(e.target.value));
                  sounds.playTick();
                }}
                className="w-full accent-amber-500"
              />
            </div>

            {/* R2 Resistor Slider */}
            {(topology === 'series' || topology === 'parallel') && (
              <div>
                <div className="flex justify-between text-xs font-mono text-teal-400 mb-1">
                  <span>Resistor R2:</span>
                  <strong>{formatResistance(r2)}</strong>
                </div>
                <input
                  type="range"
                  min="10"
                  max="1000"
                  step="10"
                  value={r2}
                  onChange={(e) => {
                    setR2(parseFloat(e.target.value));
                    sounds.playTick();
                  }}
                  className="w-full accent-teal-400"
                />
              </div>
            )}

            {/* Load Type Selector */}
            <div>
              <span className="text-xs text-slate-400 font-mono block mb-1.5">
                Load Component:
              </span>
              <div className="grid grid-cols-4 gap-1.5">
                {(
                  [
                    { id: 'bulb', label: 'Bulb' },
                    { id: 'led', label: 'LED' },
                    { id: 'motor', label: 'Motor' },
                    { id: 'heating_element', label: 'Heater' },
                  ] as { id: LoadType; label: string }[]
                ).map((lt) => (
                  <button
                    key={lt.id}
                    onClick={() => {
                      setLoadType(lt.id);
                      sounds.playSwitchClick(true);
                    }}
                    className={`py-1.5 rounded-xl text-xs font-mono transition-all ${
                      loadType === lt.id
                        ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm'
                        : 'bg-slate-900 text-slate-400 border border-slate-800'
                    }`}
                  >
                    {lt.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
