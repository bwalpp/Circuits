import React, { useState } from 'react';
import { Palette, RefreshCw, Sparkles, Check, HelpCircle, Layers } from 'lucide-react';
import { BAND_COLORS, decode4Band, encode4Band, formatResistance } from '../utils/circuitMath';
import { sounds } from '../utils/audioHaptics';

export const ResistorColorCoder: React.FC = () => {
  const [band1, setBand1] = useState<number>(4); // Yellow (4)
  const [band2, setBand2] = useState<number>(7); // Violet (7)
  const [multIdx, setMultIdx] = useState<number>(2); // Red (100) -> 4.7kΩ
  const [tolIdx, setTolIdx] = useState<number>(10); // Gold (5%)
  const [is5Band, setIs5Band] = useState<boolean>(false);
  const [band3, setBand3] = useState<number>(0); // 3rd digit if 5-band

  // Calculate resistance
  let baseValue = band1 * 10 + band2;
  if (is5Band) {
    baseValue = band1 * 100 + band2 * 10 + band3;
  }
  const multiplier = BAND_COLORS[multIdx]?.multiplier ?? 1;
  const resistance = baseValue * multiplier;
  const tolerance = BAND_COLORS[tolIdx]?.tolerance ?? 5;

  const minR = resistance * (1 - tolerance / 100);
  const maxR = resistance * (1 + tolerance / 100);

  // Set from quick standard values
  const setExactResistance = (targetR: number) => {
    sounds.playSwitchClick(true);
    const { b1, b2, multIdx: mIdx } = encode4Band(targetR);
    setBand1(b1);
    setBand2(b2);
    setMultIdx(mIdx);
    setIs5Band(false);
  };

  return (
    <div className="space-y-4">
      {/* Header Bento Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/50 p-4 rounded-3xl border border-slate-800">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <Palette className="w-4 h-4" />
            </span>
            Resistor Color Band Reader & Encoder
          </h2>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Identify standard through-hole resistor values by color stripes or encode nominal values.
          </p>
        </div>

        {/* 4-Band vs 5-Band Toggle */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-2xl border border-slate-800 self-start sm:self-auto">
          <button
            onClick={() => {
              setIs5Band(false);
              sounds.vibrate(15);
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-all ${
              !is5Band ? 'bg-emerald-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            4-Band Resistor
          </button>
          <button
            onClick={() => {
              setIs5Band(true);
              sounds.vibrate(15);
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-all ${
              is5Band ? 'bg-emerald-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            5-Band (Precision 1%)
          </button>
        </div>
      </div>

      {/* Realistic Visual Resistor Graphic Bento Card */}
      <div className="bg-slate-900/50 rounded-3xl border border-slate-800 p-6 flex flex-col items-center justify-center relative overflow-hidden shadow-sm">
        <div className="text-center mb-4">
          <span className="text-xs font-mono text-slate-400 uppercase tracking-widest block font-bold">
            Decoded Nominal Resistance
          </span>
          <div className="text-4xl sm:text-5xl font-black font-mono text-emerald-400 mt-1">
            {formatResistance(resistance)}
            <span className="text-base font-bold text-slate-400 ml-2">
              ±{tolerance}%
            </span>
          </div>
          <div className="text-xs font-mono text-slate-500 mt-1">
            Tolerance Bounds: {formatResistance(minR)} — {formatResistance(maxR)}
          </div>
        </div>

        {/* Resistor SVG Graphic */}
        <div className="w-full max-w-lg py-3">
          <svg viewBox="0 0 500 120" className="w-full drop-shadow-2xl select-none">
            {/* Metallic Lead Wires */}
            <line x1="10" y1="60" x2="100" y2="60" stroke="#94a3b8" strokeWidth="6" strokeLinecap="round" />
            <line x1="400" y1="60" x2="490" y2="60" stroke="#94a3b8" strokeWidth="6" strokeLinecap="round" />

            {/* Resistor Body Background (Ceramic Tan/Beige) */}
            <rect x="100" y="30" width="300" height="60" rx="20" fill="#d6c5a5" stroke="#9c8c74" strokeWidth="2" />
            {/* Bulbous ends */}
            <rect x="90" y="24" width="40" height="72" rx="14" fill="#d6c5a5" stroke="#9c8c74" strokeWidth="2" />
            <rect x="370" y="24" width="40" height="72" rx="14" fill="#d6c5a5" stroke="#9c8c74" strokeWidth="2" />

            {/* Band 1 */}
            <rect x="140" y="24" width="16" height="72" fill={BAND_COLORS[band1].colorHex} rx="2" />
            {/* Band 2 */}
            <rect x="190" y="30" width="16" height="60" fill={BAND_COLORS[band2].colorHex} rx="2" />

            {/* Band 3 (if 5-band) or Multiplier */}
            {is5Band ? (
              <>
                <rect x="235" y="30" width="16" height="60" fill={BAND_COLORS[band3].colorHex} rx="2" />
                <rect x="280" y="30" width="16" height="60" fill={BAND_COLORS[multIdx].colorHex} rx="2" />
              </>
            ) : (
              <rect x="250" y="30" width="16" height="60" fill={BAND_COLORS[multIdx].colorHex} rx="2" />
            )}

            {/* Tolerance Band (Right) */}
            <rect x="340" y="24" width="16" height="72" fill={BAND_COLORS[tolIdx].colorHex} rx="2" />
          </svg>
        </div>

        {/* Quick EIA Decade Presets */}
        <div className="flex flex-wrap items-center justify-center gap-2 pt-4 border-t border-slate-800 w-full mt-2">
          <span className="text-[11px] font-mono text-slate-400 font-semibold">Standard Decade Values:</span>
          {[10, 47, 100, 220, 330, 470, 1000, 4700, 10000, 100000].map((val) => (
            <button
              key={val}
              onClick={() => setExactResistance(val)}
              className="px-2.5 py-1 rounded-xl bg-slate-950 hover:bg-slate-900 border border-slate-800 text-xs font-mono text-slate-300 hover:text-emerald-400 transition-colors"
            >
              {formatResistance(val)}
            </button>
          ))}
        </div>
      </div>

      {/* Color Band Selector Palette Columns */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* Band 1 Selector */}
        <div className="bg-slate-900/50 p-4 rounded-3xl border border-slate-800 space-y-2">
          <span className="text-xs font-bold text-slate-300 font-mono block mb-1">
            Band 1 (1st Digit): {BAND_COLORS[band1].name} ({band1})
          </span>
          <div className="grid grid-cols-2 gap-1.5 max-h-56 overflow-y-auto pr-1 no-scrollbar">
            {BAND_COLORS.slice(1, 10).map((c) => (
              <button
                key={c.value}
                onClick={() => {
                  setBand1(c.value);
                  sounds.vibrate(15);
                }}
                className={`p-2 rounded-xl text-xs font-mono font-bold flex items-center gap-2 border transition-all ${
                  band1 === c.value
                    ? 'border-emerald-500 bg-slate-950 text-white shadow-md'
                    : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="w-3.5 h-3.5 rounded-full border border-black/40" style={{ backgroundColor: c.colorHex }} />
                <span>{c.value}: {c.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Band 2 Selector */}
        <div className="bg-slate-900/50 p-4 rounded-3xl border border-slate-800 space-y-2">
          <span className="text-xs font-bold text-slate-300 font-mono block mb-1">
            Band 2 (2nd Digit): {BAND_COLORS[band2].name} ({band2})
          </span>
          <div className="grid grid-cols-2 gap-1.5 max-h-56 overflow-y-auto pr-1 no-scrollbar">
            {BAND_COLORS.slice(0, 10).map((c) => (
              <button
                key={c.value}
                onClick={() => {
                  setBand2(c.value);
                  sounds.vibrate(15);
                }}
                className={`p-2 rounded-xl text-xs font-mono font-bold flex items-center gap-2 border transition-all ${
                  band2 === c.value
                    ? 'border-emerald-500 bg-slate-950 text-white shadow-md'
                    : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="w-3.5 h-3.5 rounded-full border border-black/40" style={{ backgroundColor: c.colorHex }} />
                <span>{c.value}: {c.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Multiplier Selector */}
        <div className="bg-slate-900/50 p-4 rounded-3xl border border-slate-800 space-y-2">
          <span className="text-xs font-bold text-slate-300 font-mono block mb-1">
            Multiplier: ×{BAND_COLORS[multIdx].multiplier >= 1e6 ? `${BAND_COLORS[multIdx].multiplier / 1e6}M` : BAND_COLORS[multIdx].multiplier >= 1e3 ? `${BAND_COLORS[multIdx].multiplier / 1e3}k` : BAND_COLORS[multIdx].multiplier}
          </span>
          <div className="grid grid-cols-2 gap-1.5 max-h-56 overflow-y-auto pr-1 no-scrollbar">
            {BAND_COLORS.filter((c) => c.multiplier !== undefined).map((c) => {
              const idx = BAND_COLORS.findIndex((item) => item.name === c.name);
              return (
                <button
                  key={c.name}
                  onClick={() => {
                    setMultIdx(idx);
                    sounds.vibrate(15);
                  }}
                  className={`p-2 rounded-xl text-xs font-mono font-bold flex items-center gap-2 border transition-all ${
                    multIdx === idx
                      ? 'border-emerald-500 bg-slate-950 text-white shadow-md'
                      : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="w-3.5 h-3.5 rounded-full border border-black/40" style={{ backgroundColor: c.colorHex }} />
                  <span className="truncate">{c.name}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Tolerance Selector */}
        <div className="bg-slate-900/50 p-4 rounded-3xl border border-slate-800 space-y-2">
          <span className="text-xs font-bold text-slate-300 font-mono block mb-1">
            Tolerance: ±{tolerance}% ({BAND_COLORS[tolIdx].name})
          </span>
          <div className="grid grid-cols-2 gap-1.5 max-h-56 overflow-y-auto pr-1 no-scrollbar">
            {BAND_COLORS.filter((c) => c.tolerance !== undefined).map((c) => {
              const idx = BAND_COLORS.findIndex((item) => item.name === c.name);
              return (
                <button
                  key={c.name}
                  onClick={() => {
                    setTolIdx(idx);
                    sounds.vibrate(15);
                  }}
                  className={`p-2 rounded-xl text-xs font-mono font-bold flex items-center gap-2 border transition-all ${
                    tolIdx === idx
                      ? 'border-emerald-500 bg-slate-950 text-white shadow-md'
                      : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="w-3.5 h-3.5 rounded-full border border-black/40" style={{ backgroundColor: c.colorHex }} />
                  <span className="truncate">±{c.tolerance}%</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
