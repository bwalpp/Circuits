import React, { useState, useEffect } from 'react';
import { Smartphone, Volume2, VolumeX, Cpu, Activity } from 'lucide-react';
import { sounds } from '../utils/audioHaptics';

interface AndroidFrameProps {
  children: React.ReactNode;
  activeTabTitle: string;
}

export const AndroidFrame: React.FC<AndroidFrameProps> = ({ children, activeTabTitle }) => {
  const [time, setTime] = useState('10:42');
  const [isPhoneFrame, setIsPhoneFrame] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [cpuMs, setCpuMs] = useState(12);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }));
      setCpuMs(Math.floor(8 + Math.random() * 8));
    };
    updateTime();
    const interval = setInterval(updateTime, 10000);
    return () => clearInterval(interval);
  }, []);

  const toggleMute = () => {
    const next = !isMuted;
    setIsMuted(next);
    sounds.setMuted(next);
    sounds.vibrate(20);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-start p-2 sm:p-4 md:p-6 selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Top Bento Header */}
      <header className="w-full max-w-7xl flex flex-col sm:flex-row justify-between sm:items-end gap-3 mb-4 md:mb-6">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-emerald-500 text-slate-950 flex items-center justify-center font-black shadow-lg shadow-emerald-500/20">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-emerald-400 font-display">
                  OhmFlow <span className="text-xs font-mono text-emerald-500 font-semibold px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30">v2.4 Bento</span>
                </h1>
              </div>
              <p className="text-slate-400 text-xs sm:text-sm font-mono mt-0.5">
                Interactive Circuit Analysis & Physics Calculator
              </p>
            </div>
          </div>
        </div>

        {/* Status badges & Controls */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          <div className="bg-slate-900/80 border border-slate-800 px-3.5 py-1.5 rounded-2xl flex items-center gap-2.5 shadow-sm">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
            <span className="text-[11px] font-bold uppercase tracking-widest text-slate-300">
              Simulator Active
            </span>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 px-3 py-1.5 rounded-2xl hidden sm:flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-[11px] font-mono font-semibold text-slate-400">
              Engine: {cpuMs}ms
            </span>
          </div>

          {/* Sound Mute/Unmute */}
          <button
            onClick={toggleMute}
            className={`px-3 py-1.5 rounded-2xl border text-xs font-semibold flex items-center gap-1.5 transition-all ${
              isMuted
                ? 'bg-slate-900 border-slate-800 text-slate-400'
                : 'bg-emerald-950/40 border-emerald-500/40 text-emerald-400 shadow-sm shadow-emerald-500/10'
            }`}
            title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5 text-emerald-400" />}
            <span className="hidden md:inline">{isMuted ? 'Muted' : 'Audio On'}</span>
          </button>

          {/* Android Phone Frame / Fullscreen Toggle */}
          <button
            onClick={() => {
              setIsPhoneFrame(!isPhoneFrame);
              sounds.vibrate(15);
            }}
            className={`px-3 py-1.5 rounded-2xl border text-xs font-semibold flex items-center gap-1.5 transition-all ${
              isPhoneFrame
                ? 'bg-amber-500/20 border-amber-500/50 text-amber-300'
                : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white hover:border-slate-700'
            }`}
            title="Toggle Android Device Frame"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="hidden md:inline">
              {isPhoneFrame ? 'Phone Shell' : 'Bento Grid'}
            </span>
          </button>
        </div>
      </header>

      {/* Main Layout Container */}
      <main className={`w-full transition-all duration-300 ${isPhoneFrame ? 'max-w-[460px] my-2' : 'max-w-7xl'}`}>
        {isPhoneFrame ? (
          /* Realistic Android Smartphone Shell */
          <div className="relative rounded-[44px] border-[10px] border-slate-800 bg-slate-950 shadow-2xl shadow-emerald-950/40 overflow-hidden ring-1 ring-slate-700/80 flex flex-col min-h-[780px]">
            {/* Top Speaker & Camera */}
            <div className="w-full bg-slate-900 px-6 py-2 flex items-center justify-between text-[11px] font-medium text-slate-300 select-none z-30">
              <span className="font-mono-numbers">{time}</span>
              <div className="w-3.5 h-3.5 rounded-full bg-slate-950 border border-slate-800 flex items-center justify-center">
                <div className="w-1.5 h-1.5 rounded-full bg-slate-900" />
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-mono">5G</span>
                <div className="flex items-center gap-0.5 font-mono text-[10px]">
                  <span>98%</span>
                  <div className="w-4 h-2 rounded-[2px] border border-slate-400 p-[1px] flex items-center">
                    <div className="h-full bg-emerald-400 rounded-[1px] w-[90%]" />
                  </div>
                </div>
              </div>
            </div>

            {/* Android Screen Body */}
            <div className="flex-1 flex flex-col bg-slate-950 overflow-y-auto">
              {children}
            </div>

            {/* Android Gesture Bar */}
            <div className="bg-slate-950 py-2.5 flex items-center justify-center select-none z-30 border-t border-slate-900">
              <div className="w-32 h-1 bg-slate-600 rounded-full hover:bg-slate-400 transition-colors cursor-pointer" />
            </div>
          </div>
        ) : (
          /* Bento Canvas */
          <div className="w-full space-y-4">
            {children}
          </div>
        )}
      </main>
    </div>
  );
};
