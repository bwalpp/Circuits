import React, { useState } from 'react';
import { Award, CheckCircle, XCircle, HelpCircle, ArrowRight, Sparkles, RefreshCw, Trophy, Star } from 'lucide-react';
import confetti from 'canvas-confetti';
import { Challenge } from '../types';
import { sounds } from '../utils/audioHaptics';

const CHALLENGES_LIST: Challenge[] = [
  {
    id: 'ch1',
    title: "1. Basic Ohm's Law: Loop Current",
    category: 'beginner',
    description: 'A 9V transistor battery is connected directly across a 150 Ω fixed resistor in a closed circuit.',
    targetQuestion: 'Calculate the total current (I) flowing in the circuit in Milliamps (mA):',
    givenValues: [
      { label: 'Voltage (V)', value: '9.0 V' },
      { label: 'Resistance (R)', value: '150 Ω' },
    ],
    targetParameter: 'I',
    correctValue: 60, // 60 mA (9 / 150 = 0.06A = 60mA)
    unit: 'mA',
    tolerancePct: 2,
    hint: 'Use Ohm’s Law: I = V / R. Remember to convert Amperes into Milliamps (1 A = 1000 mA).',
    explanation: 'I = V / R = 9V / 150Ω = 0.06 A. Multiplying by 1000 gives 60 mA.',
  },
  {
    id: 'ch2',
    title: '2. LED Sizing: Current-Limiting Resistor',
    category: 'design',
    description: 'You want to power a standard Red LED (Forward voltage Vf = 2.0 V, Forward current If = 20 mA = 0.02 A) from a 5.0 V microcontroller pin without burning the LED.',
    targetQuestion: 'Calculate the exact required series resistor (R) value in Ohms (Ω):',
    givenValues: [
      { label: 'Supply Voltage (Vs)', value: '5.0 V' },
      { label: 'LED Forward Drop (Vf)', value: '2.0 V' },
      { label: 'Target Current (If)', value: '20 mA (0.02 A)' },
    ],
    targetParameter: 'R',
    correctValue: 150, // (5 - 2) / 0.02 = 150 Ohms
    unit: 'Ω',
    tolerancePct: 2,
    hint: 'The voltage drop across the resistor is Vr = Vs - Vf = 5.0V - 2.0V = 3.0V. Then apply R = Vr / If.',
    explanation: 'Resistor voltage Vr = 5.0V - 2.0V = 3.0V. R = Vr / If = 3.0V / 0.02A = 150 Ω.',
  },
  {
    id: 'ch3',
    title: '3. Voltage Divider: Output Tap',
    category: 'intermediate',
    description: 'A 12V power supply is connected to two resistors in series: R1 = 1000 Ω (1 kΩ) on top, and R2 = 3000 Ω (3 kΩ) on bottom. You measure the voltage Vout across R2.',
    targetQuestion: 'Calculate the divider output voltage (Vout) in Volts (V):',
    givenValues: [
      { label: 'Input Voltage (Vin)', value: '12.0 V' },
      { label: 'Top Resistor (R1)', value: '1000 Ω' },
      { label: 'Bottom Resistor (R2)', value: '3000 Ω' },
    ],
    targetParameter: 'V',
    correctValue: 9.0, // 12 * (3000 / 4000) = 9V
    unit: 'V',
    tolerancePct: 2,
    hint: 'Voltage Divider Formula: Vout = Vin × [ R2 / (R1 + R2) ].',
    explanation: 'Vout = 12V × (3000 / (1000 + 3000)) = 12V × 0.75 = 9.0 V.',
  },
  {
    id: 'ch4',
    title: '4. Power & Heat Dissipation: Joule Heating',
    category: 'intermediate',
    description: 'An electric heating element with a resistance of 20 Ω carries a steady current of 3.0 Amperes.',
    targetQuestion: 'Calculate the rate of heat energy generated (Power in Watts, W):',
    givenValues: [
      { label: 'Resistance (R)', value: '20 Ω' },
      { label: 'Current (I)', value: '3.0 A' },
    ],
    targetParameter: 'P',
    correctValue: 180, // P = I^2 * R = 9 * 20 = 180W
    unit: 'W',
    tolerancePct: 2,
    hint: 'Joule’s Power Law: P = I² × R.',
    explanation: 'P = I² × R = (3.0 A)² × 20 Ω = 9 × 20 = 180 Watts.',
  },
  {
    id: 'ch5',
    title: '5. Parallel Resistors: Equivalent Resistance',
    category: 'intermediate',
    description: 'Two resistors of R1 = 60 Ω and R2 = 40 Ω are wired in parallel across a battery.',
    targetQuestion: 'Calculate the total equivalent resistance (Req) of the parallel combination in Ohms (Ω):',
    givenValues: [
      { label: 'Resistor R1', value: '60 Ω' },
      { label: 'Resistor R2', value: '40 Ω' },
    ],
    targetParameter: 'R',
    correctValue: 24, // (60 * 40) / (60 + 40) = 2400 / 100 = 24 Ohms
    unit: 'Ω',
    tolerancePct: 2,
    hint: 'Product over Sum rule: Req = (R1 × R2) / (R1 + R2).',
    explanation: 'Req = (60 × 40) / (60 + 40) = 2400 / 100 = 24 Ω.',
  },
  {
    id: 'ch6',
    title: '6. Fuse Rating & Short Circuit Protection',
    category: 'troubleshooting',
    description: 'A 12V DC automotive headlamp draws 48 Watts of power during normal operation.',
    targetQuestion: 'Calculate the normal operating current (I) in Amps (A) to choose an appropriate fuse:',
    givenValues: [
      { label: 'Supply Voltage (V)', value: '12.0 V' },
      { label: 'Power Rating (P)', value: '48.0 W' },
    ],
    targetParameter: 'I',
    correctValue: 4.0, // I = P / V = 48 / 12 = 4A
    unit: 'A',
    tolerancePct: 2,
    hint: 'Electric Power formula: P = V × I -> I = P / V.',
    explanation: 'I = P / V = 48 W / 12 V = 4.0 Amperes.',
  },
];

export const CircuitChallenges: React.FC = () => {
  const [currentIdx, setCurrentIdx] = useState<number>(0);
  const [userAnswer, setUserAnswer] = useState<string>('');
  const [showHint, setShowHint] = useState<boolean>(false);
  const [status, setStatus] = useState<'unanswered' | 'correct' | 'incorrect'>('unanswered');
  const [completedIds, setCompletedIds] = useState<string[]>([]);
  const [score, setScore] = useState<number>(0);

  const challenge = CHALLENGES_LIST[currentIdx];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const num = parseFloat(userAnswer.trim());
    if (isNaN(num)) return;

    const diff = Math.abs(num - challenge.correctValue);
    const maxDiff = (challenge.correctValue * challenge.tolerancePct) / 100;

    if (diff <= maxDiff) {
      // Correct!
      setStatus('correct');
      sounds.playSuccess();
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.7 },
      });
      if (!completedIds.includes(challenge.id)) {
        setCompletedIds([...completedIds, challenge.id]);
        setScore((prev) => prev + 100);
      }
    } else {
      // Incorrect
      setStatus('incorrect');
      sounds.playFuseBlow();
    }
  };

  const nextChallenge = () => {
    sounds.playSwitchClick(true);
    setStatus('unanswered');
    setUserAnswer('');
    setShowHint(false);
    setCurrentIdx((prev) => (prev + 1) % CHALLENGES_LIST.length);
  };

  return (
    <div className="space-y-4">
      {/* Top Header Bento Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/50 p-4 rounded-3xl border border-slate-800">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <Award className="w-4 h-4" />
            </span>
            Circuit Challenges & Engineering Quizzes
          </h2>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Test and validate your electronics math and troubleshooting mastery.
          </p>
        </div>

        {/* Score Readout */}
        <div className="flex items-center gap-3 bg-slate-950 px-4 py-2 rounded-2xl border border-slate-800 self-start sm:self-auto shadow-sm">
          <Trophy className="w-4 h-4 text-amber-400" />
          <div className="text-xs font-mono">
            <span className="text-slate-400">Score: </span>
            <strong className="text-emerald-400 text-sm">{score} pts</strong>
          </div>
          <div className="text-xs font-mono text-slate-500">
            ({completedIds.length}/{CHALLENGES_LIST.length} solved)
          </div>
        </div>
      </div>

      {/* Main Challenge Bento Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Challenge Card (8 Cols) */}
        <div className="lg:col-span-8 bg-slate-900/50 rounded-3xl border border-slate-800 p-6 flex flex-col justify-between shadow-sm">
          <div>
            {/* Question Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                Problem {currentIdx + 1} of {CHALLENGES_LIST.length}
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider bg-slate-950 text-slate-400 border border-slate-800">
                {challenge.category}
              </span>
            </div>

            <h3 className="text-lg font-bold text-white mb-2">
              {challenge.title}
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-4">
              {challenge.description}
            </p>

            {/* Given Parameters Box */}
            <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800/80 mb-4">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider font-mono block mb-2">
                Given Parameters:
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {challenge.givenValues.map((gv, i) => (
                  <div key={i} className="bg-slate-900/90 p-2.5 rounded-xl border border-slate-800">
                    <div className="text-[10px] text-slate-400 font-mono">{gv.label}</div>
                    <div className="text-sm font-bold text-emerald-400 font-mono mt-0.5">
                      {gv.value}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Target Question */}
            <div className="text-xs sm:text-sm font-bold text-white mb-3">
              {challenge.targetQuestion}
            </div>

            {/* User Input Form */}
            <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-2">
              <div className="relative flex-grow">
                <input
                  type="number"
                  step="any"
                  value={userAnswer}
                  onChange={(e) => setUserAnswer(e.target.value)}
                  placeholder={`Enter value in ${challenge.unit}...`}
                  className="w-full bg-slate-950 border border-slate-700 rounded-2xl px-4 py-3 text-sm font-mono text-white focus:outline-none focus:border-emerald-500"
                />
                <span className="absolute right-4 top-1/2 -translate-y-1/2 font-mono font-bold text-slate-400 text-xs">
                  {challenge.unit}
                </span>
              </div>
              <button
                type="submit"
                className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-6 py-3 rounded-2xl text-xs uppercase tracking-wider transition-transform active:scale-95 shadow-md shadow-emerald-500/20 font-mono"
              >
                Submit Answer
              </button>
            </form>

            {/* Status Result feedback */}
            {status === 'correct' && (
              <div className="mt-4 p-3.5 bg-emerald-950/40 border border-emerald-500/40 rounded-2xl text-xs text-emerald-300 flex items-start gap-2.5 font-mono">
                <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-emerald-300 font-bold text-sm">
                    Correct! +100 Points
                  </strong>
                  <p className="mt-0.5 text-slate-300">{challenge.explanation}</p>
                </div>
              </div>
            )}

            {status === 'incorrect' && (
              <div className="mt-4 p-3.5 bg-rose-950/40 border border-rose-500/40 rounded-2xl text-xs text-rose-300 flex items-start gap-2.5 font-mono">
                <XCircle className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-rose-300 font-bold">Incorrect</strong>
                  <p className="mt-0.5 text-slate-300">
                    Double-check your unit conversions or formula. Click "View Hint" if needed.
                  </p>
                </div>
              </div>
            )}

            {showHint && (
              <div className="mt-3 p-3 bg-amber-950/30 border border-amber-500/30 rounded-2xl text-xs text-amber-300 font-mono">
                <strong>Hint:</strong> {challenge.hint}
              </div>
            )}
          </div>

          {/* Action buttons footer */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-800 mt-4">
            <button
              onClick={() => {
                setShowHint(!showHint);
                sounds.vibrate(15);
              }}
              className="text-xs font-mono text-amber-400 hover:text-amber-300 flex items-center gap-1.5"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              {showHint ? 'Hide Hint' : 'Need a Hint?'}
            </button>

            <button
              onClick={nextChallenge}
              className="px-4 py-2 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-mono text-xs font-bold flex items-center gap-2 border border-slate-800 transition-colors"
            >
              Next Problem <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Right Challenge Selector List (4 Cols) */}
        <div className="lg:col-span-4 bg-slate-900/50 rounded-3xl border border-slate-800 p-5 space-y-3 shadow-sm">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono">
            Problem Directory
          </h4>
          <div className="space-y-2">
            {CHALLENGES_LIST.map((c, idx) => {
              const isCurrent = idx === currentIdx;
              const isDone = completedIds.includes(c.id);
              return (
                <button
                  key={c.id}
                  onClick={() => {
                    setCurrentIdx(idx);
                    setStatus('unanswered');
                    setUserAnswer('');
                    setShowHint(false);
                    sounds.playSwitchClick(true);
                  }}
                  className={`w-full text-left p-3 rounded-2xl border transition-all flex items-center justify-between text-xs ${
                    isCurrent
                      ? 'bg-slate-950 border-emerald-500 text-white shadow-sm'
                      : 'bg-slate-950/60 border-slate-800/80 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    <span className="font-mono font-bold text-slate-500">{idx + 1}.</span>
                    <span className="truncate font-medium">{c.title.split(':')[1] || c.title}</span>
                  </div>
                  {isDone ? (
                    <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  ) : (
                    <Star className="w-3.5 h-3.5 text-slate-600 flex-shrink-0" />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
