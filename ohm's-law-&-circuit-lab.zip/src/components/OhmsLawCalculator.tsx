import React, { useState } from 'react';
import { Zap, Gauge, Flame, Sparkles, RefreshCw, HelpCircle, ArrowRight, Check, Sliders, Activity } from 'lucide-react';
import { solveOhmsLaw, formatVoltage, formatCurrent, formatResistance, formatPower } from '../utils/circuitMath';
import { sounds } from '../utils/audioHaptics';

type TargetVar = 'V' | 'I' | 'R' | 'P';

export const OhmsLawCalculator: React.FC = () => {
  const [target, setTarget] = useState<TargetVar>('I');
  const [voltage, setVoltage] = useState<number>(12); // Volts
  const [current, setCurrent] = useState<number>(2.4); // Amps
  const [resistance, setResistance] = useState<number>(5.0); // Ohms
  const [power, setPower] = useState<number>(28.8); // Watts

  // Update calculations whenever inputs change
  const handleVoltageChange = (newV: number) => {
    sounds.playTick();
    const v = Math.max(0.01, newV);
    setVoltage(v);
    if (target === 'I') {
      const res = solveOhmsLaw({ voltage: v, resistance });
      setCurrent(res.current);
      setPower(res.power);
    } else if (target === 'R') {
      const res = solveOhmsLaw({ voltage: v, current });
      setResistance(res.resistance);
      setPower(res.power);
    } else if (target === 'V') {
      const res = solveOhmsLaw({ current, resistance });
      setVoltage(res.voltage);
      setPower(res.power);
    } else {
      const res = solveOhmsLaw({ voltage: v, resistance });
      setCurrent(res.current);
      setPower(res.power);
    }
  };

  const handleResistanceChange = (newR: number) => {
    sounds.playTick();
    const r = Math.max(0.1, newR);
    setResistance(r);
    if (target === 'I') {
      const res = solveOhmsLaw({ voltage, resistance: r });
      setCurrent(res.current);
      setPower(res.power);
    } else if (target === 'V') {
      const res = solveOhmsLaw({ current, resistance: r });
      setVoltage(res.voltage);
      setPower(res.power);
    } else {
      const res = solveOhmsLaw({ voltage, resistance: r });
      setCurrent(res.current);
      setPower(res.power);
    }
  };

  const handleCurrentChange = (newI: number) => {
    sounds.playTick();
    const i = Math.max(0.0001, newI);
    setCurrent(i);
    if (target === 'V') {
      const res = solveOhmsLaw({ current: i, resistance });
      setVoltage(res.voltage);
      setPower(res.power);
    } else if (target === 'R') {
      const res = solveOhmsLaw({ voltage, current: i });
      setResistance(res.resistance);
      setPower(res.power);
    } else {
      const res = solveOhmsLaw({ current: i, resistance });
      setVoltage(res.voltage);
      setPower(res.power);
    }
  };

  const setPreset = (v: number, r: number) => {
    sounds.playSwitchClick(true);
    setVoltage(v);
    setResistance(r);
    const i = v / r;
    const p = (v * v) / r;
    setCurrent(i);
    setPower(p);
  };

  return (
    <div className="space-y-4">
      {/* Primary 12-Column Bento Grid Row */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Bento Tile 1: Schematic Preview (8 Cols) */}
        <div className="lg:col-span-8 bg-slate-900/50 border border-slate-800 rounded-3xl p-5 sm:p-6 relative overflow-hidden flex flex-col justify-between shadow-sm">
          <div>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-base sm:text-lg font-bold flex items-center gap-2 text-white">
                <span className="text-emerald-500">●</span> Schematic Preview & Active Loop
              </h2>
              <div className="flex gap-1.5 sm:gap-2 font-mono">
                <span className="px-2 py-1 bg-slate-800 text-[10px] font-semibold rounded-lg border border-slate-700 text-slate-300">
                  DC SOURCE
                </span>
                <span className="px-2 py-1 bg-slate-800 text-[10px] font-semibold rounded-lg border border-slate-700 text-slate-300">
                  SERIES LOOP
                </span>
                <span className="px-2 py-1 bg-emerald-500/10 text-[10px] font-bold rounded-lg border border-emerald-500/30 text-emerald-400">
                  V = I × R
                </span>
              </div>
            </div>

            {/* Schematic Canvas Box */}
            <div className="w-full min-h-[220px] sm:min-h-[260px] border-2 border-dashed border-slate-800 rounded-2xl flex items-center justify-center bg-slate-950/40 relative p-4 overflow-hidden">
              <svg viewBox="0 0 440 200" className="w-full max-w-md select-none">
                {/* Circuit wire loop */}
                <rect x="50" y="80" width="340" height="40" fill="none" stroke="#475569" strokeWidth="2" />
                <path d="M50 100 L20 100 L20 160 L420 160 L420 100 L390 100" fill="none" stroke="#475569" strokeWidth="2" />

                {/* Animated electron dots */}
                {current > 0.01 && (
                  <g fill="#10b981" className="animate-pulse">
                    <circle cx="100" cy="80" r="3" />
                    <circle cx="280" cy="80" r="3" />
                    <circle cx="420" cy="130" r="3" />
                    <circle cx="220" cy="160" r="3" />
                    <circle cx="20" cy="130" r="3" />
                  </g>
                )}

                {/* Voltage Source (Left circle) */}
                <circle cx="50" cy="100" r="16" fill="#10b981" fillOpacity="0.2" stroke="#10b981" strokeWidth="2" />
                <text x="50" y="105" fill="#10b981" fontSize="14" fontWeight="bold" textAnchor="middle">
                  V
                </text>

                {/* Resistor Block (Center) */}
                <rect x="180" y="70" width="80" height="24" rx="4" fill="#f59e0b" fillOpacity="0.2" stroke="#f59e0b" strokeWidth="2" />
                <text x="220" y="86" fill="#f59e0b" fontSize="12" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                  R ({formatResistance(resistance)})
                </text>

                {/* Current Arrow (Right) */}
                <path d="M320 100 L345 80 M345 80 L370 100" fill="none" stroke="#38bdf8" strokeWidth="3" strokeLinecap="round" />
                <text x="345" y="70" fill="#38bdf8" fontSize="12" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                  I: {formatCurrent(current)}
                </text>
              </svg>

              {/* Floating Potential Difference Readout */}
              <div className="absolute top-3 right-4 text-right">
                <div className="text-3xl sm:text-4xl font-mono font-black text-white tracking-tight">
                  {voltage.toFixed(2)}V
                </div>
                <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono">
                  Potential Difference
                </div>
              </div>
            </div>
          </div>

          {/* Quick Slider Presets Strip */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-slate-800/80 text-xs font-mono">
            <span className="text-slate-400 text-[11px] font-semibold">Standard Lab Presets:</span>
            <div className="flex flex-wrap gap-1.5">
              <button
                onClick={() => setPreset(1.5, 10)}
                className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-[11px] transition-colors"
              >
                1.5V AA (10Ω)
              </button>
              <button
                onClick={() => setPreset(5.0, 220)}
                className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-emerald-400 text-[11px] transition-colors font-semibold"
              >
                5V USB (220Ω)
              </button>
              <button
                onClick={() => setPreset(12.0, 5.0)}
                className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-amber-400 text-[11px] transition-colors font-semibold"
              >
                12V Battery (5Ω)
              </button>
              <button
                onClick={() => setPreset(24.0, 100)}
                className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-blue-400 text-[11px] transition-colors"
              >
                24V PLC (100Ω)
              </button>
            </div>
          </div>
        </div>

        {/* Bento Tile 2: Solid Emerald Accent Calculator Card (4 Cols) */}
        <div className="lg:col-span-4 bg-emerald-500 text-slate-950 rounded-3xl p-6 flex flex-col justify-between shadow-xl">
          <div>
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-xl font-black uppercase tracking-tight italic">
                Ohm's Calculator
              </h2>
              <span className="px-2 py-0.5 rounded-full bg-slate-950/15 text-[10px] font-black uppercase tracking-wider font-mono">
                Live Solver
              </span>
            </div>

            <div className="space-y-4">
              {/* Voltage Input */}
              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider opacity-80 mb-1">
                  Voltage (V)
                </label>
                <div className="relative">
                  <input
                    type="number"
                    step="0.1"
                    value={voltage}
                    onChange={(e) => handleVoltageChange(parseFloat(e.target.value) || 0.1)}
                    className="w-full bg-slate-950/10 border-b-2 border-slate-950 p-2 text-2xl font-black font-mono focus:outline-none focus:bg-slate-950/15 transition-colors"
                  />
                  <span className="absolute right-2 top-1/2 -translate-y-1/2 font-black font-mono text-sm opacity-70">
                    V
                  </span>
                </div>
              </div>

              {/* Resistance Input */}
              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider opacity-80 mb-1">
                  Resistance (Ω)
                </label>
                <div className="relative">
                  <input
                    type="number"
                    step="0.5"
                    value={resistance}
                    onChange={(e) => handleResistanceChange(parseFloat(e.target.value) || 0.1)}
                    className="w-full bg-slate-950/10 border-b-2 border-slate-950 p-2 text-2xl font-black font-mono focus:outline-none focus:bg-slate-950/15 transition-colors"
                  />
                  <span className="absolute right-2 top-1/2 -translate-y-1/2 font-black font-mono text-sm opacity-70">
                    Ω
                  </span>
                </div>
              </div>

              {/* Resulting Current Hero Stat */}
              <div className="pt-2">
                <label className="block text-[11px] font-black uppercase tracking-wider opacity-80 mb-1">
                  Resulting Current (I)
                </label>
                <div className="text-4xl sm:text-5xl font-black tabular-nums tracking-tight font-mono">
                  {current.toFixed(2)} <span className="text-xl sm:text-2xl font-bold">A</span>
                </div>
                <div className="text-xs font-mono font-bold opacity-75 mt-0.5">
                  ({(current * 1000).toFixed(0)} mA @ {voltage.toFixed(1)}V / {resistance.toFixed(1)}Ω)
                </div>
              </div>
            </div>
          </div>

          <div className="pt-5">
            <button
              onClick={() => {
                sounds.playSwitchClick(true);
                handleVoltageChange(voltage);
              }}
              className="w-full bg-slate-950 text-emerald-400 font-black py-3.5 rounded-2xl uppercase tracking-wider text-xs hover:bg-slate-900 transition-transform active:scale-95 shadow-md"
            >
              Recalculate Circuit
            </button>
          </div>
        </div>
      </div>

      {/* Secondary Bento Grid Row: Power Dissipation + Theory Reference */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Bento Tile 3: Power Dissipation with Bars (4 Cols) */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 flex flex-col justify-between shadow-sm">
          <div>
            <div className="flex items-center justify-between mb-1">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest font-mono">
                Power Dissipation
              </h3>
              <Flame className="w-4 h-4 text-amber-500" />
            </div>
            <div className="text-3xl sm:text-4xl font-mono font-black text-amber-500">
              {power.toFixed(2)}W
            </div>
            <p className="text-[11px] text-slate-500 font-mono mt-0.5">
              Joule Heat Rate: P = I²R = V²/R
            </p>
          </div>

          {/* Graphical Power Bars (Matching Bento Grid Style) */}
          <div className="flex gap-1.5 items-end h-16 pt-3">
            <div className="w-full bg-amber-500/20 h-1/4 rounded-t-md transition-all duration-300"></div>
            <div className="w-full bg-amber-500/20 h-2/4 rounded-t-md transition-all duration-300"></div>
            <div className="w-full bg-amber-500/30 h-3/4 rounded-t-md transition-all duration-300"></div>
            <div
              className="w-full bg-amber-500 rounded-t-md transition-all duration-300 shadow-md shadow-amber-500/30"
              style={{ height: `${Math.min(100, Math.max(20, (power / 60) * 100))}%` }}
            ></div>
            <div className="w-full bg-amber-500/60 h-4/5 rounded-t-md transition-all duration-300"></div>
            <div className="w-full bg-amber-500/30 h-1/3 rounded-t-md transition-all duration-300"></div>
          </div>
        </div>

        {/* Bento Tile 4: Theory Reference & Mathematical Formulations (8 Cols) */}
        <div className="lg:col-span-8 bg-slate-900/50 border border-slate-800 rounded-3xl p-5 sm:p-6 flex flex-col sm:flex-row items-center gap-6 shadow-sm">
          {/* Big Iconic Formula Stamp */}
          <div className="flex-shrink-0 w-24 h-24 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-center shadow-inner">
            <span className="text-3xl sm:text-4xl font-serif italic text-emerald-400 font-bold">
              V=IR
            </span>
          </div>

          {/* Explanatory Content */}
          <div className="flex-grow text-center sm:text-left">
            <h3 className="text-base sm:text-lg font-bold text-white mb-1">
              Theory Reference & Core Principles
            </h3>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-xl">
              Ohm's Law states that the current through a conductor between two points is directly proportional to the voltage across the two points.
            </p>
            <div className="flex flex-wrap gap-2 mt-2 font-mono text-xs justify-center sm:justify-start">
              <span className="text-emerald-400">V = Potential (Volts)</span>
              <span className="text-slate-600">•</span>
              <span className="text-blue-400">I = Current (Amps)</span>
              <span className="text-slate-600">•</span>
              <span className="text-amber-400">R = Resistance (Ohms)</span>
            </div>
          </div>

          {/* Quick Matrix Badges */}
          <div className="flex-shrink-0">
            <div className="grid grid-cols-2 gap-2">
              <div
                onClick={() => {
                  setTarget('R');
                  sounds.vibrate(15);
                }}
                className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl text-center cursor-pointer hover:border-slate-700 transition-colors"
              >
                <div className="text-[10px] text-slate-500 font-mono">V / I</div>
                <div className="font-mono font-bold text-emerald-400 text-sm">R</div>
              </div>
              <div
                onClick={() => {
                  setTarget('I');
                  sounds.vibrate(15);
                }}
                className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl text-center cursor-pointer hover:border-slate-700 transition-colors"
              >
                <div className="text-[10px] text-slate-500 font-mono">V / R</div>
                <div className="font-mono font-bold text-blue-400 text-sm">I</div>
              </div>
              <div
                onClick={() => {
                  setTarget('V');
                  sounds.vibrate(15);
                }}
                className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl text-center cursor-pointer hover:border-slate-700 transition-colors"
              >
                <div className="text-[10px] text-slate-500 font-mono">I × R</div>
                <div className="font-mono font-bold text-amber-400 text-sm">V</div>
              </div>
              <div
                onClick={() => {
                  setTarget('P');
                  sounds.vibrate(15);
                }}
                className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl text-center cursor-pointer hover:border-slate-700 transition-colors"
              >
                <div className="text-[10px] text-slate-500 font-mono">V × I</div>
                <div className="font-mono font-bold text-purple-400 text-sm">P</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tertiary Bento Row: Sliders & Fine Adjustments */}
      <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-emerald-400" />
            Precision Potentiometer & Voltage Rail Controls
          </h3>
          <span className="text-xs font-mono text-slate-500">
            Real-time synchronization
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Voltage Slider */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs font-mono">
              <label className="font-bold text-emerald-400 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                Source Voltage:
              </label>
              <span className="font-bold text-white bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800">
                {voltage.toFixed(1)} V
              </span>
            </div>
            <input
              type="range"
              min="0.5"
              max="48"
              step="0.5"
              value={voltage}
              onChange={(e) => handleVoltageChange(parseFloat(e.target.value))}
              className="w-full accent-emerald-500"
            />
            <div className="flex justify-between text-[10px] font-mono text-slate-500">
              <span>0.5V</span>
              <span>12V</span>
              <span>24V</span>
              <span>36V</span>
              <span>48V</span>
            </div>
          </div>

          {/* Resistance Slider */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs font-mono">
              <label className="font-bold text-amber-400 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-amber-400" />
                Loop Resistance:
              </label>
              <span className="font-bold text-white bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800">
                {formatResistance(resistance)}
              </span>
            </div>
            <input
              type="range"
              min="0.5"
              max="1000"
              step="0.5"
              value={resistance}
              onChange={(e) => handleResistanceChange(parseFloat(e.target.value))}
              className="w-full accent-amber-500"
            />
            <div className="flex justify-between text-[10px] font-mono text-slate-500">
              <span>0.5Ω</span>
              <span>100Ω</span>
              <span>250Ω</span>
              <span>500Ω</span>
              <span>1kΩ</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
