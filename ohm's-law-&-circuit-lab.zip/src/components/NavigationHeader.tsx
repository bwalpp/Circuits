import React from 'react';
import { Calculator, CircuitBoard, Atom, Palette, Award, Wrench, Workflow, Table } from 'lucide-react';
import { LabTab } from '../types';
import { sounds } from '../utils/audioHaptics';

interface NavigationHeaderProps {
  activeTab: LabTab;
  setActiveTab: (tab: LabTab) => void;
}

export const NavigationHeader: React.FC<NavigationHeaderProps> = ({ activeTab, setActiveTab }) => {
  const tabs: { id: LabTab; label: string; icon: React.ReactNode; badge?: string }[] = [
    { id: 'custom_designer', label: 'Circuit Designer', icon: <Wrench className="w-4 h-4" />, badge: 'Design' },
    { id: 'virp_matrix', label: 'VIRP Table Solver', icon: <Table className="w-4 h-4" />, badge: 'Solve' },
    { id: 'circuit_solver', label: 'Series/Parallel Solver', icon: <Workflow className="w-4 h-4" />, badge: 'Steps' },
    { id: 'ohms_calculator', label: "Ohm's Grid", icon: <Calculator className="w-4 h-4" /> },
    { id: 'circuit_sandbox', label: 'Circuit Testbench', icon: <CircuitBoard className="w-4 h-4" /> },
    { id: 'physics_visualizer', label: 'Physics Lab', icon: <Atom className="w-4 h-4" /> },
    { id: 'resistor_code', label: 'Color Bands', icon: <Palette className="w-4 h-4" /> },
    { id: 'challenges', label: 'Challenges', icon: <Award className="w-4 h-4" />, badge: 'Quiz' },
  ];

  return (
    <div className="w-full bg-slate-900/50 border border-slate-800 rounded-3xl p-1.5 sm:p-2 backdrop-blur-md mb-4 shadow-sm">
      <nav className="flex items-center justify-between gap-1 overflow-x-auto no-scrollbar">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id);
                sounds.vibrate(15);
              }}
              className={`flex-1 min-w-[70px] sm:min-w-[100px] py-2 px-2.5 rounded-2xl flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-1.5 text-xs font-bold transition-all relative whitespace-nowrap ${
                isActive
                  ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <div className={`${isActive ? 'text-slate-950 scale-105' : 'text-slate-400'} transition-transform`}>
                {tab.icon}
              </div>
              <span className="text-[10px] sm:text-xs tracking-tight">{tab.label}</span>

              {tab.badge && (
                <span className={`px-1 py-0.2 rounded-md text-[8px] font-mono font-black uppercase tracking-wider hidden md:inline-block ${
                  isActive ? 'bg-slate-950 text-emerald-400' : 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                }`}>
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>
    </div>
  );
};

