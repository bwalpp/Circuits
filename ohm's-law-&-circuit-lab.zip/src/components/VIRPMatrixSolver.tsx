import React, { useState, useMemo } from 'react';
import {
  Layers,
  GitMerge,
  Workflow,
  Sparkles,
  Zap,
  CheckCircle2,
  Table,
  RotateCcw,
  BookOpen,
  ArrowRight,
  Info,
  HelpCircle,
  Lightbulb,
  Check,
} from 'lucide-react';
import {
  VIRPTopology,
  solveVIRPMatrix,
  VIRPSolverResult,
} from '../utils/virpSolver';
import {
  formatVoltage,
  formatCurrent,
  formatResistance,
  formatPower,
} from '../utils/circuitMath';
import { sounds } from '../utils/audioHaptics';

export const VIRPMatrixSolver: React.FC = () => {
  const [topology, setTopology] = useState<VIRPTopology>('series_2');

  // Matrix raw inputs: Record<rowKey, { v, i, r, p }>
  const [inputs, setInputs] = useState<
    Record<string, { v?: string; i?: string; r?: string; p?: string }>
  >({
    r1: { r: '200' },
    r2: { r: '300' },
    total: { v: '400' },
  });

  const solverResult: VIRPSolverResult = useMemo(() => {
    return solveVIRPMatrix(topology, inputs);
  }, [topology, inputs]);

  const handleInputChange = (
    rowId: string,
    param: 'v' | 'i' | 'r' | 'p',
    value: string
  ) => {
    setInputs((prev) => {
      const row = prev[rowId] ? { ...prev[rowId] } : {};
      if (value === '') {
        delete row[param];
      } else {
        row[param] = value;
      }
      return {
        ...prev,
        [rowId]: row,
      };
    });
  };

  const clearInputs = () => {
    sounds.playSwitchClick(false);
    setInputs({});
  };

  const applyPreset = (
    top: VIRPTopology,
    presetInputs: Record<string, { v?: string; i?: string; r?: string; p?: string }>
  ) => {
    sounds.playSwitchClick(true);
    setTopology(top);
    setInputs(presetInputs);
  };

  const topologiesList: {
    id: VIRPTopology;
    label: string;
    icon: React.ReactNode;
    desc: string;
  }[] = [
    {
      id: 'series_2',
      label: '2-Resistor Series',
      icon: <Layers className="w-4 h-4" />,
      desc: 'R1 in series with R2. Current is constant (I1 = I2 = IT).',
    },
    {
      id: 'series_3',
      label: '3-Resistor Series',
      icon: <Layers className="w-4 h-4" />,
      desc: 'R1, R2, R3 in series. VT = V1+V2+V3, RT = R1+R2+R3.',
    },
    {
      id: 'parallel_2',
      label: '2-Resistor Parallel',
      icon: <GitMerge className="w-4 h-4" />,
      desc: 'R1 || R2. Voltage is constant (V1 = V2 = VT), IT = I1+I2.',
    },
    {
      id: 'parallel_3',
      label: '3-Resistor Parallel',
      icon: <GitMerge className="w-4 h-4" />,
      desc: 'R1 || R2 || R3 across common power rails.',
    },
    {
      id: 'combo_series_parallel',
      label: 'Series-Parallel Combo',
      icon: <Workflow className="w-4 h-4" />,
      desc: 'Trunk R1 in series with parallel block (R2 || R3).',
    },
    {
      id: 'combo_parallel_series',
      label: 'Parallel-Series Combo',
      icon: <Workflow className="w-4 h-4" />,
      desc: 'Two series branches in parallel: (R1+R2) || (R3+R4).',
    },
  ];

  return (
    <div className="space-y-4">
      {/* Header Bento Banner */}
      <div className="bg-slate-900/60 p-4 sm:p-5 rounded-3xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <Table className="w-4 h-4" />
            </span>
            <h2 className="text-base sm:text-lg font-bold text-white">
              VIRP Complete Matrix & Missing Value Solver
            </h2>
          </div>
          <p className="text-xs text-slate-400 font-mono mt-1">
            Input <strong className="text-emerald-400">ANY</strong> combination of given Voltages, Currents, Resistances, or Powers — the solver derives all missing quantities with step-by-step math.
          </p>
        </div>

        {/* Global Solver State Pill */}
        <div className="flex items-center gap-2 bg-slate-950 p-2 sm:px-4 sm:py-2.5 rounded-2xl border border-slate-800 self-start md:self-auto shadow-inner">
          <div className="text-left font-mono">
            <div className="flex items-center gap-1.5 text-xs font-bold">
              {solverResult.isFullySolved ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span className="text-emerald-400">Fully Solved (100%)</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span className="text-amber-400">
                    {solverResult.steps.length > 0
                      ? `${solverResult.steps.length} Values Solved`
                      : 'Waiting for Inputs'}
                  </span>
                </>
              )}
            </div>
            <span className="text-[10px] text-slate-400 block truncate max-w-[260px]">
              {solverResult.statusMessage}
            </span>
          </div>
        </div>
      </div>

      {/* Quick Example Presets Bar */}
      <div className="bg-slate-900/40 p-3 rounded-2xl border border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs font-mono">
        <div className="flex items-center gap-2 text-slate-400 font-bold text-[11px]">
          <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
          <span>Quick Homework & Lab Examples:</span>
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={() =>
              applyPreset('series_2', {
                r1: { r: '200' },
                r2: { r: '300' },
                total: { v: '400' },
              })
            }
            className="px-2.5 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 text-[11px] font-bold transition-colors"
          >
            ★ Your Example (R1=200Ω, R2=300Ω, V_tot=400V)
          </button>
          <button
            onClick={() =>
              applyPreset('parallel_2', {
                r1: { r: '200' },
                r2: { r: '300' },
                total: { v: '400' },
              })
            }
            className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-[11px] transition-colors"
          >
            Parallel (R1=200Ω, R2=300Ω, V_tot=400V)
          </button>
          <button
            onClick={() =>
              applyPreset('series_3', {
                r1: { r: '100' },
                r2: { r: '220' },
                r3: { r: '470' },
                total: { v: '24' },
              })
            }
            className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-[11px] transition-colors"
          >
            3-Resistor Series (24V)
          </button>
          <button
            onClick={() =>
              applyPreset('combo_series_parallel', {
                r1: { r: '50' },
                r2: { r: '100' },
                r3: { r: '100' },
                total: { v: '100' },
              })
            }
            className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-[11px] transition-colors"
          >
            Series-Parallel Combo (100V)
          </button>
          <button
            onClick={() =>
              applyPreset('series_2', {
                r1: { v: '60', r: '100' },
                r2: { r: '200' },
              })
            }
            className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-[11px] transition-colors"
          >
            Given V1 & R1, Solve All
          </button>
          <button
            onClick={clearInputs}
            className="px-2 py-1 rounded-lg bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-red-400 text-[11px] transition-colors flex items-center gap-1"
          >
            <RotateCcw className="w-3 h-3" />
            Clear
          </button>
        </div>
      </div>

      {/* Topology Selection Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
        {topologiesList.map((t) => {
          const isActive = topology === t.id;
          return (
            <button
              key={t.id}
              onClick={() => {
                setTopology(t.id);
                sounds.playSwitchClick(true);
              }}
              className={`p-3 rounded-2xl border text-left transition-all flex flex-col justify-between ${
                isActive
                  ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-md shadow-emerald-500/20 font-bold'
                  : 'bg-slate-900/50 border-slate-800 text-slate-300 hover:bg-slate-800/80 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-1.5 text-xs">
                {t.icon}
                <span className="truncate">{t.label}</span>
              </div>
              <span
                className={`text-[10px] line-clamp-2 mt-1 leading-tight font-mono ${
                  isActive ? 'text-slate-950 font-medium' : 'text-slate-500'
                }`}
              >
                {t.desc}
              </span>
            </button>
          );
        })}
      </div>

      {/* Primary VIRP Interactive Table Card */}
      <div className="bg-slate-900/60 p-5 rounded-3xl border border-slate-800 space-y-4 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Table className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
              Interactive VIRP Matrix (V • I • R • P)
            </h3>
          </div>
          <div className="flex items-center gap-2 text-[11px] font-mono">
            <span className="flex items-center gap-1 text-slate-400">
              <span className="w-2.5 h-2.5 rounded bg-emerald-500/30 border border-emerald-500 inline-block" />
              User Given
            </span>
            <span className="flex items-center gap-1 text-slate-400">
              <span className="w-2.5 h-2.5 rounded bg-cyan-500/20 border border-cyan-500/40 inline-block" />
              Auto Solved
            </span>
          </div>
        </div>

        {/* The Matrix Table */}
        <div className="overflow-x-auto no-scrollbar">
          <table className="w-full text-left font-mono text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-[11px] uppercase text-slate-400">
                <th className="py-3 px-3 w-28">Component</th>
                <th className="py-3 px-3 min-w-[150px] text-amber-400">
                  Voltage (V)
                </th>
                <th className="py-3 px-3 min-w-[150px] text-cyan-400">
                  Current (I)
                </th>
                <th className="py-3 px-3 min-w-[150px] text-emerald-400">
                  Resistance (R)
                </th>
                <th className="py-3 px-3 min-w-[150px] text-purple-400">
                  Power (P)
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {solverResult.solvedRows.map((row) => {
                const rawInput = inputs[row.id] || {};
                return (
                  <tr
                    key={row.id}
                    className="hover:bg-slate-800/30 transition-colors"
                  >
                    <td className="py-3 px-3 font-bold text-white">
                      <div className="flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-emerald-400" />
                        <span>{row.label}</span>
                      </div>
                    </td>

                    {/* Voltage Cell (V) */}
                    <td className="py-2.5 px-3">
                      <div className="relative flex items-center">
                        <input
                          type="number"
                          step="any"
                          placeholder={
                            row.v && !row.v.isGiven
                              ? formatVoltage(row.v.value)
                              : 'e.g. 12'
                          }
                          value={rawInput.v ?? ''}
                          onChange={(e) =>
                            handleInputChange(row.id, 'v', e.target.value)
                          }
                          className={`w-full text-xs font-bold px-2.5 py-1.5 rounded-xl border font-mono transition-all ${
                            row.v?.isGiven
                              ? 'bg-emerald-950/50 border-emerald-500 text-emerald-300 shadow-sm'
                              : row.v
                              ? 'bg-slate-950/80 border-cyan-500/40 text-amber-300'
                              : 'bg-slate-950/40 border-slate-800 text-slate-400 focus:border-emerald-500'
                          } focus:outline-none`}
                        />
                        <span className="absolute right-2 text-[10px] text-slate-500 pointer-events-none font-bold">
                          V
                        </span>
                      </div>
                      {row.v && !row.v.isGiven && (
                        <div className="text-[10px] text-amber-400 font-bold mt-1 flex items-center justify-between">
                          <span>= {formatVoltage(row.v.value)}</span>
                          <span className="text-[9px] text-slate-500 font-normal">
                            {row.v.formula}
                          </span>
                        </div>
                      )}
                    </td>

                    {/* Current Cell (I) */}
                    <td className="py-2.5 px-3">
                      <div className="relative flex items-center">
                        <input
                          type="number"
                          step="any"
                          placeholder={
                            row.i && !row.i.isGiven
                              ? formatCurrent(row.i.value)
                              : 'e.g. 0.8'
                          }
                          value={rawInput.i ?? ''}
                          onChange={(e) =>
                            handleInputChange(row.id, 'i', e.target.value)
                          }
                          className={`w-full text-xs font-bold px-2.5 py-1.5 rounded-xl border font-mono transition-all ${
                            row.i?.isGiven
                              ? 'bg-emerald-950/50 border-emerald-500 text-emerald-300 shadow-sm'
                              : row.i
                              ? 'bg-slate-950/80 border-cyan-500/40 text-cyan-300'
                              : 'bg-slate-950/40 border-slate-800 text-slate-400 focus:border-emerald-500'
                          } focus:outline-none`}
                        />
                        <span className="absolute right-2 text-[10px] text-slate-500 pointer-events-none font-bold">
                          A
                        </span>
                      </div>
                      {row.i && !row.i.isGiven && (
                        <div className="text-[10px] text-cyan-400 font-bold mt-1 flex items-center justify-between">
                          <span>= {formatCurrent(row.i.value)}</span>
                          <span className="text-[9px] text-slate-500 font-normal">
                            {row.i.formula}
                          </span>
                        </div>
                      )}
                    </td>

                    {/* Resistance Cell (R) */}
                    <td className="py-2.5 px-3">
                      <div className="relative flex items-center">
                        <input
                          type="number"
                          step="any"
                          placeholder={
                            row.r && !row.r.isGiven
                              ? formatResistance(row.r.value)
                              : 'e.g. 200'
                          }
                          value={rawInput.r ?? ''}
                          onChange={(e) =>
                            handleInputChange(row.id, 'r', e.target.value)
                          }
                          className={`w-full text-xs font-bold px-2.5 py-1.5 rounded-xl border font-mono transition-all ${
                            row.r?.isGiven
                              ? 'bg-emerald-950/50 border-emerald-500 text-emerald-300 shadow-sm'
                              : row.r
                              ? 'bg-slate-950/80 border-cyan-500/40 text-emerald-300'
                              : 'bg-slate-950/40 border-slate-800 text-slate-400 focus:border-emerald-500'
                          } focus:outline-none`}
                        />
                        <span className="absolute right-2 text-[10px] text-slate-500 pointer-events-none font-bold">
                          Ω
                        </span>
                      </div>
                      {row.r && !row.r.isGiven && (
                        <div className="text-[10px] text-emerald-400 font-bold mt-1 flex items-center justify-between">
                          <span>= {formatResistance(row.r.value)}</span>
                          <span className="text-[9px] text-slate-500 font-normal">
                            {row.r.formula}
                          </span>
                        </div>
                      )}
                    </td>

                    {/* Power Cell (P) */}
                    <td className="py-2.5 px-3">
                      <div className="relative flex items-center">
                        <input
                          type="number"
                          step="any"
                          placeholder={
                            row.p && !row.p.isGiven
                              ? formatPower(row.p.value)
                              : 'e.g. 128'
                          }
                          value={rawInput.p ?? ''}
                          onChange={(e) =>
                            handleInputChange(row.id, 'p', e.target.value)
                          }
                          className={`w-full text-xs font-bold px-2.5 py-1.5 rounded-xl border font-mono transition-all ${
                            row.p?.isGiven
                              ? 'bg-emerald-950/50 border-emerald-500 text-emerald-300 shadow-sm'
                              : row.p
                              ? 'bg-slate-950/80 border-cyan-500/40 text-purple-300'
                              : 'bg-slate-950/40 border-slate-800 text-slate-400 focus:border-emerald-500'
                          } focus:outline-none`}
                        />
                        <span className="absolute right-2 text-[10px] text-slate-500 pointer-events-none font-bold">
                          W
                        </span>
                      </div>
                      {row.p && !row.p.isGiven && (
                        <div className="text-[10px] text-purple-400 font-bold mt-1 flex items-center justify-between">
                          <span>= {formatPower(row.p.value)}</span>
                          <span className="text-[9px] text-slate-500 font-normal">
                            {row.p.formula}
                          </span>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}

              {/* Total Circuit Bottom Master Row */}
              {(() => {
                const totalRow = solverResult.totalRow;
                const rawTotal = inputs['total'] || {};
                return (
                  <tr className="bg-slate-950/90 font-bold border-t-2 border-emerald-500/50">
                    <td className="py-3.5 px-3 text-emerald-400">
                      <div className="flex items-center gap-1.5">
                        <Zap className="w-3.5 h-3.5 text-amber-400" />
                        <span>TOTAL CIRCUIT</span>
                      </div>
                    </td>

                    {/* V_total */}
                    <td className="py-2.5 px-3">
                      <div className="relative flex items-center">
                        <input
                          type="number"
                          step="any"
                          placeholder={
                            totalRow.v && !totalRow.v.isGiven
                              ? formatVoltage(totalRow.v.value)
                              : 'e.g. 400'
                          }
                          value={rawTotal.v ?? ''}
                          onChange={(e) =>
                            handleInputChange('total', 'v', e.target.value)
                          }
                          className={`w-full text-xs font-bold px-2.5 py-1.5 rounded-xl border font-mono transition-all ${
                            totalRow.v?.isGiven
                              ? 'bg-emerald-950/50 border-emerald-500 text-emerald-300 shadow-sm'
                              : totalRow.v
                              ? 'bg-slate-900 border-amber-500/50 text-amber-300'
                              : 'bg-slate-900 border-slate-800 text-slate-400 focus:border-emerald-500'
                          } focus:outline-none`}
                        />
                        <span className="absolute right-2 text-[10px] text-slate-500 pointer-events-none font-bold">
                          V
                        </span>
                      </div>
                      {totalRow.v && !totalRow.v.isGiven && (
                        <div className="text-[10px] text-amber-400 font-bold mt-1">
                          = {formatVoltage(totalRow.v.value)}
                        </div>
                      )}
                    </td>

                    {/* I_total */}
                    <td className="py-2.5 px-3">
                      <div className="relative flex items-center">
                        <input
                          type="number"
                          step="any"
                          placeholder={
                            totalRow.i && !totalRow.i.isGiven
                              ? formatCurrent(totalRow.i.value)
                              : 'e.g. 0.8'
                          }
                          value={rawTotal.i ?? ''}
                          onChange={(e) =>
                            handleInputChange('total', 'i', e.target.value)
                          }
                          className={`w-full text-xs font-bold px-2.5 py-1.5 rounded-xl border font-mono transition-all ${
                            totalRow.i?.isGiven
                              ? 'bg-emerald-950/50 border-emerald-500 text-emerald-300 shadow-sm'
                              : totalRow.i
                              ? 'bg-slate-900 border-cyan-500/50 text-cyan-300'
                              : 'bg-slate-900 border-slate-800 text-slate-400 focus:border-emerald-500'
                          } focus:outline-none`}
                        />
                        <span className="absolute right-2 text-[10px] text-slate-500 pointer-events-none font-bold">
                          A
                        </span>
                      </div>
                      {totalRow.i && !totalRow.i.isGiven && (
                        <div className="text-[10px] text-cyan-400 font-bold mt-1">
                          = {formatCurrent(totalRow.i.value)}
                        </div>
                      )}
                    </td>

                    {/* R_total */}
                    <td className="py-2.5 px-3">
                      <div className="relative flex items-center">
                        <input
                          type="number"
                          step="any"
                          placeholder={
                            totalRow.r && !totalRow.r.isGiven
                              ? formatResistance(totalRow.r.value)
                              : 'e.g. 500'
                          }
                          value={rawTotal.r ?? ''}
                          onChange={(e) =>
                            handleInputChange('total', 'r', e.target.value)
                          }
                          className={`w-full text-xs font-bold px-2.5 py-1.5 rounded-xl border font-mono transition-all ${
                            totalRow.r?.isGiven
                              ? 'bg-emerald-950/50 border-emerald-500 text-emerald-300 shadow-sm'
                              : totalRow.r
                              ? 'bg-slate-900 border-emerald-500/50 text-emerald-300'
                              : 'bg-slate-900 border-slate-800 text-slate-400 focus:border-emerald-500'
                          } focus:outline-none`}
                        />
                        <span className="absolute right-2 text-[10px] text-slate-500 pointer-events-none font-bold">
                          Ω
                        </span>
                      </div>
                      {totalRow.r && !totalRow.r.isGiven && (
                        <div className="text-[10px] text-emerald-400 font-bold mt-1">
                          = {formatResistance(totalRow.r.value)}
                        </div>
                      )}
                    </td>

                    {/* P_total */}
                    <td className="py-2.5 px-3">
                      <div className="relative flex items-center">
                        <input
                          type="number"
                          step="any"
                          placeholder={
                            totalRow.p && !totalRow.p.isGiven
                              ? formatPower(totalRow.p.value)
                              : 'e.g. 320'
                          }
                          value={rawTotal.p ?? ''}
                          onChange={(e) =>
                            handleInputChange('total', 'p', e.target.value)
                          }
                          className={`w-full text-xs font-bold px-2.5 py-1.5 rounded-xl border font-mono transition-all ${
                            totalRow.p?.isGiven
                              ? 'bg-emerald-950/50 border-emerald-500 text-emerald-300 shadow-sm'
                              : totalRow.p
                              ? 'bg-slate-900 border-purple-500/50 text-purple-300'
                              : 'bg-slate-900 border-slate-800 text-slate-400 focus:border-emerald-500'
                          } focus:outline-none`}
                        />
                        <span className="absolute right-2 text-[10px] text-slate-500 pointer-events-none font-bold">
                          W
                        </span>
                      </div>
                      {totalRow.p && !totalRow.p.isGiven && (
                        <div className="text-[10px] text-purple-400 font-bold mt-1">
                          = {formatPower(totalRow.p.value)}
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })()}
            </tbody>
          </table>
        </div>
      </div>

      {/* Two-Column Bento Layout: Schematic Preview & Step-by-Step Mathematical Derivations */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Bento: Live Schematic Preview (5 Cols) */}
        <div className="lg:col-span-5 bg-slate-900/60 p-5 rounded-3xl border border-slate-800 space-y-3 flex flex-col justify-between shadow-sm">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                Live Circuit State
              </span>
              <span className="px-2 py-0.5 rounded-lg text-[10px] font-mono font-bold bg-slate-950 text-emerald-400 border border-slate-800">
                {solverResult.totalRow.v
                  ? formatVoltage(solverResult.totalRow.v.value)
                  : '— V'}{' '}
                DC Source
              </span>
            </div>

            {/* Visual SVG Diagram */}
            <div className="w-full bg-slate-950 rounded-2xl border border-slate-800/90 p-4 flex items-center justify-center relative select-none min-h-[220px]">
              {topology.startsWith('series_') && (
                <svg viewBox="0 0 400 180" className="w-full max-w-sm drop-shadow-md">
                  {/* DC Source */}
                  <line x1="50" y1="40" x2="50" y2="140" stroke="#0ea5e9" strokeWidth="2" />
                  <line x1="30" y1="75" x2="70" y2="75" stroke="#f59e0b" strokeWidth="3" />
                  <line x1="40" y1="95" x2="60" y2="95" stroke="#64748b" strokeWidth="3" />
                  <text x="20" y="70" fill="#f59e0b" fontSize="11" fontWeight="bold" fontFamily="monospace">+</text>
                  <text x="22" y="105" fill="#94a3b8" fontSize="11" fontWeight="bold" fontFamily="monospace">-</text>
                  <text x="12" y="135" fill="#38bdf8" fontSize="10" fontFamily="monospace">
                    {solverResult.totalRow.v ? formatVoltage(solverResult.totalRow.v.value) : 'Vs'}
                  </text>

                  {/* Wire loop */}
                  <path d="M 50 40 L 100 40" fill="none" stroke="#38bdf8" strokeWidth="2" />
                  <path d="M 50 140 L 360 140 L 360 40" fill="none" stroke="#38bdf8" strokeWidth="2" />

                  {/* Resistors */}
                  {solverResult.solvedRows.map((row, idx) => {
                    const count = solverResult.solvedRows.length;
                    const spacing = 220 / count;
                    const x = 100 + idx * spacing;
                    return (
                      <g key={row.id}>
                        <rect x={x + 10} y="28" width="45" height="24" rx="4" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                        <text x={x + 32} y="44" fill="#34d399" fontSize="10" fontWeight="bold" fontFamily="monospace" textAnchor="middle">
                          {row.label}
                        </text>
                        <text x={x + 32} y="68" fill="#94a3b8" fontSize="8" fontFamily="monospace" textAnchor="middle">
                          {row.r ? formatResistance(row.r.value) : '— Ω'}
                        </text>
                        <text x={x + 32} y="80" fill="#f59e0b" fontSize="8" fontFamily="monospace" textAnchor="middle">
                          {row.v ? formatVoltage(row.v.value) : '— V'}
                        </text>
                        <line x1={x + 55} y1="40" x2={x + spacing + 10} y2="40" stroke="#38bdf8" strokeWidth="2" />
                      </g>
                    );
                  })}

                  {/* Current Arrow */}
                  <path d="M 200 140 L 190 136 L 190 144 Z" fill="#38bdf8" />
                  <text x="200" y="160" fill="#38bdf8" fontSize="10" fontFamily="monospace" textAnchor="middle">
                    I_loop = {solverResult.totalRow.i ? formatCurrent(solverResult.totalRow.i.value) : '— A'}
                  </text>
                </svg>
              )}

              {topology.startsWith('parallel_') && (
                <svg viewBox="0 0 400 180" className="w-full max-w-sm drop-shadow-md">
                  {/* DC Source */}
                  <line x1="60" y1="30" x2="60" y2="150" stroke="#0ea5e9" strokeWidth="2" />
                  <line x1="40" y1="75" x2="80" y2="75" stroke="#f59e0b" strokeWidth="3" />
                  <line x1="50" y1="95" x2="70" y2="95" stroke="#64748b" strokeWidth="3" />

                  {/* Rails */}
                  <line x1="60" y1="30" x2="350" y2="30" stroke="#38bdf8" strokeWidth="2.5" />
                  <line x1="60" y1="150" x2="350" y2="150" stroke="#38bdf8" strokeWidth="2.5" />

                  {solverResult.solvedRows.map((row, idx) => {
                    const count = solverResult.solvedRows.length;
                    const spacing = 220 / count;
                    const x = 120 + idx * spacing;
                    return (
                      <g key={row.id}>
                        <circle cx={x} cy="30" r="3" fill="#38bdf8" />
                        <circle cx={x} cy="150" r="3" fill="#38bdf8" />
                        <line x1={x} y1="30" x2={x} y2="60" stroke="#38bdf8" strokeWidth="2" />
                        <rect x={x - 14} y="60" width="28" height="45" rx="4" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                        <text x={x} y="85" fill="#34d399" fontSize="9" fontWeight="bold" fontFamily="monospace" textAnchor="middle">
                          {row.label}
                        </text>
                        <line x1={x} y1="105" x2={x} y2="150" stroke="#38bdf8" strokeWidth="2" />
                        <text x={x + 20} y="75" fill="#94a3b8" fontSize="8" fontFamily="monospace">
                          {row.r ? formatResistance(row.r.value) : '— Ω'}
                        </text>
                        <text x={x + 20} y="90" fill="#38bdf8" fontSize="8" fontFamily="monospace">
                          {row.i ? formatCurrent(row.i.value) : '— A'}
                        </text>
                      </g>
                    );
                  })}
                </svg>
              )}

              {topology === 'combo_series_parallel' && (
                <svg viewBox="0 0 400 180" className="w-full max-w-sm drop-shadow-md">
                  <line x1="40" y1="40" x2="40" y2="140" stroke="#0ea5e9" strokeWidth="2" />
                  <line x1="25" y1="80" x2="55" y2="80" stroke="#f59e0b" strokeWidth="3" />
                  <line x1="30" y1="100" x2="50" y2="100" stroke="#64748b" strokeWidth="3" />

                  {/* Wire to R1 */}
                  <line x1="40" y1="40" x2="100" y2="40" stroke="#38bdf8" strokeWidth="2" />
                  <rect x="100" y="30" width="45" height="20" rx="4" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                  <text x="122" y="44" fill="#34d399" fontSize="9" fontWeight="bold" fontFamily="monospace" textAnchor="middle">
                    R1
                  </text>
                  <line x1="145" y1="40" x2="190" y2="40" stroke="#38bdf8" strokeWidth="2" />

                  {/* Junction Split Node */}
                  <circle cx="190" cy="40" r="3.5" fill="#f59e0b" />
                  <line x1="190" y1="20" x2="190" y2="60" stroke="#38bdf8" strokeWidth="2" />
                  <line x1="190" y1="20" x2="230" y2="20" stroke="#38bdf8" strokeWidth="2" />
                  <line x1="190" y1="60" x2="230" y2="60" stroke="#38bdf8" strokeWidth="2" />

                  {/* R2 & R3 Parallel */}
                  <rect x="230" y="10" width="45" height="20" rx="4" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                  <text x="252" y="24" fill="#34d399" fontSize="9" fontWeight="bold" fontFamily="monospace" textAnchor="middle">
                    R2
                  </text>
                  <rect x="230" y="50" width="45" height="20" rx="4" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                  <text x="252" y="64" fill="#34d399" fontSize="9" fontWeight="bold" fontFamily="monospace" textAnchor="middle">
                    R3
                  </text>

                  {/* Reconnect Node */}
                  <line x1="275" y1="20" x2="315" y2="20" stroke="#38bdf8" strokeWidth="2" />
                  <line x1="275" y1="60" x2="315" y2="60" stroke="#38bdf8" strokeWidth="2" />
                  <line x1="315" y1="20" x2="315" y2="60" stroke="#38bdf8" strokeWidth="2" />
                  <circle cx="315" cy="40" r="3.5" fill="#f59e0b" />

                  {/* Return Path */}
                  <path d="M 315 40 L 360 40 L 360 140 L 40 140" fill="none" stroke="#38bdf8" strokeWidth="2" />
                </svg>
              )}

              {topology === 'combo_parallel_series' && (
                <svg viewBox="0 0 400 180" className="w-full max-w-sm drop-shadow-md">
                  <line x1="40" y1="30" x2="40" y2="150" stroke="#0ea5e9" strokeWidth="2" />
                  <line x1="25" y1="80" x2="55" y2="80" stroke="#f59e0b" strokeWidth="3" />
                  <line x1="30" y1="100" x2="50" y2="100" stroke="#64748b" strokeWidth="3" />

                  <line x1="40" y1="30" x2="360" y2="30" stroke="#38bdf8" strokeWidth="2" />
                  <line x1="40" y1="150" x2="360" y2="150" stroke="#38bdf8" strokeWidth="2" />

                  {/* Branch A: R1 + R2 */}
                  <circle cx="140" cy="30" r="3" fill="#38bdf8" />
                  <circle cx="140" cy="150" r="3" fill="#38bdf8" />
                  <line x1="140" y1="30" x2="140" y2="50" stroke="#38bdf8" strokeWidth="2" />
                  <rect x="128" y="50" width="24" height="28" rx="3" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                  <text x="140" y="68" fill="#34d399" fontSize="8" fontWeight="bold" fontFamily="monospace" textAnchor="middle">R1</text>
                  <line x1="140" y1="78" x2="140" y2="100" stroke="#38bdf8" strokeWidth="2" />
                  <rect x="128" y="100" width="24" height="28" rx="3" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                  <text x="140" y="118" fill="#34d399" fontSize="8" fontWeight="bold" fontFamily="monospace" textAnchor="middle">R2</text>
                  <line x1="140" y1="128" x2="140" y2="150" stroke="#38bdf8" strokeWidth="2" />

                  {/* Branch B: R3 + R4 */}
                  <circle cx="260" cy="30" r="3" fill="#38bdf8" />
                  <circle cx="260" cy="150" r="3" fill="#38bdf8" />
                  <line x1="260" y1="30" x2="260" y2="50" stroke="#38bdf8" strokeWidth="2" />
                  <rect x="248" y="50" width="24" height="28" rx="3" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                  <text x="260" y="68" fill="#34d399" fontSize="8" fontWeight="bold" fontFamily="monospace" textAnchor="middle">R3</text>
                  <line x1="260" y1="78" x2="260" y2="100" stroke="#38bdf8" strokeWidth="2" />
                  <rect x="248" y="100" width="24" height="28" rx="3" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
                  <text x="260" y="118" fill="#34d399" fontSize="8" fontWeight="bold" fontFamily="monospace" textAnchor="middle">R4</text>
                  <line x1="260" y1="128" x2="260" y2="150" stroke="#38bdf8" strokeWidth="2" />
                </svg>
              )}
            </div>
          </div>

          {/* Quick Summary Pill Box */}
          <div className="grid grid-cols-3 gap-2 text-center font-mono text-xs pt-2">
            <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <span className="text-[9px] text-slate-500 uppercase block font-bold">R_Total</span>
              <span className="text-emerald-400 font-bold">
                {solverResult.totalRow.r
                  ? formatResistance(solverResult.totalRow.r.value)
                  : '—'}
              </span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <span className="text-[9px] text-slate-500 uppercase block font-bold">I_Total</span>
              <span className="text-cyan-400 font-bold">
                {solverResult.totalRow.i
                  ? formatCurrent(solverResult.totalRow.i.value)
                  : '—'}
              </span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <span className="text-[9px] text-slate-500 uppercase block font-bold">P_Total</span>
              <span className="text-purple-400 font-bold">
                {solverResult.totalRow.p
                  ? formatPower(solverResult.totalRow.p.value)
                  : '—'}
              </span>
            </div>
          </div>
        </div>

        {/* Right Bento: Step-by-Step Algebraic Derivations (7 Cols) */}
        <div className="lg:col-span-7 bg-slate-900/60 p-5 rounded-3xl border border-slate-800 space-y-4 shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
                Step-by-Step Mathematical Derivations
              </h3>
            </div>
            <span className="text-[11px] font-mono text-slate-400">
              {solverResult.steps.length} Steps Executed
            </span>
          </div>

          {solverResult.steps.length === 0 ? (
            <div className="text-center py-10 space-y-2">
              <HelpCircle className="w-8 h-8 text-slate-600 mx-auto" />
              <p className="text-xs text-slate-400 font-mono">
                No unknown values solved yet. Type your known values above or click an example preset!
              </p>
            </div>
          ) : (
            <div className="space-y-2.5 max-h-[460px] overflow-y-auto pr-1">
              {solverResult.steps.map((step) => (
                <div
                  key={step.stepNumber}
                  className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800/80 space-y-1.5 font-mono text-xs"
                >
                  <div className="flex items-center justify-between">
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      Step {step.stepNumber}: Solve {step.variableName}
                    </span>
                    <span className="text-cyan-300 font-bold text-xs">
                      {step.resultString}
                    </span>
                  </div>

                  <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800/60 space-y-1 text-[11px]">
                    <div className="flex items-center gap-2 text-slate-300">
                      <span className="text-slate-500 uppercase text-[9px] font-bold">
                        Formula:
                      </span>
                      <span className="text-emerald-400 font-bold">
                        {step.formula}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-300">
                      <span className="text-slate-500 uppercase text-[9px] font-bold">
                        Substitution:
                      </span>
                      <span>{step.substitution}</span>
                    </div>
                  </div>

                  <p className="text-[11px] text-slate-400 leading-normal">
                    <strong className="text-slate-300">Rationale:</strong>{' '}
                    {step.rationale}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
