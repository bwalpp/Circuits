import React, { useState, useEffect, useRef } from 'react';
import { Atom, Waves, Zap, Flame, Sliders, Play, Pause, RefreshCw, Info } from 'lucide-react';
import { formatVoltage, formatCurrent, formatResistance, formatPower } from '../utils/circuitMath';
import { sounds } from '../utils/audioHaptics';

export const VisualPhysicsSimulation: React.FC = () => {
  const [mode, setMode] = useState<'electron' | 'water' | 'split'>('split');
  const [voltage, setVoltage] = useState<number>(12); // V
  const [resistance, setResistance] = useState<number>(100); // Ohms
  const [isPlaying, setIsPlaying] = useState<boolean>(true);

  // Derived current and power
  const current = voltage / Math.max(0.1, resistance);
  const power = (voltage * voltage) / Math.max(0.1, resistance);

  // Canvas Refs
  const electronCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const waterCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Electron particle simulation state
  const particlesRef = useRef<
    { x: number; y: number; vx: number; vy: number; radius: number }[]
  >([]);
  const latticeRef = useRef<{ x: number; y: number; baseOffset: number }[]>([]);
  const animFrameIdRef = useRef<number | null>(null);

  // Initialize electrons and copper atomic lattice
  useEffect(() => {
    const numElectrons = 60;
    const particles = [];
    for (let i = 0; i < numElectrons; i++) {
      particles.push({
        x: Math.random() * 600,
        y: 30 + Math.random() * 140,
        vx: (Math.random() - 0.5) * 2,
        vy: (Math.random() - 0.5) * 2,
        radius: 3.5,
      });
    }
    particlesRef.current = particles;

    // Lattice atoms (fixed with thermal jitter)
    const lattice = [];
    for (let x = 60; x <= 540; x += 40) {
      for (let y = 50; y <= 150; y += 40) {
        lattice.push({ x, y, baseOffset: Math.random() * Math.PI * 2 });
      }
    }
    latticeRef.current = lattice;
  }, []);

  // Electron Canvas Animation Loop
  useEffect(() => {
    let lastTime = performance.now();

    const render = (time: number) => {
      const dt = Math.min(0.05, (time - lastTime) / 1000);
      lastTime = time;

      const canvas = electronCanvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          const width = canvas.width;
          const height = canvas.height;

          // Clear background
          ctx.fillStyle = '#020617';
          ctx.fillRect(0, 0, width, height);

          // Draw Conductor Wire Boundaries
          ctx.fillStyle = '#0f172a';
          ctx.fillRect(0, 0, width, 25);
          ctx.fillRect(0, height - 25, width, 25);

          // Electric Field Drift Force
          const driftForce = isPlaying ? (voltage / Math.max(10, resistance)) * 45 : 0;
          const thermalHeat = Math.min(1, power / 5);

          // Thermal Jitter Amplitude of Lattice
          const jitterAmp = 1 + thermalHeat * 5;

          // Draw Resistor Scattering Region in center
          ctx.fillStyle = `rgba(16, 185, 129, ${Math.min(0.2, resistance / 2000)})`;
          ctx.fillRect(200, 25, 200, height - 50);
          ctx.strokeStyle = '#10b981';
          ctx.lineWidth = 1;
          ctx.strokeRect(200, 25, 200, height - 50);

          // Label resistor region
          ctx.fillStyle = '#34d399';
          ctx.font = '11px JetBrains Mono, monospace';
          ctx.textAlign = 'center';
          ctx.fillText(`Resistor Lattice (${formatResistance(resistance)})`, 300, 42);

          // Draw Copper Ion Lattice (+ Cu atoms)
          latticeRef.current.forEach((atom) => {
            const jx = atom.x + (Math.sin(time * 0.01 + atom.baseOffset) * jitterAmp);
            const jy = atom.y + (Math.cos(time * 0.01 + atom.baseOffset) * jitterAmp);

            ctx.beginPath();
            ctx.arc(jx, jy, 9, 0, Math.PI * 2);
            ctx.fillStyle = '#f59e0b';
            ctx.fill();
            ctx.strokeStyle = '#d97706';
            ctx.lineWidth = 1.5;
            ctx.stroke();

            ctx.fillStyle = '#1e293b';
            ctx.font = 'bold 10px monospace';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('+', jx, jy);
          });

          // Update and Draw Electrons
          if (isPlaying) {
            particlesRef.current.forEach((p) => {
              // Apply drift
              p.vx += driftForce * dt * 2;
              p.vx *= 0.98; // Drag friction

              p.x += p.vx;
              p.y += p.vy;

              // Bounds wrap around horizontally
              if (p.x > width) p.x = 0;
              if (p.x < 0) p.x = width;

              // Top/bottom bounce
              if (p.y < 30) {
                p.y = 30;
                p.vy *= -1;
              }
              if (p.y > height - 30) {
                p.y = height - 30;
                p.vy *= -1;
              }

              // Collisions inside resistor region
              if (p.x >= 200 && p.x <= 400) {
                latticeRef.current.forEach((atom) => {
                  const dx = p.x - atom.x;
                  const dy = p.y - atom.y;
                  const dist = Math.hypot(dx, dy);
                  if (dist < 13) {
                    // Collision scatter
                    p.vx = (Math.random() - 0.7) * 4;
                    p.vy = (Math.random() - 0.5) * 4;
                  }
                });
              }

              // Draw electron
              ctx.beginPath();
              ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
              ctx.fillStyle = '#10b981';
              ctx.shadowColor = '#10b981';
              ctx.shadowBlur = 6;
              ctx.fill();
              ctx.shadowBlur = 0;

              // Draw minus sign
              ctx.fillStyle = '#022c22';
              ctx.font = 'bold 8px monospace';
              ctx.textAlign = 'center';
              ctx.textBaseline = 'middle';
              ctx.fillText('-', p.x, p.y);
            });
          }
        }
      }

      // Water Simulation
      const waterCanvas = waterCanvasRef.current;
      if (waterCanvas) {
        const wctx = waterCanvas.getContext('2d');
        if (wctx) {
          const w = waterCanvas.width;
          const h = waterCanvas.height;

          wctx.fillStyle = '#020617';
          wctx.fillRect(0, 0, w, h);

          // Flow speed proportional to current
          const flowSpeed = isPlaying ? (current * 80) : 0;
          const offset = (time * flowSpeed * 0.05) % 40;

          // Draw Pipe Outer Bounds
          wctx.fillStyle = '#0f172a';
          wctx.fillRect(0, 0, w, 40);
          wctx.fillRect(0, h - 40, w, 40);

          // Draw Constriction (Resistor Valve) in Center
          const valveHeight = Math.min(60, (resistance / 1000) * 60 + 10);
          wctx.fillStyle = '#334155';
          wctx.fillRect(250, 40, 100, valveHeight);
          wctx.fillRect(250, h - 40 - valveHeight, 100, valveHeight);

          // Water Stream fill
          wctx.fillStyle = 'rgba(56, 189, 248, 0.25)';
          wctx.fillRect(0, 40, 250, h - 80);
          wctx.fillRect(250, 40 + valveHeight, 100, h - 80 - (valveHeight * 2));
          wctx.fillRect(350, 40, w - 350, h - 80);

          // Animated Flow Streamlines
          wctx.strokeStyle = '#38bdf8';
          wctx.lineWidth = 2;
          wctx.setLineDash([10, 15]);
          wctx.lineDashOffset = -offset;

          // Left Wide Section Lines
          wctx.beginPath();
          wctx.moveTo(0, 70);
          wctx.lineTo(250, 70);
          wctx.moveTo(0, 100);
          wctx.lineTo(250, 100);
          wctx.moveTo(0, 130);
          wctx.lineTo(250, 130);
          wctx.stroke();

          // Constriction Fast Streamlines
          wctx.beginPath();
          wctx.moveTo(250, h / 2);
          wctx.lineTo(350, h / 2);
          wctx.stroke();

          // Right Output Streamlines
          wctx.beginPath();
          wctx.moveTo(350, 70);
          wctx.lineTo(w, 70);
          wctx.moveTo(350, 100);
          wctx.lineTo(w, 100);
          wctx.moveTo(350, 130);
          wctx.lineTo(w, 130);
          wctx.stroke();
          wctx.setLineDash([]);

          // Pump Indicator at Left (Voltage)
          wctx.fillStyle = '#f59e0b';
          wctx.beginPath();
          wctx.arc(40, h / 2, 22, 0, Math.PI * 2);
          wctx.fill();
          wctx.fillStyle = '#0f172a';
          wctx.font = 'bold 10px JetBrains Mono, monospace';
          wctx.textAlign = 'center';
          wctx.fillText(`PUMP`, 40, h / 2 - 3);
          wctx.fillText(`${voltage.toFixed(1)}V`, 40, h / 2 + 9);

          // Valve Indicator at Center (Resistance)
          wctx.fillStyle = '#10b981';
          wctx.font = 'bold 11px JetBrains Mono, monospace';
          wctx.fillText(`VALVE: ${formatResistance(resistance)}`, 300, 30);

          // Flow Meter Indicator at Right (Current)
          wctx.fillStyle = '#0284c7';
          wctx.beginPath();
          wctx.arc(w - 40, h / 2, 20, 0, Math.PI * 2);
          wctx.fill();
          wctx.fillStyle = '#ffffff';
          wctx.font = 'bold 10px JetBrains Mono, monospace';
          wctx.fillText(`Flow (I):`, w - 40, h / 2 - 5);
          wctx.fillText(`${formatCurrent(current)}`, w - 40, h / 2 + 10);
        }
      }

      animFrameIdRef.current = requestAnimationFrame(render);
    };

    animFrameIdRef.current = requestAnimationFrame(render);
    return () => {
      if (animFrameIdRef.current) cancelAnimationFrame(animFrameIdRef.current);
    };
  }, [isPlaying, voltage, resistance, current, power]);

  return (
    <div className="space-y-4">
      {/* Header Bento Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/50 p-4 rounded-3xl border border-slate-800">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <Atom className="w-4 h-4" />
            </span>
            Real-Time Physics & Hydraulic Analogy Simulation
          </h2>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Microscopic electron collisions and macroscopic hydrodynamic analogies side-by-side.
          </p>
        </div>

        {/* View Mode Toggle */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-2xl border border-slate-800">
          <button
            onClick={() => {
              setMode('split');
              sounds.vibrate(15);
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-all ${
              mode === 'split' ? 'bg-emerald-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            Split View
          </button>
          <button
            onClick={() => {
              setMode('electron');
              sounds.vibrate(15);
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-all ${
              mode === 'electron' ? 'bg-emerald-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            Electrons
          </button>
          <button
            onClick={() => {
              setMode('water');
              sounds.vibrate(15);
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-all ${
              mode === 'water' ? 'bg-emerald-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            Hydraulics
          </button>
        </div>
      </div>

      {/* Simulation Bento Canvases */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Electron Particle Lattice Canvas */}
        {(mode === 'electron' || mode === 'split') && (
          <div className="bg-slate-900/50 rounded-3xl border border-slate-800 p-5 space-y-3 shadow-sm">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <h3 className="text-sm font-bold text-slate-200">
                  Microscopic Electron Drift & Atomic Lattice
                </h3>
              </div>
              <span className="text-[11px] font-mono text-emerald-400 font-semibold">
                Joule Heat: {formatPower(power)}
              </span>
            </div>

            {/* Canvas */}
            <div className="w-full bg-slate-950 rounded-2xl border border-slate-800/80 overflow-hidden relative">
              <canvas
                ref={electronCanvasRef}
                width={600}
                height={200}
                className="w-full h-auto block"
              />

              <div className="absolute left-2 top-1/2 -translate-y-1/2 px-2 py-0.5 rounded-lg bg-amber-500/20 text-amber-400 font-mono text-[10px] font-bold border border-amber-500/40">
                - Cathode
              </div>
              <div className="absolute right-2 top-1/2 -translate-y-1/2 px-2 py-0.5 rounded-lg bg-amber-500/20 text-amber-400 font-mono text-[10px] font-bold border border-amber-500/40">
                + Anode
              </div>
            </div>

            <div className="text-xs text-slate-400 leading-relaxed bg-slate-950 p-3 rounded-2xl border border-slate-800/80 font-mono">
              <strong className="text-emerald-400">Mechanism:</strong> Voltage applies electric field pushing electrons rightward. Collisions with copper (+) lattice dissipate potential energy as thermal vibration (<span className="text-amber-400">Joule heating</span>).
            </div>
          </div>
        )}

        {/* Water Hydraulic Analogy Canvas */}
        {(mode === 'water' || mode === 'split') && (
          <div className="bg-slate-900/50 rounded-3xl border border-slate-800 p-5 space-y-3 shadow-sm">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-blue-400" />
                <h3 className="text-sm font-bold text-slate-200">
                  Hydraulic Water Circuit Analogy
                </h3>
              </div>
              <span className="text-[11px] font-mono text-blue-300 font-semibold">
                Flow Rate = {formatCurrent(current)}
              </span>
            </div>

            {/* Canvas */}
            <div className="w-full bg-slate-950 rounded-2xl border border-slate-800/80 overflow-hidden">
              <canvas
                ref={waterCanvasRef}
                width={600}
                height={200}
                className="w-full h-auto block"
              />
            </div>

            <div className="text-xs text-slate-400 leading-relaxed bg-slate-950 p-3 rounded-2xl border border-slate-800/80 font-mono">
              <strong className="text-blue-300">Equivalents:</strong> <span className="text-amber-400">Water Pump</span> = Voltage (Pressure ΔP), <span className="text-emerald-400">Narrow Valve</span> = Resistance ($R$), and <span className="text-cyan-400">Flow Meter</span> = Current ($I = V/R$).
            </div>
          </div>
        )}
      </div>

      {/* Physics Tuning Controls Bento Box */}
      <div className="bg-slate-900/50 rounded-3xl border border-slate-800 p-5 sm:p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2 font-mono">
            <Sliders className="w-4 h-4 text-emerald-400" />
            Adjust Physics Parameters
          </h3>
          <button
            onClick={() => {
              setIsPlaying(!isPlaying);
              sounds.playSwitchClick(!isPlaying);
            }}
            className={`px-3.5 py-1.5 rounded-2xl text-xs font-bold font-mono flex items-center gap-1.5 transition-all ${
              isPlaying
                ? 'bg-amber-500/20 border border-amber-500/40 text-amber-300'
                : 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
            }`}
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            {isPlaying ? 'Pause Simulation' : 'Resume Simulation'}
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Voltage Control */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-mono text-emerald-400">
              <label className="font-bold flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5" />
                Applied Voltage (Push / ΔP):
              </label>
              <strong className="text-white bg-slate-950 px-2 py-0.5 rounded-lg border border-slate-800">
                {voltage.toFixed(1)} Volts
              </strong>
            </div>
            <input
              type="range"
              min="1"
              max="48"
              step="0.5"
              value={voltage}
              onChange={(e) => {
                setVoltage(parseFloat(e.target.value));
                sounds.playTick();
              }}
              className="w-full accent-emerald-500"
            />
          </div>

          {/* Resistance Control */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-mono text-amber-400">
              <label className="font-bold flex items-center gap-1.5">
                <Flame className="w-3.5 h-3.5" />
                Resistance (Lattice Scattering / Valve):
              </label>
              <strong className="text-white bg-slate-950 px-2 py-0.5 rounded-lg border border-slate-800">
                {formatResistance(resistance)}
              </strong>
            </div>
            <input
              type="range"
              min="10"
              max="1000"
              step="10"
              value={resistance}
              onChange={(e) => {
                setResistance(parseFloat(e.target.value));
                sounds.playTick();
              }}
              className="w-full accent-amber-500"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
