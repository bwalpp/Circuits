import React, { useState, useEffect, useRef } from 'react';
import {
  Wrench,
  RotateCw,
  Trash2,
  Zap,
  Lightbulb,
  Radio,
  ToggleLeft,
  ShieldAlert,
  HelpCircle,
  Activity,
  Sliders,
  Sparkles,
  BookOpen,
  FolderOpen,
  Save,
  PlusCircle,
  Layers,
  Flame,
  ArrowRight,
  CheckCircle2,
  RefreshCw,
  Cpu,
  Compass,
  Move,
  Edit3,
} from 'lucide-react';
import {
  CustomComponent,
  CustomWire,
  CustomCompType,
  SimulationResult,
} from '../types';
import {
  simulateCustomCircuit,
  getComponentPinList,
  formatVoltage,
  formatCurrent,
  formatResistance,
  formatPower,
} from '../utils/circuitMath';
import { sounds } from '../utils/audioHaptics';

interface SelectedPin {
  compId: string;
  pinId: string;
}

interface PreMadeCircuit {
  id: string;
  title: string;
  category: 'Fundamentals' | 'Combination' | 'Protection & LEDs' | 'Sensors & Bridges';
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  description: string;
  learningGoal: string;
  components: CustomComponent[];
  wires: CustomWire[];
}

export const CustomCircuitDesigner: React.FC = () => {
  // Mode selection: 'library' (Pre-Made circuits) vs 'custom' (Make your own)
  const [designerMode, setDesignerMode] = useState<'library' | 'custom'>('library');

  // Canvas grid dimensions
  const GRID_COLS = 16;
  const GRID_ROWS = 10;
  const CELL_SIZE = 48; // px

  const svgRef = useRef<SVGSVGElement>(null);

  // Dragging state
  const [draggingCompId, setDraggingCompId] = useState<string | null>(null);
  const [dragStartPos, setDragStartPos] = useState<{ x: number; y: number } | null>(null);
  const [hasMovedDuringDrag, setHasMovedDuringDrag] = useState<boolean>(false);

  // ---------------------------------------------------------------------------
  // PRE-MADE CIRCUITS LIBRARY
  // ---------------------------------------------------------------------------
  const preMadeCircuits: PreMadeCircuit[] = [
    {
      id: 'simple_single_loop',
      title: 'Simple Single-Loop Circuit',
      category: 'Fundamentals',
      difficulty: 'Beginner',
      description: 'A pure Ohm’s Law circuit with a 9V battery, protective SPST toggle switch, and a 220Ω precision resistor.',
      learningGoal: 'Demonstrates basic current loop continuity and I = V / R calculation.',
      components: [
        { id: 'src_1', type: 'dc_source', label: '9V Battery', x: 4, y: 5, rotation: 0, value: 9 },
        { id: 'sw_1', type: 'switch', label: 'Power Switch', x: 8, y: 2, rotation: 0, value: 0, extra: { switchClosed: true } },
        { id: 'r_1', type: 'resistor', label: 'Load R1 (220Ω)', x: 12, y: 5, rotation: 90, value: 220 },
        { id: 'gnd_1', type: 'ground', label: 'GND (0V)', x: 4, y: 8, rotation: 0, value: 0 },
      ],
      wires: [
        { id: 'w1', fromCompId: 'src_1', fromPinId: 'pos', toCompId: 'sw_1', toPinId: 'p1' },
        { id: 'w2', fromCompId: 'sw_1', fromPinId: 'p2', toCompId: 'r_1', toPinId: 'p1' },
        { id: 'w3', fromCompId: 'r_1', fromPinId: 'p2', toCompId: 'src_1', toPinId: 'neg' },
        { id: 'w4', fromCompId: 'src_1', fromPinId: 'neg', toCompId: 'gnd_1', toPinId: 'gnd' },
      ],
    },
    {
      id: 'series_voltage_divider',
      title: '3-Resistor Series Voltage Divider',
      category: 'Fundamentals',
      difficulty: 'Beginner',
      description: 'Three resistors in series sharing one identical current, dividing a 12V supply proportionally according to KVL.',
      learningGoal: 'Shows how series resistance sums up and how voltages divide across individual components.',
      components: [
        { id: 'src_1', type: 'dc_source', label: '12V DC', x: 3, y: 5, rotation: 0, value: 12 },
        { id: 'r_1', type: 'resistor', label: 'R1 (100Ω)', x: 6, y: 2, rotation: 0, value: 100 },
        { id: 'r_2', type: 'resistor', label: 'R2 (220Ω)', x: 10, y: 2, rotation: 0, value: 220 },
        { id: 'r_3', type: 'resistor', label: 'R3 (470Ω)', x: 13, y: 5, rotation: 90, value: 470 },
        { id: 'gnd_1', type: 'ground', label: 'GND', x: 3, y: 8, rotation: 0, value: 0 },
      ],
      wires: [
        { id: 'w1', fromCompId: 'src_1', fromPinId: 'pos', toCompId: 'r_1', toPinId: 'p1' },
        { id: 'w2', fromCompId: 'r_1', fromPinId: 'p2', toCompId: 'r_2', toPinId: 'p1' },
        { id: 'w3', fromCompId: 'r_2', fromPinId: 'p2', toCompId: 'r_3', toPinId: 'p1' },
        { id: 'w4', fromCompId: 'r_3', fromPinId: 'p2', toCompId: 'src_1', toPinId: 'neg' },
        { id: 'w5', fromCompId: 'src_1', fromPinId: 'neg', toCompId: 'gnd_1', toPinId: 'gnd' },
      ],
    },
    {
      id: 'parallel_lamps',
      title: '3-Branch Parallel Lighting Grid',
      category: 'Fundamentals',
      difficulty: 'Beginner',
      description: 'Three incandescent lamps wired in parallel across a 12V rail. Each receives the full 12V and operates independently.',
      learningGoal: 'Illustrates constant voltage across parallel branches and Kirchhoff’s Current Law (KCL) junction sum.',
      components: [
        { id: 'src_1', type: 'dc_source', label: '12V DC', x: 3, y: 5, rotation: 0, value: 12 },
        { id: 'b_1', type: 'bulb', label: 'Lamp A (48Ω)', x: 6, y: 5, rotation: 90, value: 48 },
        { id: 'b_2', type: 'bulb', label: 'Lamp B (48Ω)', x: 10, y: 5, rotation: 90, value: 48 },
        { id: 'b_3', type: 'bulb', label: 'Lamp C (48Ω)', x: 14, y: 5, rotation: 90, value: 48 },
        { id: 'gnd_1', type: 'ground', label: 'GND', x: 3, y: 8, rotation: 0, value: 0 },
      ],
      wires: [
        { id: 'w1', fromCompId: 'src_1', fromPinId: 'pos', toCompId: 'b_1', toPinId: 'p1' },
        { id: 'w2', fromCompId: 'b_1', fromPinId: 'p1', toCompId: 'b_2', toPinId: 'p1' },
        { id: 'w3', fromCompId: 'b_2', fromPinId: 'p1', toCompId: 'b_3', toPinId: 'p1' },
        { id: 'w4', fromCompId: 'src_1', fromPinId: 'neg', toCompId: 'b_1', toPinId: 'p2' },
        { id: 'w5', fromCompId: 'b_1', fromPinId: 'p2', toCompId: 'b_2', toPinId: 'p2' },
        { id: 'w6', fromCompId: 'b_2', fromPinId: 'p2', toCompId: 'b_3', toPinId: 'p2' },
        { id: 'w7', fromCompId: 'src_1', fromPinId: 'neg', toCompId: 'gnd_1', toPinId: 'gnd' },
      ],
    },
    {
      id: 'series_parallel_combo',
      title: 'Series-Parallel Combination Network',
      category: 'Combination',
      difficulty: 'Intermediate',
      description: 'A 12V battery with series trunk resistor R1 driving a parallel junction of Lamp B and Resistor R2.',
      learningGoal: 'Master solving combination circuits: R_eq = R1 + (R2 || R_lamp).',
      components: [
        { id: 'src_1', type: 'dc_source', label: '12V DC', x: 3, y: 5, rotation: 0, value: 12 },
        { id: 'fuse_1', type: 'fuse', label: 'Fuse 2A', x: 6, y: 2, rotation: 0, value: 2.0, extra: { fuseBlown: false } },
        { id: 'sw_1', type: 'switch', label: 'Switch', x: 9, y: 2, rotation: 0, value: 0, extra: { switchClosed: true } },
        { id: 'r_1', type: 'resistor', label: 'R1 Trunk (100Ω)', x: 12, y: 2, rotation: 0, value: 100 },
        { id: 'bulb_1', type: 'bulb', label: 'Lamp A (50Ω)', x: 14, y: 5, rotation: 90, value: 50 },
        { id: 'r_2', type: 'resistor', label: 'R2 (200Ω)', x: 11, y: 5, rotation: 90, value: 200 },
        { id: 'gnd_1', type: 'ground', label: 'GND', x: 3, y: 8, rotation: 0, value: 0 },
      ],
      wires: [
        { id: 'w1', fromCompId: 'src_1', fromPinId: 'pos', toCompId: 'fuse_1', toPinId: 'p1' },
        { id: 'w2', fromCompId: 'fuse_1', fromPinId: 'p2', toCompId: 'sw_1', toPinId: 'p1' },
        { id: 'w3', fromCompId: 'sw_1', fromPinId: 'p2', toCompId: 'r_1', toPinId: 'p1' },
        { id: 'w4', fromCompId: 'r_1', fromPinId: 'p2', toCompId: 'bulb_1', toPinId: 'p1' },
        { id: 'w5', fromCompId: 'r_1', fromPinId: 'p2', toCompId: 'r_2', toPinId: 'p1' },
        { id: 'w6', fromCompId: 'bulb_1', fromPinId: 'p2', toCompId: 'r_2', toPinId: 'p2' },
        { id: 'w7', fromCompId: 'r_2', fromPinId: 'p2', toCompId: 'src_1', toPinId: 'neg' },
        { id: 'w8', fromCompId: 'src_1', fromPinId: 'neg', toCompId: 'gnd_1', toPinId: 'gnd' },
      ],
    },
    {
      id: 'parallel_series_bridge',
      title: 'Dual-Branch (Parallel-Series) Network',
      category: 'Combination',
      difficulty: 'Intermediate',
      description: 'Two separate series branches wired in parallel: Branch A (R1+R2) and Branch B (R3+R4).',
      learningGoal: 'Teaches branch isolation and finding node potentials between series pairs.',
      components: [
        { id: 'src_1', type: 'dc_source', label: '24V DC', x: 3, y: 5, rotation: 0, value: 24 },
        { id: 'r_1', type: 'resistor', label: 'R1 Top (100Ω)', x: 7, y: 3, rotation: 90, value: 100 },
        { id: 'r_2', type: 'resistor', label: 'R2 Bot (200Ω)', x: 7, y: 7, rotation: 90, value: 200 },
        { id: 'r_3', type: 'resistor', label: 'R3 Top (300Ω)', x: 12, y: 3, rotation: 90, value: 300 },
        { id: 'r_4', type: 'resistor', label: 'R4 Bot (150Ω)', x: 12, y: 7, rotation: 90, value: 150 },
        { id: 'gnd_1', type: 'ground', label: 'GND', x: 3, y: 8, rotation: 0, value: 0 },
      ],
      wires: [
        { id: 'w1', fromCompId: 'src_1', fromPinId: 'pos', toCompId: 'r_1', toPinId: 'p1' },
        { id: 'w2', fromCompId: 'r_1', fromPinId: 'p1', toCompId: 'r_3', toPinId: 'p1' },
        { id: 'w3', fromCompId: 'r_1', fromPinId: 'p2', toCompId: 'r_2', toPinId: 'p1' },
        { id: 'w4', fromCompId: 'r_3', fromPinId: 'p2', toCompId: 'r_4', toPinId: 'p1' },
        { id: 'w5', fromCompId: 'r_2', fromPinId: 'p2', toCompId: 'r_4', toPinId: 'p2' },
        { id: 'w6', fromCompId: 'r_2', fromPinId: 'p2', toCompId: 'src_1', toPinId: 'neg' },
        { id: 'w7', fromCompId: 'src_1', fromPinId: 'neg', toCompId: 'gnd_1', toPinId: 'gnd' },
      ],
    },
    {
      id: 'led_driver_circuit',
      title: 'LED Driver with Limiting Resistor',
      category: 'Protection & LEDs',
      difficulty: 'Beginner',
      description: 'A 9V source driving a high-brightness LED through a 330Ω current-limiting resistor to protect the diode from burning out.',
      learningGoal: 'Learn forward voltage drop ($V_F$) and resistor sizing: R = (V_supply - V_F) / I_target.',
      components: [
        { id: 'src_1', type: 'dc_source', label: '9V Battery', x: 4, y: 5, rotation: 0, value: 9 },
        { id: 'sw_1', type: 'switch', label: 'Toggle Switch', x: 7, y: 2, rotation: 0, value: 0, extra: { switchClosed: true } },
        { id: 'r_1', type: 'resistor', label: 'R_limit (330Ω)', x: 11, y: 2, rotation: 0, value: 330 },
        { id: 'led_1', type: 'led', label: 'Bright Green LED', x: 13, y: 5, rotation: 90, value: 100, extra: { ledColor: 'green', forwardVoltage: 2.2 } },
        { id: 'gnd_1', type: 'ground', label: 'GND', x: 4, y: 8, rotation: 0, value: 0 },
      ],
      wires: [
        { id: 'w1', fromCompId: 'src_1', fromPinId: 'pos', toCompId: 'sw_1', toPinId: 'p1' },
        { id: 'w2', fromCompId: 'sw_1', fromPinId: 'p2', toCompId: 'r_1', toPinId: 'p1' },
        { id: 'w3', fromCompId: 'r_1', fromPinId: 'p2', toCompId: 'led_1', toPinId: 'anode' },
        { id: 'w4', fromCompId: 'led_1', fromPinId: 'cathode', toCompId: 'src_1', toPinId: 'neg' },
        { id: 'w5', fromCompId: 'src_1', fromPinId: 'neg', toCompId: 'gnd_1', toPinId: 'gnd' },
      ],
    },
    {
      id: 'fuse_overload_lab',
      title: 'Fuse Overload & Short-Circuit Safety Lab',
      category: 'Protection & LEDs',
      difficulty: 'Intermediate',
      description: 'A 12V high-capacity supply with a 1.0A fast-acting fuse. Toggling the low-resistance bypass switch simulates a short circuit that blows the fuse!',
      learningGoal: 'Experience circuit protection, overcurrent triggers, and how fuses safely break dangerous fault currents.',
      components: [
        { id: 'src_1', type: 'dc_source', label: '12V Power', x: 3, y: 5, rotation: 0, value: 12 },
        { id: 'fuse_1', type: 'fuse', label: '1.0A Fast Fuse', x: 6, y: 2, rotation: 0, value: 1.0, extra: { fuseBlown: false } },
        { id: 'r_safe', type: 'resistor', label: 'Normal Load (50Ω)', x: 10, y: 5, rotation: 90, value: 50 },
        { id: 'sw_short', type: 'switch', label: 'Overload Bypass', x: 13, y: 2, rotation: 0, value: 0, extra: { switchClosed: false } },
        { id: 'r_short', type: 'resistor', label: 'Short (5Ω Fault)', x: 14, y: 5, rotation: 90, value: 5 },
        { id: 'gnd_1', type: 'ground', label: 'GND', x: 3, y: 8, rotation: 0, value: 0 },
      ],
      wires: [
        { id: 'w1', fromCompId: 'src_1', fromPinId: 'pos', toCompId: 'fuse_1', toPinId: 'p1' },
        { id: 'w2', fromCompId: 'fuse_1', fromPinId: 'p2', toCompId: 'r_safe', toPinId: 'p1' },
        { id: 'w3', fromCompId: 'fuse_1', fromPinId: 'p2', toCompId: 'sw_short', toPinId: 'p1' },
        { id: 'w4', fromCompId: 'sw_short', fromPinId: 'p2', toCompId: 'r_short', toPinId: 'p1' },
        { id: 'w5', fromCompId: 'r_safe', fromPinId: 'p2', toCompId: 'src_1', toPinId: 'neg' },
        { id: 'w6', fromCompId: 'r_short', fromPinId: 'p2', toCompId: 'src_1', toPinId: 'neg' },
        { id: 'w7', fromCompId: 'src_1', fromPinId: 'neg', toCompId: 'gnd_1', toPinId: 'gnd' },
      ],
    },
    {
      id: 'wheatstone_bridge_sensor',
      title: 'Wheatstone Bridge Precision Sensor Network',
      category: 'Sensors & Bridges',
      difficulty: 'Advanced',
      description: 'A 10V bridge network. When R1/R2 = R3/R4, differential voltage V_AB is null (0V). Changing any resistor unbalances the bridge.',
      learningGoal: 'Understand bridge balancing, null-detectors, and strain gauge / RTD sensor measurement principles.',
      components: [
        { id: 'src_1', type: 'dc_source', label: '10V Precision', x: 3, y: 5, rotation: 0, value: 10 },
        { id: 'r_1', type: 'resistor', label: 'R1 (100Ω)', x: 7, y: 3, rotation: 90, value: 100 },
        { id: 'r_2', type: 'resistor', label: 'R2 (100Ω)', x: 7, y: 7, rotation: 90, value: 100 },
        { id: 'r_3', type: 'resistor', label: 'R3 (200Ω)', x: 12, y: 3, rotation: 90, value: 200 },
        { id: 'r_4', type: 'resistor', label: 'R4 (200Ω)', x: 12, y: 7, rotation: 90, value: 200 },
        { id: 'gnd_1', type: 'ground', label: 'GND', x: 3, y: 8, rotation: 0, value: 0 },
      ],
      wires: [
        { id: 'w1', fromCompId: 'src_1', fromPinId: 'pos', toCompId: 'r_1', toPinId: 'p1' },
        { id: 'w2', fromCompId: 'r_1', fromPinId: 'p1', toCompId: 'r_3', toPinId: 'p1' },
        { id: 'w3', fromCompId: 'r_1', fromPinId: 'p2', toCompId: 'r_2', toPinId: 'p1' },
        { id: 'w4', fromCompId: 'r_3', fromPinId: 'p2', toCompId: 'r_4', toPinId: 'p1' },
        { id: 'w5', fromCompId: 'r_2', fromPinId: 'p2', toCompId: 'r_4', toPinId: 'p2' },
        { id: 'w6', fromCompId: 'r_2', fromPinId: 'p2', toCompId: 'src_1', toPinId: 'neg' },
        { id: 'w7', fromCompId: 'src_1', fromPinId: 'neg', toCompId: 'gnd_1', toPinId: 'gnd' },
      ],
    },
  ];

  // Active circuit on the interactive canvas
  const [components, setComponents] = useState<CustomComponent[]>(preMadeCircuits[3].components);
  const [wires, setWires] = useState<CustomWire[]>(preMadeCircuits[3].wires);
  const [activeLoadedCircuitTitle, setActiveLoadedCircuitTitle] = useState<string>('Series-Parallel Combination Network');

  // Selected circuit in library view
  const [selectedLibraryId, setSelectedLibraryId] = useState<string>('series_parallel_combo');
  const [libraryCategory, setLibraryCategory] = useState<string>('All');

  // Canvas selection state
  const [selectedCompId, setSelectedCompId] = useState<string | null>(null);
  const [selectedWireId, setSelectedWireId] = useState<string | null>(null);
  const [wiringStartPin, setWiringStartPin] = useState<SelectedPin | null>(null);

  // User Saved Circuits (stored in state / local storage)
  const [savedUserCircuits, setSavedUserCircuits] = useState<{ name: string; components: CustomComponent[]; wires: CustomWire[] }[]>(() => {
    try {
      const stored = localStorage.getItem('ohm_lab_user_circuits');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });
  const [saveCircuitName, setSaveCircuitName] = useState<string>('My Custom Circuit');
  const [showSaveModal, setShowSaveModal] = useState<boolean>(false);

  // Live simulation results
  const [simResult, setSimResult] = useState<SimulationResult>({
    nodeVoltages: {},
    componentCurrents: {},
    componentVoltages: {},
    componentPowers: {},
    wireCurrents: {},
    totalSourcePower: 0,
    totalEquivalentResistance: 0,
    isShortCircuit: false,
    blownFuses: [],
  });

  // Run simulation
  useEffect(() => {
    const result = simulateCustomCircuit(components, wires);
    setSimResult(result);

    // If any fuse blew during this simulation frame
    if (result.blownFuses.length > 0) {
      let changed = false;
      const updated = components.map((c) => {
        if (result.blownFuses.includes(c.id) && !c.extra?.fuseBlown) {
          changed = true;
          return { ...c, extra: { ...c.extra, fuseBlown: true } };
        }
        return c;
      });
      if (changed) {
        setComponents(updated);
        sounds.playFuseBlow();
      }
    }
  }, [components, wires]);

  // Load a Pre-Made circuit into the simulator and switch to custom canvas mode
  const handleLoadPreMade = (circuit: PreMadeCircuit) => {
    sounds.playSuccess();
    setComponents(JSON.parse(JSON.stringify(circuit.components)));
    setWires(JSON.parse(JSON.stringify(circuit.wires)));
    setActiveLoadedCircuitTitle(circuit.title);
    setSelectedCompId(null);
    setSelectedWireId(null);
    setWiringStartPin(null);
    setDesignerMode('custom');
  };

  // Start with a clean blank canvas in "Make Your Own" mode
  const handleStartBlank = () => {
    sounds.playSwitchClick(true);
    setComponents([
      { id: 'src_1', type: 'dc_source', label: '12V DC', x: 4, y: 5, rotation: 0, value: 12 },
      { id: 'gnd_1', type: 'ground', label: 'GND', x: 4, y: 8, rotation: 0, value: 0 },
    ]);
    setWires([
      { id: 'w1', fromCompId: 'src_1', fromPinId: 'neg', toCompId: 'gnd_1', toPinId: 'gnd' },
    ]);
    setActiveLoadedCircuitTitle('Custom Scratchpad');
    setSelectedCompId('src_1');
    setSelectedWireId(null);
    setWiringStartPin(null);
    setDesignerMode('custom');
  };

  // Add component onto canvas
  const addComponent = (type: CustomCompType) => {
    sounds.playSwitchClick(true);
    const newId = `comp_${Date.now()}`;
    let label = '';
    let val = 100;
    let extra = {};

    switch (type) {
      case 'dc_source':
        label = '12V DC';
        val = 12;
        break;
      case 'resistor':
        label = `R (${formatResistance(100)})`;
        val = 100;
        break;
      case 'bulb':
        label = 'Lamp (48Ω)';
        val = 48;
        break;
      case 'led':
        label = 'LED (Green)';
        val = 100;
        extra = { ledColor: 'green', forwardVoltage: 2.2 };
        break;
      case 'switch':
        label = 'SPST Switch';
        val = 0;
        extra = { switchClosed: true };
        break;
      case 'fuse':
        label = 'Fuse (1.0A)';
        val = 1.0;
        extra = { fuseBlown: false };
        break;
      case 'ground':
        label = 'GND (0V)';
        val = 0;
        break;
      case 'voltmeter':
        label = 'Voltmeter';
        val = 0;
        break;
      case 'ammeter':
        label = 'Ammeter';
        val = 0;
        break;
    }

    // Place near center grid with a slight random offset to prevent exact overlapping
    const offset = (components.length % 4);
    const newComp: CustomComponent = {
      id: newId,
      type,
      label,
      x: 7 + offset,
      y: 4 + offset,
      rotation: 0,
      value: val,
      extra,
    };

    setComponents([...components, newComp]);
    setSelectedCompId(newId);
  };

  // Rotate selected component
  const rotateSelected = () => {
    if (!selectedCompId) return;
    sounds.playSwitchClick(true);
    setComponents((prev) =>
      prev.map((c) => {
        if (c.id === selectedCompId) {
          const nextRot = ((c.rotation + 90) % 360) as 0 | 90 | 180 | 270;
          return { ...c, rotation: nextRot };
        }
        return c;
      })
    );
  };

  // Delete selected element
  const deleteSelected = () => {
    if (selectedCompId) {
      sounds.playSwitchClick(false);
      setComponents((prev) => prev.filter((c) => c.id !== selectedCompId));
      setWires((prev) =>
        prev.filter((w) => w.fromCompId !== selectedCompId && w.toCompId !== selectedCompId)
      );
      setSelectedCompId(null);
    } else if (selectedWireId) {
      sounds.playSwitchClick(false);
      setWires((prev) => prev.filter((w) => w.id !== selectedWireId));
      setSelectedWireId(null);
    }
  };

  // ---------------------------------------------------------------------------
  // CANVAS DRAG & DROP HANDLING
  // ---------------------------------------------------------------------------
  const getGridCoordsFromEvent = (
    clientX: number,
    clientY: number
  ): { gridX: number; gridY: number } | null => {
    if (!svgRef.current) return null;
    const rect = svgRef.current.getBoundingClientRect();
    const svgX = ((clientX - rect.left) / rect.width) * (GRID_COLS * CELL_SIZE);
    const svgY = ((clientY - rect.top) / rect.height) * (GRID_ROWS * CELL_SIZE);

    const gridX = Math.max(1, Math.min(GRID_COLS - 1, Math.round(svgX / CELL_SIZE)));
    const gridY = Math.max(1, Math.min(GRID_ROWS - 1, Math.round(svgY / CELL_SIZE)));
    return { gridX, gridY };
  };

  const handleCompMouseDown = (e: React.MouseEvent, comp: CustomComponent) => {
    e.stopPropagation();
    setSelectedCompId(comp.id);
    setSelectedWireId(null);
    setDraggingCompId(comp.id);
    setDragStartPos({ x: comp.x, y: comp.y });
    setHasMovedDuringDrag(false);
  };

  const handleCompTouchStart = (e: React.TouchEvent, comp: CustomComponent) => {
    e.stopPropagation();
    setSelectedCompId(comp.id);
    setSelectedWireId(null);
    setDraggingCompId(comp.id);
    setDragStartPos({ x: comp.x, y: comp.y });
    setHasMovedDuringDrag(false);
  };

  const handleCanvasMouseMove = (e: React.MouseEvent) => {
    if (!draggingCompId) return;
    const coords = getGridCoordsFromEvent(e.clientX, e.clientY);
    if (!coords) return;

    setHasMovedDuringDrag(true);
    setComponents((prev) =>
      prev.map((c) => {
        if (c.id === draggingCompId && (c.x !== coords.gridX || c.y !== coords.gridY)) {
          return { ...c, x: coords.gridX, y: coords.gridY };
        }
        return c;
      })
    );
  };

  const handleCanvasTouchMove = (e: React.TouchEvent) => {
    if (!draggingCompId || e.touches.length === 0) return;
    const touch = e.touches[0];
    const coords = getGridCoordsFromEvent(touch.clientX, touch.clientY);
    if (!coords) return;

    setHasMovedDuringDrag(true);
    setComponents((prev) =>
      prev.map((c) => {
        if (c.id === draggingCompId && (c.x !== coords.gridX || c.y !== coords.gridY)) {
          return { ...c, x: coords.gridX, y: coords.gridY };
        }
        return c;
      })
    );
  };

  const handleCanvasMouseUp = () => {
    if (draggingCompId) {
      if (hasMovedDuringDrag) {
        sounds.playTick();
      }
      setDraggingCompId(null);
      setDragStartPos(null);
    }
  };

  // Handle clicking component on canvas (switch toggle / fuse reset if not dragged)
  const handleCompClick = (comp: CustomComponent) => {
    if (hasMovedDuringDrag) return;

    if (comp.type === 'switch') {
      const nextState = !(comp.extra?.switchClosed ?? true);
      sounds.playSwitchClick(nextState);
      setComponents((prev) =>
        prev.map((c) =>
          c.id === comp.id ? { ...c, extra: { ...c.extra, switchClosed: nextState } } : c
        )
      );
    } else if (comp.type === 'fuse' && comp.extra?.fuseBlown) {
      sounds.playSwitchClick(true);
      setComponents((prev) =>
        prev.map((c) =>
          c.id === comp.id ? { ...c, extra: { ...c.extra, fuseBlown: false } } : c
        )
      );
    }
  };

  // Handle pin click for wiring
  const handlePinClick = (e: React.MouseEvent, compId: string, pinId: string) => {
    e.stopPropagation();
    if (!wiringStartPin) {
      sounds.playTick();
      setWiringStartPin({ compId, pinId });
    } else {
      if (wiringStartPin.compId === compId && wiringStartPin.pinId === pinId) {
        setWiringStartPin(null);
        return;
      }
      sounds.playSuccess();
      const newWire: CustomWire = {
        id: `wire_${Date.now()}`,
        fromCompId: wiringStartPin.compId,
        fromPinId: wiringStartPin.pinId,
        toCompId: compId,
        toPinId: pinId,
      };
      setWires((prev) => [...prev, newWire]);
      setWiringStartPin(null);
    }
  };

  // Save current circuit to user's saved collection
  const handleSaveCircuit = () => {
    if (!saveCircuitName.trim()) return;
    const newEntry = {
      name: saveCircuitName.trim(),
      components: JSON.parse(JSON.stringify(components)),
      wires: JSON.parse(JSON.stringify(wires)),
    };
    const updated = [newEntry, ...savedUserCircuits.filter((c) => c.name !== newEntry.name)];
    setSavedUserCircuits(updated);
    try {
      localStorage.setItem('ohm_lab_user_circuits', JSON.stringify(updated));
    } catch {
      // fallback
    }
    setShowSaveModal(false);
    sounds.playSuccess();
  };

  // Load a user-saved circuit
  const handleLoadUserSaved = (saved: { name: string; components: CustomComponent[]; wires: CustomWire[] }) => {
    sounds.playSuccess();
    setComponents(JSON.parse(JSON.stringify(saved.components)));
    setWires(JSON.parse(JSON.stringify(saved.wires)));
    setActiveLoadedCircuitTitle(saved.name);
    setDesignerMode('custom');
  };

  // Helper for pin positions
  const getPinAbsolutePos = (comp: CustomComponent, pinId: string) => {
    const pins = getComponentPinList(comp.type);
    const pin = pins.find((p) => p.id === pinId);
    if (!pin) return { x: comp.x * CELL_SIZE, y: comp.y * CELL_SIZE };

    const rad = (comp.rotation * Math.PI) / 180;
    const rx = pin.relX * CELL_SIZE;
    const ry = pin.relY * CELL_SIZE;

    const rotX = rx * Math.cos(rad) - ry * Math.sin(rad);
    const rotY = rx * Math.sin(rad) + ry * Math.cos(rad);

    return {
      x: comp.x * CELL_SIZE + rotX,
      y: comp.y * CELL_SIZE + rotY,
    };
  };

  const selectedComp = components.find((c) => c.id === selectedCompId);
  const selectedPreMade = preMadeCircuits.find((c) => c.id === selectedLibraryId) || preMadeCircuits[0];

  const filteredLibrary = libraryCategory === 'All'
    ? preMadeCircuits
    : preMadeCircuits.filter((c) => c.category === libraryCategory);

  return (
    <div className="space-y-4">
      {/* Top Main Mode Switcher Bento Card */}
      <div className="bg-slate-900/50 p-4 sm:p-5 rounded-3xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <Compass className="w-4 h-4" />
            </span>
            Circuit Design & Simulation Lab
          </h2>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Choose a verified Pre-Made educational circuit or Make Your Own custom circuit with drag-and-drop & typable parameters.
          </p>
        </div>

        {/* Mode Selector Toggle Pills */}
        <div className="flex items-center gap-2 bg-slate-950 p-1.5 rounded-2xl border border-slate-800 self-start md:self-auto shadow-inner">
          <button
            onClick={() => {
              setDesignerMode('library');
              sounds.playSwitchClick(true);
            }}
            className={`px-4 py-2 rounded-xl text-xs font-mono font-bold flex items-center gap-2 transition-all ${
              designerMode === 'library'
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            Pre-Made Circuits ({preMadeCircuits.length})
          </button>
          <button
            onClick={() => {
              setDesignerMode('custom');
              sounds.playSwitchClick(false);
            }}
            className={`px-4 py-2 rounded-xl text-xs font-mono font-bold flex items-center gap-2 transition-all ${
              designerMode === 'custom'
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Wrench className="w-4 h-4" />
            Make Your Own Circuit
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* MODE 1: PRE-MADE CIRCUITS LIBRARY VIEW */}
      {/* ========================================================================= */}
      {designerMode === 'library' && (
        <div className="space-y-4">
          {/* Filter Categories and Create From Scratch Quick Action */}
          <div className="bg-slate-900/50 p-4 rounded-3xl border border-slate-800 flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-[10px] font-mono font-bold text-slate-400 uppercase mr-1">
                Filter Category:
              </span>
              {['All', 'Fundamentals', 'Combination', 'Protection & LEDs', 'Sensors & Bridges'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => {
                    setLibraryCategory(cat);
                    sounds.playTick();
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-mono transition-all ${
                    libraryCategory === cat
                      ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm'
                      : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Quick Action: Start Custom Blank */}
            <button
              onClick={handleStartBlank}
              className="px-4 py-2 rounded-2xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-mono font-bold flex items-center gap-2 transition-all"
            >
              <PlusCircle className="w-4 h-4" />
              Start Blank Custom Canvas
            </button>
          </div>

          {/* Pre-Made Circuits Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
            {filteredLibrary.map((circuit) => {
              const isSelected = selectedLibraryId === circuit.id;
              return (
                <div
                  key={circuit.id}
                  onClick={() => {
                    setSelectedLibraryId(circuit.id);
                    sounds.playTick();
                  }}
                  className={`p-4 rounded-3xl border text-left transition-all flex flex-col justify-between cursor-pointer space-y-3 ${
                    isSelected
                      ? 'bg-slate-900 border-emerald-400 shadow-md shadow-emerald-500/10 ring-1 ring-emerald-500/30'
                      : 'bg-slate-900/50 border-slate-800 hover:border-slate-700 hover:bg-slate-800/60'
                  }`}
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="px-2 py-0.5 rounded-md text-[9px] font-mono font-bold bg-slate-950 text-emerald-400 border border-slate-800">
                        {circuit.category}
                      </span>
                      <span
                        className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded ${
                          circuit.difficulty === 'Beginner'
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : circuit.difficulty === 'Intermediate'
                            ? 'bg-amber-500/20 text-amber-400'
                            : 'bg-purple-500/20 text-purple-400'
                        }`}
                      >
                        {circuit.difficulty}
                      </span>
                    </div>

                    <h3 className="text-sm font-bold text-white leading-tight">
                      {circuit.title}
                    </h3>
                    <p className="text-xs text-slate-400 font-mono line-clamp-2">
                      {circuit.description}
                    </p>
                  </div>

                  <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
                    <span className="text-[10px] font-mono text-slate-500">
                      {circuit.components.length} Comps • {circuit.wires.length} Wires
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleLoadPreMade(circuit);
                      }}
                      className="px-3 py-1 rounded-xl bg-emerald-500 text-slate-950 text-xs font-mono font-bold hover:bg-emerald-400 flex items-center gap-1 shadow-sm"
                    >
                      Load <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Selected Circuit Deep-Dive Preview Bento Card */}
          {selectedPreMade && (
            <div className="bg-slate-900/50 p-5 sm:p-6 rounded-3xl border border-slate-800 grid grid-cols-1 lg:grid-cols-12 gap-6 shadow-sm">
              <div className="lg:col-span-7 space-y-3">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    Selected Circuit Preview
                  </span>
                  <span className="text-xs font-mono text-slate-400">
                    {selectedPreMade.category} • {selectedPreMade.difficulty}
                  </span>
                </div>

                <h3 className="text-base sm:text-lg font-bold text-white">
                  {selectedPreMade.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-300 font-mono leading-relaxed">
                  {selectedPreMade.description}
                </p>

                <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 space-y-1 font-mono text-xs">
                  <span className="text-emerald-400 font-bold block text-[11px] uppercase">
                    🎓 Key Learning Objective:
                  </span>
                  <p className="text-slate-400 leading-relaxed">
                    {selectedPreMade.learningGoal}
                  </p>
                </div>

                <div className="flex flex-wrap gap-2 pt-2">
                  <button
                    onClick={() => handleLoadPreMade(selectedPreMade)}
                    className="px-5 py-2.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold font-mono text-xs flex items-center gap-2 shadow-lg shadow-emerald-500/20 transition-transform active:scale-95"
                  >
                    <Wrench className="w-4 h-4" />
                    Open in Interactive Simulator & Tester
                  </button>
                </div>
              </div>

              {/* Component breakdown summary */}
              <div className="lg:col-span-5 bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3 font-mono text-xs">
                <span className="text-[10px] uppercase font-bold text-slate-400 block border-b border-slate-800 pb-2">
                  Circuit Schematic Components ({selectedPreMade.components.length})
                </span>
                <div className="space-y-1.5 max-h-[160px] overflow-y-auto no-scrollbar">
                  {selectedPreMade.components.map((c) => (
                    <div key={c.id} className="flex justify-between items-center bg-slate-900/60 p-2 rounded-xl border border-slate-800/60">
                      <span className="text-white font-bold">{c.label}</span>
                      <span className="text-emerald-400">{c.type}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* User Saved Circuits Drawer */}
          {savedUserCircuits.length > 0 && (
            <div className="bg-slate-900/50 p-5 rounded-3xl border border-slate-800 space-y-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                  <FolderOpen className="w-3.5 h-3.5 text-emerald-400" />
                  Your Saved Custom Designs ({savedUserCircuits.length})
                </h3>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                {savedUserCircuits.map((sc, idx) => (
                  <div
                    key={idx}
                    className="bg-slate-950 p-3 rounded-2xl border border-slate-800 flex items-center justify-between"
                  >
                    <div className="font-mono text-xs">
                      <span className="font-bold text-white block">{sc.name}</span>
                      <span className="text-[10px] text-slate-500">{sc.components.length} elements</span>
                    </div>
                    <button
                      onClick={() => handleLoadUserSaved(sc)}
                      className="px-2.5 py-1 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-mono font-bold hover:bg-emerald-500 hover:text-slate-950"
                    >
                      Load
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODE 2: MAKE YOUR OWN CUSTOM CIRCUIT CANVAS & WORKSPACE */}
      {/* ========================================================================= */}
      {designerMode === 'custom' && (
        <div className="space-y-4">
          {/* Active Workspace Banner & Save Controls */}
          <div className="bg-slate-900/50 p-3 sm:p-4 rounded-3xl border border-slate-800 flex flex-wrap items-center justify-between gap-2 shadow-sm">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-emerald-400 font-bold flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5" />
                Active Circuit: {activeLoadedCircuitTitle}
              </span>
              <button
                onClick={() => setDesignerMode('library')}
                className="px-2.5 py-1 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-xs font-mono text-slate-400 hover:text-white"
              >
                ← Switch Circuit
              </button>
            </div>

            {/* Quick Component Place Toolbar */}
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-[10px] font-mono font-bold text-slate-500 uppercase mr-1">
                + Add:
              </span>
              <button
                onClick={() => addComponent('dc_source')}
                className="px-2 py-1 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-xs font-mono text-amber-400 flex items-center gap-1"
              >
                <Zap className="w-3 h-3" /> Battery
              </button>
              <button
                onClick={() => addComponent('resistor')}
                className="px-2 py-1 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-xs font-mono text-emerald-400 flex items-center gap-1"
              >
                <Activity className="w-3 h-3" /> Resistor
              </button>
              <button
                onClick={() => addComponent('bulb')}
                className="px-2 py-1 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-xs font-mono text-yellow-400 flex items-center gap-1"
              >
                <Lightbulb className="w-3 h-3" /> Lamp
              </button>
              <button
                onClick={() => addComponent('led')}
                className="px-2 py-1 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-xs font-mono text-green-400 flex items-center gap-1"
              >
                <Radio className="w-3 h-3" /> LED
              </button>
              <button
                onClick={() => addComponent('switch')}
                className="px-2 py-1 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-xs font-mono text-cyan-400 flex items-center gap-1"
              >
                <ToggleLeft className="w-3 h-3" /> Switch
              </button>
              <button
                onClick={() => addComponent('fuse')}
                className="px-2 py-1 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-xs font-mono text-rose-400 flex items-center gap-1"
              >
                <Flame className="w-3 h-3" /> Fuse
              </button>
              <button
                onClick={() => addComponent('ground')}
                className="px-2 py-1 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-xs font-mono text-slate-300 flex items-center gap-1"
              >
                ⏚ GND
              </button>

              <button
                onClick={() => setShowSaveModal(true)}
                className="px-2.5 py-1 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500 hover:text-slate-950 text-xs font-mono font-bold flex items-center gap-1 ml-2"
              >
                <Save className="w-3 h-3" /> Save Design
              </button>
            </div>
          </div>

          {/* Designer Main Grid & Component Inspector Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            {/* Interactive Canvas (9 cols) */}
            <div className="lg:col-span-9 bg-slate-900/50 p-4 sm:p-5 rounded-3xl border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                    <Activity className="w-3.5 h-3.5 text-emerald-400" />
                    Interactive Schematic Canvas
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-mono text-slate-400 bg-slate-950 border border-slate-800 hidden sm:inline-flex items-center gap-1">
                    <Move className="w-2.5 h-2.5 text-emerald-400" /> Drag to move components
                  </span>
                  {wiringStartPin && (
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 animate-pulse">
                      Click target pin to complete wire...
                    </span>
                  )}
                </div>

                {/* Canvas Toolbar Actions */}
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={rotateSelected}
                    disabled={!selectedCompId}
                    className="p-1.5 rounded-xl bg-slate-950 hover:bg-slate-800 disabled:opacity-40 border border-slate-800 text-xs font-mono text-slate-300 flex items-center gap-1"
                    title="Rotate 90°"
                  >
                    <RotateCw className="w-3.5 h-3.5" /> Rotate
                  </button>
                  <button
                    onClick={deleteSelected}
                    disabled={!selectedCompId && !selectedWireId}
                    className="p-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 disabled:opacity-40 border border-rose-500/30 text-xs font-mono flex items-center gap-1"
                    title="Delete Selected"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> Delete
                  </button>
                  <button
                    onClick={handleStartBlank}
                    className="p-1.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-xs font-mono text-slate-400"
                    title="Clear to Blank"
                  >
                    Clear
                  </button>
                </div>
              </div>

              {/* SVG Canvas Area with Direct Drag & Drop */}
              <div className="w-full bg-slate-950 rounded-2xl border border-slate-800/90 overflow-auto relative select-none shadow-inner min-h-[460px]">
                <svg
                  ref={svgRef}
                  width={GRID_COLS * CELL_SIZE}
                  height={GRID_ROWS * CELL_SIZE}
                  className="w-full h-auto min-w-[700px] block cursor-crosshair"
                  onMouseMove={handleCanvasMouseMove}
                  onTouchMove={handleCanvasTouchMove}
                  onMouseUp={handleCanvasMouseUp}
                  onTouchEnd={handleCanvasMouseUp}
                  onMouseLeave={handleCanvasMouseUp}
                  onClick={() => {
                    if (!hasMovedDuringDrag) {
                      setSelectedCompId(null);
                      setSelectedWireId(null);
                      setWiringStartPin(null);
                    }
                  }}
                >
                  {/* Background Grid Pattern */}
                  <defs>
                    <pattern id="canvas-grid" width={CELL_SIZE} height={CELL_SIZE} patternUnits="userSpaceOnUse">
                      <circle cx={CELL_SIZE / 2} cy={CELL_SIZE / 2} r="1" fill="#334155" />
                    </pattern>
                  </defs>
                  <rect width="100%" height="100%" fill="url(#canvas-grid)" />

                  {/* Render Wires */}
                  {wires.map((wire) => {
                    const compA = components.find((c) => c.id === wire.fromCompId);
                    const compB = components.find((c) => c.id === wire.toCompId);
                    if (!compA || !compB) return null;

                    const posA = getPinAbsolutePos(compA, wire.fromPinId);
                    const posB = getPinAbsolutePos(compB, wire.toPinId);
                    const isSelected = selectedWireId === wire.id;
                    const current = simResult.wireCurrents[wire.id] || 0;
                    const isFlowing = current > 0.0001;

                    const dx = posB.x - posA.x;
                    const dy = posB.y - posA.y;
                    const pathD = `M ${posA.x} ${posA.y} C ${posA.x + dx * 0.4} ${posA.y}, ${posA.x + dx * 0.6} ${posB.y}, ${posB.x} ${posB.y}`;

                    return (
                      <g
                        key={wire.id}
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedWireId(wire.id);
                          setSelectedCompId(null);
                          sounds.playTick();
                        }}
                        className="cursor-pointer group"
                      >
                        <path d={pathD} fill="none" stroke="transparent" strokeWidth="14" />
                        <path
                          d={pathD}
                          fill="none"
                          stroke={isSelected ? '#f59e0b' : isFlowing ? '#38bdf8' : '#475569'}
                          strokeWidth={isSelected ? '3.5' : '2.5'}
                          strokeLinecap="round"
                        />
                        {isFlowing && (
                          <path
                            d={pathD}
                            fill="none"
                            stroke="#fef08a"
                            strokeWidth="2"
                            strokeDasharray="4 8"
                            className="animate-[dash_1s_linear_infinite]"
                          />
                        )}
                      </g>
                    );
                  })}

                  {/* Render Components */}
                  {components.map((comp) => {
                    const cx = comp.x * CELL_SIZE;
                    const cy = comp.y * CELL_SIZE;
                    const isSelected = selectedCompId === comp.id;
                    const isDragging = draggingCompId === comp.id;
                    const pins = getComponentPinList(comp.type);
                    const compCurrent = simResult.componentCurrents[comp.id] || 0;
                    const compVoltage = simResult.componentVoltages[comp.id] || 0;
                    const compPower = simResult.componentPowers[comp.id] || 0;

                    return (
                      <g
                        key={comp.id}
                        transform={`translate(${cx}, ${cy}) rotate(${comp.rotation})`}
                        onMouseDown={(e) => handleCompMouseDown(e, comp)}
                        onTouchStart={(e) => handleCompTouchStart(e, comp)}
                        onClick={(e) => {
                          e.stopPropagation();
                          handleCompClick(comp);
                        }}
                        className={`cursor-grab active:cursor-grabbing group ${isDragging ? 'opacity-90' : ''}`}
                      >
                        {/* Drag and selection highlight halo */}
                        {isSelected && (
                          <rect
                            x="-38"
                            y="-26"
                            width="76"
                            height="52"
                            rx="12"
                            fill="#38bdf8"
                            fillOpacity={isDragging ? '0.2' : '0.1'}
                            stroke={isDragging ? '#f59e0b' : '#38bdf8'}
                            strokeWidth={isDragging ? '2' : '1.5'}
                            strokeDasharray={isDragging ? undefined : '3 3'}
                          />
                        )}

                        {/* Visual representations */}
                        {comp.type === 'dc_source' && (
                          <g>
                            <line x1="0" y1="-30" x2="0" y2="30" stroke="#0ea5e9" strokeWidth="2" />
                            <line x1="-20" y1="-8" x2="20" y2="-8" stroke="#f59e0b" strokeWidth="3" />
                            <line x1="-10" y1="8" x2="10" y2="8" stroke="#64748b" strokeWidth="3" />
                            <text x="-16" y="-12" fill="#f59e0b" fontSize="10" fontWeight="bold" fontFamily="monospace">+</text>
                            <text x="-16" y="16" fill="#94a3b8" fontSize="10" fontWeight="bold" fontFamily="monospace">-</text>
                          </g>
                        )}

                        {comp.type === 'resistor' && (
                          <g>
                            <line x1="-30" y1="0" x2="-18" y2="0" stroke="#38bdf8" strokeWidth="2" />
                            <rect x="-18" y="-10" width="36" height="20" rx="4" fill="#0f172a" stroke="#10b981" strokeWidth="2" />
                            <line x1="-10" y1="-8" x2="-10" y2="8" stroke="#ef4444" strokeWidth="2" />
                            <line x1="-4" y1="-8" x2="-4" y2="8" stroke="#3b82f6" strokeWidth="2" />
                            <line x1="2" y1="-8" x2="2" y2="8" stroke="#eab308" strokeWidth="2" />
                            <line x1="8" y1="-8" x2="8" y2="8" stroke="#d97706" strokeWidth="2" />
                            <line x1="18" y1="0" x2="30" y2="0" stroke="#38bdf8" strokeWidth="2" />
                          </g>
                        )}

                        {comp.type === 'bulb' && (
                          <g>
                            <line x1="-30" y1="0" x2="-16" y2="0" stroke="#38bdf8" strokeWidth="2" />
                            <circle
                              cx="0"
                              cy="0"
                              r="16"
                              fill={compPower > 0.01 ? '#fef08a' : '#0f172a'}
                              fillOpacity={compPower > 0.01 ? Math.min(0.9, 0.2 + compPower * 0.1) : 0.8}
                              stroke={compPower > 0.01 ? '#eab308' : '#64748b'}
                              strokeWidth="2"
                            />
                            <line x1="-6" y1="-6" x2="6" y2="6" stroke={compPower > 0.01 ? '#d97706' : '#94a3b8'} strokeWidth="1.5" />
                            <line x1="-6" y1="6" x2="6" y2="-6" stroke={compPower > 0.01 ? '#d97706' : '#94a3b8'} strokeWidth="1.5" />
                            <line x1="16" y1="0" x2="30" y2="0" stroke="#38bdf8" strokeWidth="2" />
                          </g>
                        )}

                        {comp.type === 'led' && (
                          <g>
                            <line x1="-30" y1="0" x2="-12" y2="0" stroke="#38bdf8" strokeWidth="2" />
                            <polygon
                              points="-12,-12 -12,12 8,0"
                              fill={compCurrent > 0.001 ? '#22c55e' : '#0f172a'}
                              stroke="#22c55e"
                              strokeWidth="2"
                            />
                            <line x1="8" y1="-12" x2="8" y2="12" stroke="#22c55e" strokeWidth="2" />
                            <line x1="8" y1="0" x2="30" y2="0" stroke="#38bdf8" strokeWidth="2" />
                            {compCurrent > 0.001 && (
                              <g stroke="#86efac" strokeWidth="1.5">
                                <line x1="2" y1="-14" x2="10" y2="-22" />
                                <line x1="10" y1="-10" x2="18" y2="-18" />
                              </g>
                            )}
                          </g>
                        )}

                        {comp.type === 'switch' && (
                          <g>
                            <line x1="-30" y1="0" x2="-14" y2="0" stroke="#38bdf8" strokeWidth="2" />
                            <circle cx="-14" cy="0" r="3" fill="#38bdf8" />
                            <circle cx="14" cy="0" r="3" fill="#38bdf8" />
                            {comp.extra?.switchClosed ? (
                              <line x1="-14" y1="0" x2="14" y2="0" stroke="#10b981" strokeWidth="3" />
                            ) : (
                              <line x1="-14" y1="0" x2="10" y2="-14" stroke="#ef4444" strokeWidth="3" />
                            )}
                            <line x1="14" y1="0" x2="30" y2="0" stroke="#38bdf8" strokeWidth="2" />
                          </g>
                        )}

                        {comp.type === 'fuse' && (
                          <g>
                            <line x1="-30" y1="0" x2="-18" y2="0" stroke="#38bdf8" strokeWidth="2" />
                            <rect x="-18" y="-8" width="36" height="16" rx="4" fill="#0f172a" stroke={comp.extra?.fuseBlown ? '#ef4444' : '#38bdf8'} strokeWidth="1.5" />
                            {comp.extra?.fuseBlown ? (
                              <line x1="-12" y1="0" x2="-4" y2="0" stroke="#ef4444" strokeWidth="2" strokeDasharray="3 3" />
                            ) : (
                              <path d="M -12 0 Q -6 -6 0 0 Q 6 6 12 0" fill="none" stroke="#f59e0b" strokeWidth="2" />
                            )}
                            <line x1="18" y1="0" x2="30" y2="0" stroke="#38bdf8" strokeWidth="2" />
                          </g>
                        )}

                        {comp.type === 'ground' && (
                          <g>
                            <line x1="0" y1="-20" x2="0" y2="0" stroke="#38bdf8" strokeWidth="2" />
                            <line x1="-16" y1="0" x2="16" y2="0" stroke="#94a3b8" strokeWidth="2" />
                            <line x1="-10" y1="6" x2="10" y2="6" stroke="#94a3b8" strokeWidth="2" />
                            <line x1="-4" y1="12" x2="4" y2="12" stroke="#94a3b8" strokeWidth="2" />
                          </g>
                        )}

                        {/* Component Pins */}
                        {pins.map((pin) => {
                          const isWiringFrom =
                            wiringStartPin?.compId === comp.id && wiringStartPin?.pinId === pin.id;
                          return (
                            <g
                              key={pin.id}
                              transform={`translate(${pin.relX * CELL_SIZE}, ${pin.relY * CELL_SIZE})`}
                              onClick={(e) => handlePinClick(e, comp.id, pin.id)}
                              className="hover:scale-125 transition-transform"
                            >
                              <circle
                                cx="0"
                                cy="0"
                                r={isWiringFrom ? 6 : 4}
                                fill={isWiringFrom ? '#f59e0b' : '#38bdf8'}
                                stroke="#0f172a"
                                strokeWidth="1.5"
                              />
                            </g>
                          );
                        })}

                        <text
                          x="0"
                          y="26"
                          fill="#94a3b8"
                          fontSize="9"
                          fontWeight="bold"
                          fontFamily="monospace"
                          textAnchor="middle"
                        >
                          {comp.label}
                        </text>
                      </g>
                    );
                  })}
                </svg>
              </div>
            </div>

            {/* Right Inspector & Diagnostics (3 cols) */}
            <div className="lg:col-span-3 space-y-4">
              {/* Telemetry diagnostics */}
              <div className="bg-slate-900/50 p-4 rounded-3xl border border-slate-800 space-y-2">
                <span className="text-[10px] font-mono uppercase font-bold text-slate-400 block border-b border-slate-800 pb-1.5">
                  Live Diagnostics
                </span>
                <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                  <div className="bg-slate-950 p-2 rounded-xl border border-slate-800">
                    <span className="text-[9px] text-slate-500 block uppercase">Req</span>
                    <span className="text-emerald-400 font-bold">{formatResistance(simResult.totalEquivalentResistance)}</span>
                  </div>
                  <div className="bg-slate-950 p-2 rounded-xl border border-slate-800">
                    <span className="text-[9px] text-slate-500 block uppercase">Total Power</span>
                    <span className="text-amber-400 font-bold">{formatPower(simResult.totalSourcePower)}</span>
                  </div>
                </div>
              </div>

              {/* Selected component inspector with Typable Values & Renaming */}
              <div className="bg-slate-900/50 p-5 rounded-3xl border border-slate-800 space-y-4 shadow-sm">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                    <Sliders className="w-3.5 h-3.5 text-emerald-400" />
                    Element Inspector
                  </h3>
                </div>

                {selectedComp ? (
                  <div className="space-y-3 text-xs font-mono">
                    {/* Component Label Renamer */}
                    <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-1.5">
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] text-slate-500 uppercase font-bold">Element Label:</span>
                        <span className="text-[10px] text-emerald-400 uppercase font-bold">{selectedComp.type}</span>
                      </div>
                      <input
                        type="text"
                        value={selectedComp.label}
                        onChange={(e) => {
                          const val = e.target.value;
                          setComponents((prev) =>
                            prev.map((c) => (c.id === selectedComp.id ? { ...c, label: val } : c))
                          );
                        }}
                        className="w-full bg-slate-900 border border-slate-800 text-white font-bold text-xs px-2.5 py-1.5 rounded-xl focus:border-emerald-500 focus:outline-none"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div className="bg-slate-950 p-2 rounded-xl border border-slate-800">
                        <span className="text-[9px] text-slate-500 block uppercase">Voltage Drop</span>
                        <span className="text-amber-400 font-bold">
                          {formatVoltage(simResult.componentVoltages[selectedComp.id] || 0)}
                        </span>
                      </div>
                      <div className="bg-slate-950 p-2 rounded-xl border border-slate-800">
                        <span className="text-[9px] text-slate-500 block uppercase">Current Flow</span>
                        <span className="text-cyan-400 font-bold">
                          {formatCurrent(simResult.componentCurrents[selectedComp.id] || 0)}
                        </span>
                      </div>
                    </div>

                    {/* Typable Value Input: DC Voltage Source */}
                    {selectedComp.type === 'dc_source' && (
                      <div className="space-y-2 pt-2 border-t border-slate-800">
                        <div className="flex items-center justify-between">
                          <span className="text-slate-400 font-bold">Supply Voltage:</span>
                          <div className="flex items-center gap-1">
                            <input
                              type="number"
                              min="0.1"
                              max="1000"
                              step="any"
                              value={selectedComp.value}
                              onChange={(e) => {
                                const val = parseFloat(e.target.value) || 0;
                                setComponents((prev) =>
                                  prev.map((c) => (c.id === selectedComp.id ? { ...c, value: val } : c))
                                );
                              }}
                              className="w-20 bg-slate-950 border border-slate-800 text-amber-400 font-bold text-xs px-2 py-1 rounded-lg text-right focus:border-amber-500 focus:outline-none"
                            />
                            <span className="text-slate-400 font-bold">V</span>
                          </div>
                        </div>

                        {/* Voltage Quick Presets */}
                        <div className="flex flex-wrap gap-1">
                          {[3.3, 5, 9, 12, 24, 48].map((v) => (
                            <button
                              key={v}
                              onClick={() => {
                                setComponents((prev) =>
                                  prev.map((c) => (c.id === selectedComp.id ? { ...c, value: v } : c))
                                );
                                sounds.playTick();
                              }}
                              className={`px-2 py-0.5 rounded-md text-[10px] border ${
                                selectedComp.value === v
                                  ? 'bg-amber-500 text-slate-950 font-bold border-amber-400'
                                  : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                              }`}
                            >
                              {v}V
                            </button>
                          ))}
                        </div>

                        <input
                          type="range"
                          min="1"
                          max="48"
                          value={selectedComp.value}
                          onChange={(e) => {
                            const val = parseFloat(e.target.value);
                            setComponents((prev) =>
                              prev.map((c) => (c.id === selectedComp.id ? { ...c, value: val } : c))
                            );
                          }}
                          className="w-full accent-amber-500"
                        />
                      </div>
                    )}

                    {/* Typable Value Input: Resistor or Bulb */}
                    {(selectedComp.type === 'resistor' || selectedComp.type === 'bulb') && (
                      <div className="space-y-2 pt-2 border-t border-slate-800">
                        <div className="flex items-center justify-between">
                          <span className="text-slate-400 font-bold">Resistance (Ω):</span>
                          <div className="flex items-center gap-1">
                            <input
                              type="number"
                              min="0.1"
                              max="1000000"
                              step="any"
                              value={selectedComp.value}
                              onChange={(e) => {
                                const val = parseFloat(e.target.value) || 0;
                                setComponents((prev) =>
                                  prev.map((c) => (c.id === selectedComp.id ? { ...c, value: val } : c))
                                );
                              }}
                              className="w-24 bg-slate-950 border border-slate-800 text-emerald-400 font-bold text-xs px-2 py-1 rounded-lg text-right focus:border-emerald-500 focus:outline-none"
                            />
                            <span className="text-slate-400 font-bold">Ω</span>
                          </div>
                        </div>

                        {/* Resistor Quick Presets */}
                        <div className="flex flex-wrap gap-1">
                          {[10, 48, 100, 220, 330, 470, 1000].map((r) => (
                            <button
                              key={r}
                              onClick={() => {
                                setComponents((prev) =>
                                  prev.map((c) => (c.id === selectedComp.id ? { ...c, value: r } : c))
                                );
                                sounds.playTick();
                              }}
                              className={`px-1.5 py-0.5 rounded-md text-[10px] border ${
                                selectedComp.value === r
                                  ? 'bg-emerald-500 text-slate-950 font-bold border-emerald-400'
                                  : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                              }`}
                            >
                              {r >= 1000 ? `${r / 1000}kΩ` : `${r}Ω`}
                            </button>
                          ))}
                        </div>

                        <input
                          type="range"
                          min="10"
                          max="1000"
                          step="10"
                          value={selectedComp.value}
                          onChange={(e) => {
                            const val = parseFloat(e.target.value);
                            setComponents((prev) =>
                              prev.map((c) => (c.id === selectedComp.id ? { ...c, value: val } : c))
                            );
                          }}
                          className="w-full accent-emerald-500"
                        />
                      </div>
                    )}

                    {/* Typable Value Input: Fuse */}
                    {selectedComp.type === 'fuse' && (
                      <div className="space-y-2 pt-2 border-t border-slate-800">
                        <div className="flex items-center justify-between">
                          <span className="text-slate-400 font-bold">Trip Rating:</span>
                          <div className="flex items-center gap-1">
                            <input
                              type="number"
                              min="0.1"
                              max="50"
                              step="0.1"
                              value={selectedComp.value}
                              onChange={(e) => {
                                const val = parseFloat(e.target.value) || 0;
                                setComponents((prev) =>
                                  prev.map((c) => (c.id === selectedComp.id ? { ...c, value: val } : c))
                                );
                              }}
                              className="w-20 bg-slate-950 border border-slate-800 text-rose-400 font-bold text-xs px-2 py-1 rounded-lg text-right focus:border-rose-500 focus:outline-none"
                            />
                            <span className="text-slate-400 font-bold">A</span>
                          </div>
                        </div>

                        <input
                          type="range"
                          min="0.5"
                          max="5.0"
                          step="0.5"
                          value={selectedComp.value}
                          onChange={(e) => {
                            const val = parseFloat(e.target.value);
                            setComponents((prev) =>
                              prev.map((c) => (c.id === selectedComp.id ? { ...c, value: val } : c))
                            );
                          }}
                          className="w-full accent-rose-500"
                        />
                        {selectedComp.extra?.fuseBlown && (
                          <button
                            onClick={() => handleCompClick(selectedComp)}
                            className="w-full py-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold text-xs flex items-center justify-center gap-1.5"
                          >
                            <RefreshCw className="w-3.5 h-3.5" /> Replace Blown Fuse
                          </button>
                        )}
                      </div>
                    )}

                    {/* Canvas nudge controls for precision fine-tuning */}
                    <div className="space-y-1 pt-2 border-t border-slate-800">
                      <span className="text-[10px] text-slate-500 block uppercase">Nudge Grid Position:</span>
                      <div className="grid grid-cols-2 gap-1.5">
                        <button
                          onClick={() => {
                            if (selectedComp.x > 1) {
                              setComponents((prev) =>
                                prev.map((c) => (c.id === selectedComp.id ? { ...c, x: c.x - 1 } : c))
                              );
                            }
                          }}
                          className="p-1 rounded-lg bg-slate-950 border border-slate-800 text-[10px]"
                        >
                          ← Left
                        </button>
                        <button
                          onClick={() => {
                            if (selectedComp.x < GRID_COLS - 1) {
                              setComponents((prev) =>
                                prev.map((c) => (c.id === selectedComp.id ? { ...c, x: c.x + 1 } : c))
                              );
                            }
                          }}
                          className="p-1 rounded-lg bg-slate-950 border border-slate-800 text-[10px]"
                        >
                          Right →
                        </button>
                        <button
                          onClick={() => {
                            if (selectedComp.y > 1) {
                              setComponents((prev) =>
                                prev.map((c) => (c.id === selectedComp.id ? { ...c, y: c.y - 1 } : c))
                              );
                            }
                          }}
                          className="p-1 rounded-lg bg-slate-950 border border-slate-800 text-[10px]"
                        >
                          ↑ Up
                        </button>
                        <button
                          onClick={() => {
                            if (selectedComp.y < GRID_ROWS - 1) {
                              setComponents((prev) =>
                                prev.map((c) => (c.id === selectedComp.id ? { ...c, y: c.y + 1 } : c))
                              );
                            }
                          }}
                          className="p-1 rounded-lg bg-slate-950 border border-slate-800 text-[10px]"
                        >
                          Down ↓
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-6 text-slate-500 font-mono text-xs space-y-2">
                    <Wrench className="w-8 h-8 mx-auto text-slate-700 stroke-[1.5]" />
                    <p>Click or drag any component on the canvas to inspect, move, and edit properties.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Save Circuit Modal */}
      {showSaveModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full space-y-4 shadow-2xl">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Save className="w-4 h-4 text-emerald-400" />
              Save Custom Circuit
            </h3>
            <p className="text-xs text-slate-400 font-mono">
              Give your circuit design a name to save it to your collection.
            </p>
            <input
              type="text"
              value={saveCircuitName}
              onChange={(e) => setSaveCircuitName(e.target.value)}
              placeholder="e.g., My Sensor Bridge"
              className="w-full bg-slate-950 border border-slate-800 text-white text-xs font-mono p-3 rounded-2xl focus:border-emerald-500 focus:outline-none"
            />
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setShowSaveModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-mono hover:bg-slate-700"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveCircuit}
                className="px-4 py-2 rounded-xl bg-emerald-500 text-slate-950 font-bold text-xs font-mono hover:bg-emerald-400"
              >
                Save Circuit
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
