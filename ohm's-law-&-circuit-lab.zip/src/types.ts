export type LabTab =
  | 'custom_designer'
  | 'circuit_solver'
  | 'virp_matrix'
  | 'ohms_calculator'
  | 'circuit_sandbox'
  | 'physics_visualizer'
  | 'resistor_code'
  | 'challenges';

export interface OhmsCalculation {
  voltage: number;      // in Volts (V)
  current: number;      // in Amperes (A)
  resistance: number;   // in Ohms (Ω)
  power: number;        // in Watts (W)
  solvedFor: 'V' | 'I' | 'R' | 'P';
}

export type UnitPrefix = 'micro' | 'milli' | 'base' | 'kilo' | 'mega';

export type LoadType = 'bulb' | 'led' | 'motor' | 'resistor_only' | 'heating_element';

export type CircuitTopology = 'single' | 'series' | 'parallel' | 'potentiometer' | 'led_circuit' | 'fuse_circuit';

export interface CircuitState {
  sourceVoltage: number;        // Volts
  internalResistance: number;    // Ohms
  switchClosed: boolean;
  topology: CircuitTopology;
  resistor1: number;            // Ohms
  resistor2: number;            // Ohms
  potentiometerPosition: number;// 0.0 to 1.0
  loadType: LoadType;
  ledColor: 'red' | 'green' | 'blue' | 'yellow' | 'white';
  fuseRating: number;           // Amperes (e.g. 0.5A, 1A, 2A)
  fuseBlown: boolean;
  probeA: 'source_pos' | 'source_neg' | 'r1_in' | 'r1_out' | 'r2_in' | 'r2_out' | 'load_in' | 'load_out' | null;
  probeB: 'source_pos' | 'source_neg' | 'r1_in' | 'r1_out' | 'r2_in' | 'r2_out' | 'load_in' | 'load_out' | null;
  multimeterMode: 'voltage' | 'current' | 'resistance' | 'continuity';
}

export interface ResistorBandColor {
  name: string;
  value: number;
  multiplier: number;
  tolerance?: number;
  colorHex: string;
  textColor: string;
}

export interface Challenge {
  id: string;
  title: string;
  category: 'beginner' | 'intermediate' | 'troubleshooting' | 'design';
  description: string;
  targetQuestion: string;
  givenValues: { label: string; value: string }[];
  targetParameter: 'V' | 'I' | 'R' | 'P' | 'resistor_val';
  correctValue: number;
  unit: string;
  tolerancePct: number;
  explanation: string;
  hint: string;
  diagramTopology?: CircuitTopology;
}

// Custom Circuit Designer Types
export type CustomCompType =
  | 'dc_source'
  | 'resistor'
  | 'bulb'
  | 'led'
  | 'switch'
  | 'fuse'
  | 'ground'
  | 'voltmeter'
  | 'ammeter';

export interface ComponentPin {
  id: string;
  label?: string;
  relX: number; // relative to component center (grid units)
  relY: number;
}

export interface CustomComponent {
  id: string;
  type: CustomCompType;
  label: string;
  x: number; // grid coordinates (e.g. 0 to 20)
  y: number;
  rotation: 0 | 90 | 180 | 270;
  value: number; // Volts for source, Ohms for resistor/bulb, Amps for fuse
  extra?: {
    switchClosed?: boolean;
    fuseBlown?: boolean;
    ledColor?: 'red' | 'green' | 'blue' | 'yellow' | 'white';
    forwardVoltage?: number;
    bulbRatedWatts?: number;
  };
}

export interface CustomWire {
  id: string;
  fromCompId: string;
  fromPinId: string;
  toCompId: string;
  toPinId: string;
  points?: { x: number; y: number }[]; // optional waypoints
}

export interface SimulationResult {
  nodeVoltages: Record<string, number>;
  componentCurrents: Record<string, number>; // current through component (A)
  componentVoltages: Record<string, number>; // voltage drop across component (V)
  componentPowers: Record<string, number>;   // power dissipated (W)
  wireCurrents: Record<string, number>;      // current through wire (A)
  totalSourcePower: number;
  totalEquivalentResistance: number;
  isShortCircuit: boolean;
  blownFuses: string[];
}

// Step-by-Step Solver Types
export type SolverTopology =
  | 'series'
  | 'parallel'
  | 'combo_series_parallel'   // R1 + (R2 || R3)
  | 'combo_parallel_series'   // (R1 + R2) || (R3 + R4)
  | 'combo_ladder'            // R1 + [R2 || (R3 + [R4 || R5])]
  | 'bridge_wheatstone';

export interface ResistorLedgerItem {
  id: string;
  label: string;
  resistance: number;
  voltage: number;
  current: number;
  power: number;
  formulaV: string;
  formulaI: string;
}

export interface ReductionStep {
  stepNumber: number;
  badgeTitle: string;
  heading: string;
  latexFormula: string;
  calculation: string;
  resultValue: string;
  rationale: string;
  highlightedComponents: string[];
}

